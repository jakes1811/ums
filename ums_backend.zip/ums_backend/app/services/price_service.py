from app.repositories.price_repository import (
    PriceRepository
)
 
 
class PriceService:
 
    @staticmethod
    def get_market_prices(
        page,
        page_size,
        search,
        exchange,
        trade_date
    ):
 
        return PriceRepository.get_market_prices(
            page=page,
            page_size=page_size,
            search=search,
            exchange=exchange,
            trade_date=trade_date
        )
 
 
    @staticmethod
    def get_trade_dates():
 
        return PriceRepository.get_trade_dates()
 