import {
  Box,
  Drawer,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Toolbar,
  Typography,
} from "@mui/material";
 
import SecurityIcon from "@mui/icons-material/Security";
import CategoryIcon from "@mui/icons-material/Category";
import AccountTreeIcon from "@mui/icons-material/AccountTree";
import PaletteIcon from "@mui/icons-material/Palette";
import PieChartIcon from "@mui/icons-material/PieChart";
import ShowChartIcon from "@mui/icons-material/ShowChart";
import QueryStatsIcon from "@mui/icons-material/QueryStats";
 
import { useNavigate } from "react-router-dom";
 
 
const drawerWidth = 240;
 
 
function Sidebar() {
 
  const navigate = useNavigate();
 
 
  const menuItems = [
 
    {
      name: "Securities",
      icon: <SecurityIcon />,
      path: "/securities",
    },
 
    {
      name: "Asset Classes",
      icon: <CategoryIcon />,
      path: "/asset-classes",
    },
 
    {
      name: "GICS",
      icon: <AccountTreeIcon />,
      path: "/gics",
    },
 
    {
      name: "Investment Themes",
      icon: <PaletteIcon />,
      path: "/themes",
    },
 
    {
      name: "Theme Allocation",
      icon: <PieChartIcon />,
      path: "/theme-allocation",
    },
 
    {
      name: "Market Prices",
      icon: <ShowChartIcon />,
      path: "/market-prices",
    },
 
    {
      name: "Benchmarks",
      icon: <QueryStatsIcon />,
      path: "/benchmarks",
    },
  ];
 
 
  return (
 
    <Drawer
      variant="permanent"
      sx={{
        width: drawerWidth,
 
        "& .MuiDrawer-paper": {
          width: drawerWidth,
          boxSizing: "border-box",
        },
      }}
    >
 
      <Toolbar>
 
        <Typography
          variant="h6"
          fontWeight="bold"
        >
          Security Master
        </Typography>
 
      </Toolbar>
 
 
      <Box>
 
        <List>
 
          {menuItems.map((item) => (
 
            <ListItemButton
              key={item.name}
              onClick={() =>
                navigate(item.path)
              }
            >
 
              <ListItemIcon>
                {item.icon}
              </ListItemIcon>
 
              <ListItemText
                primary={item.name}
              />
 
            </ListItemButton>
 
          ))}
 
        </List>
 
      </Box>
 
    </Drawer>
  );
}
 
 
export default Sidebar;