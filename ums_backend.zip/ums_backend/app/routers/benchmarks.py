from fastapi import APIRouter
from app.repositories.master_repository import (MasterRepository)
router = APIRouter(
    prefix="/benchmarks",
    tags=["Benchmarks"]
)
@router.get("")
def get_benchmarks():
    return MasterRepository.get_benchmarks()
 