from app.database.connection import get_db_connection
 
 
class HoldingRepository:
 
    @staticmethod
    def create_holding(
        portfolio_id,
        security_id,
        quantity,
        security_price,
        total_value
    ):
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            cursor.execute(
                """
                INSERT INTO assets_and_holdings
                (
                    portfolio_id,
                    security_id,
                    quantity,
                    security_price,
                    total_value
                )
 
                VALUES
                (
                    %s, %s, %s, %s, %s
                )
 
                RETURNING asset_holding_id;
                """,
                (
                    portfolio_id,
                    security_id,
                    quantity,
                    security_price,
                    total_value
                )
            )
 
            holding_id = cursor.fetchone()[0]
 
            conn.commit()
 
            return holding_id
 
        except Exception:
 
            conn.rollback()
            raise
 
        finally:
 
            cursor.close()
            conn.close()
 
    @staticmethod
    def get_holdings_by_portfolio(
        portfolio_id
    ):
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            cursor.execute(
                """
                SELECT
                    asset_holding_id,
                    portfolio_id,
                    security_id,
                    quantity,
                    security_price,
                    total_value
 
                FROM assets_and_holdings
 
                WHERE portfolio_id = %s
 
                ORDER BY asset_holding_id;
                """,
                (portfolio_id,)
            )
 
            rows = cursor.fetchall()
 
            return [
                {
                    "asset_holding_id": row[0],
                    "portfolio_id": row[1],
                    "security_id": row[2],
                    "quantity": float(row[3]),
                    "security_price": float(row[4]),
                    "total_value": float(row[5])
                }
 
                for row in rows
            ]
 
        finally:
 
            cursor.close()
            conn.close()

 
    @staticmethod
    def get_total_invested_value(
        portfolio_id
    ):
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            cursor.execute(
                """
                SELECT
                    COALESCE(
                        SUM(total_value),
                        0
                    )
 
                FROM assets_and_holdings
 
                WHERE portfolio_id = %s;
                """,
                (portfolio_id,)
            )
 
            total = cursor.fetchone()[0]
 
            return float(total)
 
        finally:
 
            cursor.close()
            conn.close()
    
    @staticmethod
    def get_holding_by_id(
        holding_id
    ):
    
        conn = get_db_connection()
        cursor = conn.cursor()
    
        try:
    
            cursor.execute(
                """
                SELECT
                    asset_holding_id,
                    portfolio_id,
                    security_id,
                    quantity,
                    security_price,
                    total_value
    
                FROM assets_and_holdings
    
                WHERE asset_holding_id = %s;
                """,
                (holding_id,)
            )
    
            row = cursor.fetchone()
    
            if row is None:
                return None
    
            return {
                "asset_holding_id": row[0],
                "portfolio_id": row[1],
                "security_id": row[2],
                "quantity": float(row[3]),
                "security_price": float(row[4]),
                "total_value": float(row[5])
            }
    
        finally:
    
            cursor.close()
            conn.close()

    
    @staticmethod
    def update_holding(
        holding_id,
        quantity,
        security_price,
        total_value
    ):
    
        conn = get_db_connection()
        cursor = conn.cursor()
    
        try:
    
            cursor.execute(
                """
                UPDATE assets_and_holdings
    
                SET
                    quantity = %s,
                    security_price = %s,
                    total_value = %s
    
                WHERE asset_holding_id = %s;
                """,
                (
                    quantity,
                    security_price,
                    total_value,
                    holding_id
                )
            )
    
            conn.commit()
    
        except Exception:
    
            conn.rollback()
            raise
    
        finally:
    
            cursor.close()
            conn.close()

    
    @staticmethod
    def delete_holding(
        holding_id
    ):
    
        conn = get_db_connection()
        cursor = conn.cursor()
    
        try:
    
            cursor.execute(
                """
                DELETE FROM assets_and_holdings
                WHERE asset_holding_id = %s;
                """,
                (holding_id,)
            )
    
            conn.commit()
    
        except Exception:
    
            conn.rollback()
            raise
    
        finally:
    
            cursor.close()
            conn.close()
    
    @staticmethod
    def get_holding_by_security(
        portfolio_id,
        security_id
    ):
    
        conn = get_db_connection()
        cursor = conn.cursor()
    
        try:
    
            cursor.execute(
                """
                SELECT
                    asset_holding_id,
                    portfolio_id,
                    security_id,
                    quantity,
                    security_price,
                    total_value
    
                FROM assets_and_holdings
    
                WHERE portfolio_id = %s
                AND security_id = %s;
                """,
                (
                    portfolio_id,
                    security_id
                )
            )
    
            row = cursor.fetchone()
    
            if row is None:
                return None
    
            return {
                "asset_holding_id":
                    row[0],
    
                "portfolio_id":
                    row[1],
    
                "security_id":
                    row[2],
    
                "quantity":
                    float(row[3]),
    
                "security_price":
                    float(row[4]),
    
                "total_value":
                    float(row[5])
            }
    
        finally:
    
            cursor.close()
            conn.close()
    