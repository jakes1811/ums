import csv
from pathlib import Path
 
from app.database.connection import get_db_connection
BATCH_SIZE = 500
def import_market_price():
    project_folder = Path(__file__).resolve().parents[2]
    csv_file = (
        project_folder
        / "data"
        / "market_price_2days_mock.csv"
    )
    if not csv_file.exists():
        print("Market price CSV not found:")
        print(csv_file)
        return
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""SELECT security_id FROM unified_security_master;""")
        valid_security_ids = {row[0] for row in cursor.fetchall()}
        print("Securities available:",len(valid_security_ids))
        price_rows = []
        missing_security_ids = set()
        with open(csv_file, "r", encoding="utf-8-sig") as file:
            reader = csv.DictReader(file)
            for row in reader:
                security_id = int(
                    row["security_id"]
                )
                if security_id not in valid_security_ids:
                    missing_security_ids.add(
                        security_id
                    )
 
                    continue
 
 
                # ---------------------------------------------
                # Prepare row
                # ---------------------------------------------
 
                price_rows.append(
                    (
                        security_id,
 
                        row["trade_date"],
 
                        float(
                            row["previous_close"]
                        ),
 
                        float(
                            row["open_price"]
                        ),
 
                        float(
                            row["high_price"]
                        ),
 
                        float(
                            row["low_price"]
                        ),
 
                        float(
                            row["close_price"]
                        ),
 
                        int(
                            row["volume"]
                        ),
 
                        float(
                            row["turnover"]
                        )
                    )
                )
 
 
        # =====================================================
        # 3. VALIDATION
        # =====================================================
 
        if missing_security_ids:
 
            print()
            print(
                "Missing security IDs:",
                sorted(
                    missing_security_ids
                )[:20]
            )
 
            raise Exception(
                "Some Market Price rows refer to "
                "securities that do not exist"
            )
 
 
        print(
            "Price rows ready:",
            len(price_rows)
        )
 
 
        # =====================================================
        # 4. INSERT QUERY
        # =====================================================
 
        insert_query = """
            INSERT INTO market_price
            (
                security_id,
                trade_date,
                previous_close,
                open_price,
                high_price,
                low_price,
                close_price,
                volume,
                turnover
            )
 
            VALUES
            (
                %s, %s, %s, %s, %s,
                %s, %s, %s, %s
            )
 
            ON CONFLICT
            (
                security_id,
                trade_date
            )
 
            DO UPDATE SET
 
                previous_close =
                    EXCLUDED.previous_close,
 
                open_price =
                    EXCLUDED.open_price,
 
                high_price =
                    EXCLUDED.high_price,
 
                low_price =
                    EXCLUDED.low_price,
 
                close_price =
                    EXCLUDED.close_price,
 
                volume =
                    EXCLUDED.volume,
 
                turnover =
                    EXCLUDED.turnover;
        """
 
 
        # =====================================================
        # 5. BATCH INSERT
        # =====================================================
 
        total_processed = 0
 
 
        for start in range(
            0,
            len(price_rows),
            BATCH_SIZE
        ):
 
            batch = price_rows[
                start:
                start + BATCH_SIZE
            ]
 
 
            cursor.executemany(
                insert_query,
                batch
            )
 
 
            total_processed += len(batch)
 
 
            print(
                f"Processed {total_processed} price rows"
            )
 
 
        conn.commit()
 
 
        # =====================================================
        # 6. VERIFY TOTAL COUNT
        # =====================================================
 
        cursor.execute("""
            SELECT COUNT(*)
            FROM market_price;
        """)
 
        total_count = cursor.fetchone()[0]
 
 
        # =====================================================
        # 7. VERIFY DATE COUNTS
        # =====================================================
 
        cursor.execute("""
            SELECT
                trade_date,
                COUNT(*)
 
            FROM market_price
 
            GROUP BY trade_date
 
            ORDER BY trade_date;
        """)
 
        date_counts = cursor.fetchall()
 
 
        print()
        print("--------------------------------")
        print("MARKET PRICE IMPORT COMPLETE")
        print("--------------------------------")
 
        print(
            "Total Market Price rows:",
            total_count
        )
 
        print()
 
        for trade_date, count in date_counts:
 
            print(
                trade_date,
                ":",
                count
            )

    except Exception as error:
        conn.rollback()
        print()
        print("Market Price import failed:")
        print(error)
        raise error
    finally:
        cursor.close()
        conn.close()
if __name__ == "__main__":
    import_market_price()
 