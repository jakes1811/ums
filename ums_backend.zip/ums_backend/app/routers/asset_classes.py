from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
 
from app.repositories.master_repository import MasterRepository
 
 
router = APIRouter(
    prefix="/asset-classes",
    tags=["Asset Classes"]
)

class AssetClassRequest(BaseModel):
 
    asset_class: str
 
    asset_description: str | None = None
 
    sub_asset_class: str | None = None
 
    risk: str | None = None
 
    investment_horizon: str | None = None
 
    sub_asset_description: str | None = None
 
    equity_category: str | None = None
 
 
@router.get("")
def get_asset_classes():
 
    return MasterRepository.get_asset_classes()
 
 
@router.post("")
def create_asset_class(
    data: AssetClassRequest
):
 
    return MasterRepository.create_asset_class(
        data.model_dump()
    )
 
 
@router.put("/{asset_class_id}")
def update_asset_class(
    asset_class_id: int,
    data: AssetClassRequest
):
 
    updated = MasterRepository.update_asset_class(
        asset_class_id,
        data.model_dump()
    )
 
    if updated == 0:
 
        raise HTTPException(
            status_code=404,
            detail="Asset class not found"
        )
 
    return {
        "message":
        "Asset class updated successfully"
    }
 