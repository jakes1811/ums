import axios from "axios";
const API = axios.create({ baseURL: "http://127.0.0.1:8001", });

export async function getPortfolios(){
    const response = await API.get("/portfolios");
    return response.data;
}

export async function getPortfolioById(portfolioId){
    const response = await API.get(`/portfolios/${portfolioId}`);
    return response.data;
}

export async function createPortfolio(data){
    const response = await API.post("/portfolios", data);
    return response.data;
}

export async function activatePortfolio(portfolioId){
    const response = await API.put(`/portfolios/${portfolioId}/activate`);
    return response.data;
}

export async function deletePortfolio(portfolioId){
    const response = await API.delete(`/portfolios/${portfolioId}`);
    return response.data;
}

export async function addHolding(portfolioId, data){
    const response = await API.post(`/portfolios/${portfolioId}/holdings`, data);
    return response.data;
}

export async function getHoldings(portfolioId){
    const response = await API.get(`/portfolios/${portfolioId}/holdings`);
    return response.data;
}  

export async function getAlerts() {
    const response = await API.get("/alerts");
    return response.data;
}

export async function getThemes() {
    const response = await API.get("/reference/themes");
    return response.data;
}

export async function getBenchmarks() {
    const response = await API.get("/reference/benchmarks");
    return response.data;
}

export async function getReferenceSecurities({exchange="", search="", equity_category="", page=1, pageSize=25, } = {}) {
    const response = await API.get("/reference/securities", {
        params: {
            exchange: exchange || undefined,
            search: search || undefined,
            equity_category: equity_category || undefined,
            page,
            page_size: pageSize,
            },
        }
    );
    return response.data;
}

export async function getPortfolioValuation(portfolioId, valuationDate){
    const response = await API.get(`/portfolios/${portfolioId}/valuation`,
        {
            params:{
                valuation_date: valuationDate,
            },
        }
    );
    return response.data;
}

export async function getPortfolioAllocation(portfolioId, valuationDate) {
    const response = await API.get(`/portfolios/${portfolioId}/allocation`,
        {
            params: {
                valuation_date: valuationDate,
            },
        }
    );
    return response.data;
}

export async function getPortfolioPerformance(portfolioId,valuationDate) {
    const response = await API.get(`/portfolios/${portfolioId}/performance`,
        {
            params: {
                valuation_date: valuationDate,
            },
        }
    );
    return response.data;
}

export async function buyMoreHolding(
  portfolioId,
  holdingId,
  data
) {
 
  const response =
    await API.post(
      `/portfolios/${portfolioId}/holdings/${holdingId}/buy-more`,
      data
    );
 
  return response.data;
}
 
 
export async function sellHolding(
  portfolioId,
  holdingId,
  data
) {
 
  const response =
    await API.post(
      `/portfolios/${portfolioId}/holdings/${holdingId}/sell`,
      data
    );
 
  return response.data;
}
 
 
export async function deleteHolding(
  portfolioId,
  holdingId
) {
 
  const response =
    await API.delete(
      `/portfolios/${portfolioId}/holdings/${holdingId}`
    );
 
  return response.data;
}

export async function closePortfolio(portfolioId){
    const response = await API.put(`/portfolios/${portfolioId}/close`);
    return response.data;
}



export default API;
