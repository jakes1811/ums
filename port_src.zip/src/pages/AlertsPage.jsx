import {
  useEffect,
  useMemo,
  useState,
} from "react";
 
import {
  Alert,
  Box,
  Button,
  Chip,
  CircularProgress,
  Typography,
} from "@mui/material";
 
import {
  DataGrid,
} from "@mui/x-data-grid";
 
import {
  useNavigate,
} from "react-router-dom";
 
import {
  getAlerts,
  getPortfolios,
} from "../api/api";
 
 
function AlertsPage() {
 
  const navigate =
    useNavigate();
 
 
  const [alerts, setAlerts] =
    useState([]);
 
  const [portfolios, setPortfolios] =
    useState([]);
 
  const [loading, setLoading] =
    useState(true);
 
  const [error, setError] =
    useState("");
 
 
  async function loadData() {
 
    try {
 
      setLoading(true);
      setError("");
 
 
      const [
        alertData,
        portfolioData,
      ] = await Promise.all([
 
        getAlerts(),
 
        getPortfolios(),
 
      ]);
 
 
      setAlerts(
        alertData || []
      );
 
      setPortfolios(
        portfolioData || []
      );
 
    }
    catch (err) {
 
      console.error(err);
 
      setError(
        err.response?.data?.detail ||
        "Unable to load alerts"
      );
 
    }
    finally {
 
      setLoading(false);
 
    }
 
  }
 
 
  useEffect(() => {
 
    loadData();
 
  }, []);
 
 
  const rows =
    useMemo(() => {
 
      return alerts.map(
        (alert) => {
 
          const portfolio =
            portfolios.find(
              item =>
                Number(
                  item.portfolio_id
                )
                ===
                Number(
                  alert.portfolio_id
                )
            );
 
 
          return {
 
            ...alert,
 
            portfolio_name:
              portfolio
                ?.portfolio_name
              ||
              `Portfolio ${alert.portfolio_id}`,
 
            asset_class_display:
              alert.asset_class
              ||
              alert.asset_class_name
              ||
              `Asset Class ${alert.asset_class_id}`,
 
          };
 
        }
      );
 
    }, [
      alerts,
      portfolios,
    ]);
 
 
  const columns = [
 
    {
      field: "portfolio_name",
      headerName: "Portfolio Name",
      width: 220,
    },
 
    {
      field: "asset_class_display",
      headerName: "Asset Class",
      width: 180,
    },
 
    {
      field: "target_percentage",
      headerName: "Target %",
      width: 120,
 
      valueFormatter: (value) =>
        value == null
          ? "-"
          : `${Number(value).toFixed(2)}%`,
    },
 
    {
      field: "current_percentage",
      headerName: "Current %",
      width: 120,
 
      valueFormatter: (value) =>
        value == null
          ? "-"
          : `${Number(value).toFixed(2)}%`,
    },
 
    {
      field: "deviation_percentage",
      headerName: "Deviation %",
      width: 130,
 
      valueFormatter: (value) => {
 
        if (
          value === null ||
          value === undefined
        ) {
          return "-";
        }
 
        const number =
          Number(value);
 
        return `${
          number > 0
            ? "+"
            : ""
        }${number.toFixed(2)}%`;
      },
    },
 
    {
      field: "recommendation",
      headerName: "Recommendation",
      width: 190,
 
      valueGetter: (
        value,
        row
      ) => {
 
        if (
          row.alert_message
        ) {
          return row.alert_message;
        }
 
        const deviation =
          Number(
            row.deviation_percentage || 0
          );
 
        if (
          deviation > 5
        ) {
          return "Reduce allocation";
        }
 
        if (
          deviation < -5
        ) {
          return "Increase allocation";
        }
 
        return "Within Range";
      },
    },
 
    {
      field: "alert_type",
      headerName: "Alert Type",
      width: 180,
 
      valueFormatter: (value) =>
        value || "ALLOCATION_DEVIATION",
    },
 
    {
      field: "status",
      headerName: "Status",
      width: 120,
 
      renderCell: (params) => (
 
        <Chip
 
          label={
            params.value
          }
 
          size="small"
 
          color={
            params.value === "ACTIVE"
              ? "error"
              : "default"
          }
 
        />
 
      ),
    },
 
    {
      field: "view",
      headerName: "Action",
      width: 120,
 
      sortable: false,
 
      filterable: false,
 
      renderCell: (params) => (
 
        <Button
 
          size="small"
 
          onClick={() =>
            navigate(
              `/portfolios/${params.row.portfolio_id}`
            )
          }
 
        >
          View
        </Button>
 
      ),
    },
 
  ];
 
 
  const activeCount =
    rows.filter(
      item =>
        item.status === "ACTIVE"
    ).length;
 
 
  if (loading) {
 
    return (
 
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          mt: 8,
        }}
      >
 
        <CircularProgress />
 
      </Box>
 
    );
 
  }
 
 
  return (
 
    <Box
      sx={{
        p: 4,
        minHeight: "100vh",
        backgroundColor: "#f5f6f8",
      }}
    >
 
      <Button
        onClick={() =>
          navigate("/portfolios")
        }
        sx={{
          mb: 2,
        }}
      >
        ← Back to Portfolios
      </Button>
 
 
      <Box
        sx={{
          display: "flex",
 
          justifyContent:
            "space-between",
 
          alignItems: "center",
 
          mb: 3,
        }}
      >
 
        <Box>
 
          <Typography
            variant="h4"
            fontWeight="bold"
          >
            Rebalancing Alerts
          </Typography>
 
          <Typography
            color="text.secondary"
          >
            Active Alerts:{" "}
            <strong>
              {activeCount}
            </strong>
          </Typography>
 
        </Box>
 
 
        <Button
          variant="outlined"
          onClick={
            loadData
          }
        >
          Refresh
        </Button>
 
      </Box>
 
 
      {error && (
 
        <Alert
          severity="error"
          sx={{
            mb: 2,
          }}
        >
          {error}
        </Alert>
 
      )}
 
 
      {rows.length === 0 ? (
 
        <Alert severity="success">
 
          No rebalancing alerts are currently active.
 
        </Alert>
 
      ) : (
 
        <Box
          sx={{
            height: 600,
            width: "100%",
            backgroundColor: "white",
          }}
        >
 
          <DataGrid
 
            rows={
              rows
            }
 
            columns={
              columns
            }
 
            getRowId={
              row =>
                row.alert_id
            }
 
            pageSizeOptions={[
              5,
              10,
              25,
              50,
            ]}
 
            initialState={{
              pagination: {
                paginationModel: {
                  page: 0,
                  pageSize: 10,
                },
              },
            }}
 
            disableRowSelectionOnClick
 
            showToolbar
 
          />
 
        </Box>
 
      )}
 
    </Box>
 
  );
 
}
 
 
export default AlertsPage;