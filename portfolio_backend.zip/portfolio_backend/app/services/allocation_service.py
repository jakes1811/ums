from app.repositories.portfolio_repository import (
    PortfolioRepository
)
 
from app.repositories.holding_repository import (
    HoldingRepository
)
 
from app.repositories.alert_repository import (
    AlertRepository
)
 
from app.services.ums_service import (
    UMSService
)
 
 
class AllocationService:
 
    ALERT_THRESHOLD = 5
 
 
    @staticmethod
    async def calculate_allocation(
        portfolio_id,
        valuation_date
    ):
 
        # ==================================================
        # PORTFOLIO
        # ==================================================
 
        portfolio = (
            PortfolioRepository
            .get_portfolio_by_id(
                portfolio_id
            )
        )
 
        if portfolio is None:
 
            raise ValueError(
                "Portfolio not found"
            )
 
 
        # ==================================================
        # HOLDINGS
        # ==================================================
 
        holdings = (
            HoldingRepository
            .get_holdings_by_portfolio(
                portfolio_id
            )
        )
 
 
        # ==================================================
        # TARGET ALLOCATION FROM UMS
        # ==================================================
 
        target_allocations = await (
            UMSService.get_theme_allocations(
                portfolio["theme_id"]
            )
        )
 
 
        # ==================================================
        # CURRENT VALUE GROUPED BY ASSET CLASS
        # ==================================================
 
        current_values = {}
 
        total_current_value = 0
 
 
        for holding in holdings:
 
            security = await (
                UMSService.get_security(
                    holding["security_id"]
                )
            )
 
 
            price = await (
                UMSService.get_security_price(
                    holding["security_id"],
                    valuation_date
                )
            )
 
 
            current_price = float(
                price["close_price"]
            )
 
            quantity = float(
                holding["quantity"]
            )
 
            current_value = (
                quantity
                *
                current_price
            )
 
 
            asset_class = (
                security["asset_class"]
            )
 
 
            current_values[
                asset_class
            ] = (
                current_values.get(
                    asset_class,
                    0
                )
                +
                current_value
            )
 
 
            total_current_value += (
                current_value
            )
 
 
        # ==================================================
        # CURRENT VS TARGET
        # ==================================================
 
        result = []
 
 
        for target in target_allocations:
 
            asset_class_id = (
                target[
                    "asset_class_id"
                ]
            )
 
            asset_class = (
                target[
                    "asset_class"
                ]
            )
 
            target_percentage = float(
                target[
                    "target_percentage"
                ]
            )
 
 
            current_value = (
                current_values.get(
                    asset_class,
                    0
                )
            )
 
 
            if total_current_value > 0:
 
                current_percentage = (
                    current_value
                    /
                    total_current_value
                    *
                    100
                )
 
            else:
 
                current_percentage = 0
 
 
            deviation = (
                current_percentage
                -
                target_percentage
            )
 
 
            # ==============================================
            # ALERT LOGIC
            # ==============================================
 
            alert_required = (
                abs(deviation)
                >
                AllocationService.ALERT_THRESHOLD
            )
 
 
            recommendation = None
 
 
            if alert_required:
 
                if deviation > 0:
 
                    recommendation = (
                        f"Reduce {asset_class} allocation"
                    )
 
                    alert_type = (
                        "OVER_ALLOCATED"
                    )
 
                else:
 
                    recommendation = (
                        f"Increase {asset_class} allocation"
                    )
 
                    alert_type = (
                        "UNDER_ALLOCATED"
                    )
 
 
                message = (
                    f"{asset_class} target is "
                    f"{target_percentage:.2f}% "
                    f"but current allocation is "
                    f"{current_percentage:.2f}%. "
                    f"Deviation is "
                    f"{deviation:+.2f}%."
                )
 
 
                existing_alert = (
                    AlertRepository
                    .get_active_alert(
                        portfolio_id,
                        asset_class_id
                    )
                )
 
 
                if existing_alert:
 
                    AlertRepository.update_alert(
                        existing_alert,
                        alert_type,
                        message,
                        target_percentage,
                        current_percentage,
                        deviation
                    )
 
                else:
 
                    AlertRepository.create_alert(
                        portfolio_id,
                        asset_class_id,
                        alert_type,
                        message,
                        target_percentage,
                        current_percentage,
                        deviation
                    )
 
 
            else:
 
                AlertRepository.resolve_alert(
                    portfolio_id,
                    asset_class_id
                )
 
 
            result.append({
 
                "asset_class_id":
                    asset_class_id,
 
                "asset_class":
                    asset_class,
 
                "current_value":
                    round(
                        current_value,
                        2
                    ),
 
                "current_percentage":
                    round(
                        current_percentage,
                        2
                    ),
 
                "target_percentage":
                    round(
                        target_percentage,
                        2
                    ),
 
                "deviation_percentage":
                    round(
                        deviation,
                        2
                    ),
 
                "alert":
                    alert_required,
 
                "recommendation":
                    recommendation
            })
 
 
        return {
 
            "portfolio_id":
                portfolio_id,
 
            "portfolio_name":
                portfolio[
                    "portfolio_name"
                ],
 
            "theme_id":
                portfolio[
                    "theme_id"
                ],
 
            "valuation_date":
                valuation_date,
 
            "total_current_value":
                round(
                    total_current_value,
                    2
                ),
 
            "alert_threshold":
                AllocationService
                .ALERT_THRESHOLD,
 
            "allocations":
                result
        }
 