from app.database.connection import get_db_connection
 
 
class SecurityRepository:
 
    @staticmethod
    def get_securities(
        page: int,
        page_size: int,
        search: str | None = None,
        exchange: str | None = None,
        asset_class: str | None = None,
        equity_category: str | None = None
    ):
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            conditions = []
            values = []
 
 
            # -----------------------------------------
            # SEARCH
            # -----------------------------------------
 
            if search:
 
                conditions.append("""
                    (
                        s.symbol ILIKE %s
                        OR
                        s.security_name ILIKE %s
                        OR
                        s.isin ILIKE %s
                        OR
                        s.security_code ILIKE %s
                    )
                """)
 
                search_value = f"%{search}%"
 
                values.extend([
                    search_value,
                    search_value,
                    search_value,
                    search_value
                ])
 
 
            # -----------------------------------------
            # EXCHANGE FILTER
            # -----------------------------------------
 
            if exchange:
 
                conditions.append(
                    "s.stock_exchange = %s"
                )
 
                values.append(exchange)
 
 
            # -----------------------------------------
            # ASSET CLASS FILTER
            # -----------------------------------------
 
            if asset_class:
 
                conditions.append(
                    "a.asset_class = %s"
                )
 
                values.append(asset_class)
 

            if equity_category:

                conditions.append(
                    "s.equity_category = %s"
                )

                values.append(equity_category)

            where_clause = ""

            if conditions:
                where_clause = (
                    " WHERE "
                    + " AND ".join(conditions)
                )

            # =========================================
            # COUNT QUERY
            # =========================================
 
            count_query = f"""
                SELECT COUNT(*)
 
                FROM unified_security_master s
 
                JOIN asset_class a
                ON a.asset_class_id =
                   s.asset_class_id
 
                LEFT JOIN gics g
                ON g.gics_id =
                   s.gics_id
 
                {where_clause};
            """
 
 
            cursor.execute(
                count_query,
                values
            )
 
            total = cursor.fetchone()[0]
 
 
            # =========================================
            # DATA QUERY
            # =========================================
 
            offset = (
                page - 1
            ) * page_size
 
 
            data_query = f"""
                SELECT
                    s.security_id,
                    s.isin,
                    s.symbol,
                    s.stock_exchange,
                    s.series,
                    s.security_code,
                    s.security_name,
                    s.country,
                    s.currency,
 
                    a.asset_class,
                    s.equity_category,
 
                    s.sector,
                    s.industry,
 
                    g.sector_name
                        AS gics_sector,
 
                    g.industry_name
                        AS gics_industry
 
                FROM unified_security_master s
 
                JOIN asset_class a
                ON a.asset_class_id =
                   s.asset_class_id
 
                LEFT JOIN gics g
                ON g.gics_id =
                   s.gics_id
 
                {where_clause}
 
                ORDER BY
                    s.security_id
 
                LIMIT %s
                OFFSET %s;
            """
 
 
            data_values = (
                values
                +
                [
                    page_size,
                    offset
                ]
            )
 
 
            cursor.execute(
                data_query,
                data_values
            )
 
 
            records = cursor.fetchall()
 
 
            securities = []
 
 
            for row in records:
 
                securities.append({
 
                    "security_id": row[0],
 
                    "isin": row[1],
 
                    "symbol": row[2],
 
                    "stock_exchange": row[3],
 
                    "series": row[4],
 
                    "security_code": row[5],
 
                    "security_name": row[6],
 
                    "country": row[7],
 
                    "currency": row[8],
 
                    "asset_class": row[9],
                    "equity_category": row[10],
 
                    "sector": row[11],
 
                    "industry": row[12],
 
                    "gics_sector": row[13],
 
                    "gics_industry": row[14]
                })
 
 
            return {
                "rows": securities,
                "total": total,
                "page": page,
                "page_size": page_size
            }
 
 
        finally:
 
            cursor.close()
            conn.close()

    @staticmethod
    def get_security_by_id(security_id: int):
        conn = get_db_connection()
        cursor = conn.cursor()

        try:
            cursor.execute(
                """
                SELECT
                    s.security_id,
                    s.isin,
                    s.symbol,
                    s.stock_exchange,
                    s.series,
                    s.description,
                    s.security_code,
                    s.security_name,
                    s.country,
                    s.currency,

                    a.asset_class,
                    a.sub_asset_class,
                    s.equity_category,

                    s.sector,
                    s.industry,

                    g.sector_name AS gics_sector,
                    g.industry_name AS gics_industry

                FROM unified_security_master s

                JOIN asset_class a
                ON a.asset_class_id = s.asset_class_id

                LEFT JOIN gics g
                ON g.gics_id = s.gics_id

                WHERE s.security_id = %s;
                """,
                (security_id,)
            )

            row = cursor.fetchone()

            if row is None:
                return None

            return {
                "security_id":      row[0],
                "isin":             row[1],
                "symbol":           row[2],
                "stock_exchange":   row[3],
                "series":           row[4],
                "description":      row[5],
                "security_code":    row[6],
                "security_name":    row[7],
                "country":          row[8],
                "currency":         row[9],
                "asset_class":      row[10],
                "sub_asset_class":  row[11],
                "equity_category":  row[12],
                "sector":           row[13],
                "industry":         row[14],
                "gics_sector":      row[15],
                "gics_industry":    row[16]
            }

        finally:
            cursor.close()
            conn.close()