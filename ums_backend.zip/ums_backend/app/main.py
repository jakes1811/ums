from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.database.init_db import create_ums_tables
from app.routers import ( securities, asset_classes, gics, benchmarks, themes, prices )

app = FastAPI(
    title="Unified Security Master (USM) API",
    version="1.0.0"
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173","http://localhost:5174",],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
create_ums_tables()  
app.include_router(securities.router)
app.include_router(asset_classes.router)
app.include_router(gics.router)
app.include_router(benchmarks.router)
app.include_router(themes.router)
app.include_router(prices.router)
@app.get("/")
def home():
    return {"message": "Welcome to the Unified Security Master (USM) API!"}
