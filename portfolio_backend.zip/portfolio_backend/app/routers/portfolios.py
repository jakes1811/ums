from fastapi import (
    APIRouter,
    HTTPException,
    Query
)
 
from pydantic import (
    BaseModel,
    Field
)
 
import httpx
from datetime import date
from app.services.portfolio_service import PortfolioService
from app.services.valuation_service import ValuationService
from app.services.allocation_service import AllocationService
from app.services.performance_service import PerformanceService
router = APIRouter(
    prefix="/portfolios",
    tags=["Portfolios"]
)
 
 
class PortfolioCreate(BaseModel):
 
    portfolio_name: str
 
    portfolio_type: str | None = None
    fun_manager_name: str | None = None
 
    exchange: str
 
    theme_id: int
 
    rebalancing_frequency: str | None = None
 
    amount: float = Field(
        default=0,
        ge=0
    )
 
 
@router.post("")
async def create_portfolio(
    data: PortfolioCreate
):
 
    try:
 
        return await (
            PortfolioService
            .create_portfolio(
                data.model_dump()
            )
        )
 
 
    except ValueError as error:
 
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )
 
 
    except httpx.HTTPError:
 
        raise HTTPException(
            status_code=502,
            detail=
            "Unable to communicate with UMS API"
        )
 
 
# =====================================================
# LIST PORTFOLIOS
# =====================================================
 
@router.get("")
async def get_portfolios():
 
    try:
 
        return await (
            PortfolioService
            .get_all_portfolios()
        )
 
    except httpx.HTTPError:
 
        raise HTTPException(
            status_code=502,
            detail=
            "Unable to communicate with UMS API"
        )
 
 
# =====================================================
# GET ONE PORTFOLIO
# =====================================================
 
@router.get("/{portfolio_id}")
async def get_portfolio(
    portfolio_id: int
):
 
    portfolio = await (
        PortfolioService
        .get_portfolio_by_id(
            portfolio_id
        )
    )
 
 
    if portfolio is None:
 
        raise HTTPException(
            status_code=404,
            detail="Portfolio not found"
        )
 
 
    return portfolio

#delete portfolio
@router.delete("/{portfolio_id}")
def delete_portfolio(portfolio_id:int):
    try:
        return(PortfolioService.delete_portfolio(portfolio_id))
    except ValueError as error:
        raise HTTPException(status_code=400,detail=str(error))

@router.put("/{portfolio_id}/activate")
def activate_portfolio(
    portfolio_id: int
):
 
    try:
 
        return (
            PortfolioService
            .activate_portfolio(
                portfolio_id
            )
        )
 
    except ValueError as error:
 
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )
 
@router.put(
    "/{portfolio_id}/close"
)
def close_portfolio(
    portfolio_id: int
):
 
    try:
 
        return (
            PortfolioService
            .close_portfolio(
                portfolio_id
            )
        )
 
    except ValueError as error:
 
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )

@router.get("/{portfolio_id}/valuation")
async def get_portfolio_valuation( portfolio_id: int, valuation_date: date):  
    try:
        return await (ValuationService.get_portfolio_valuation(portfolio_id,valuation_date))
    except ValueError as error:
        raise HTTPException(status_code=400,detail=str(error))
    except httpx.HTTPError as error:
        if(error.response.status_code == 404):
            raise HTTPException(status_code=404,detail="Market price not found for the given date")
        raise HTTPException(status_code=502,detail="Unable to fetch price from UMS")
    except httpx.RequestError as error:
        raise HTTPException(status_code=502,detail="Unable to communicate with UMS API")

@router.get("/{portfolio_id}/allocation")
async def get_portfolio_allocation(portfolio_id: int, valuation_date: date = Query(...)):
    try:
        return await (AllocationService.calculate_allocation(portfolio_id,valuation_date))
    except ValueError as error:
        raise HTTPException(status_code=400,detail=str(error))
    except httpx.HTTPError as error:
        raise HTTPException(status_code=502,detail="Unable to communicate with UMS API")

@router.get("/{portfolio_id}/performance")
async def get_portfolio_performance(portfolio_id: int, valuation_date: date = Query(...)):
    try:
        return await (PerformanceService.get_performance(portfolio_id,valuation_date))
    except ValueError as error:
        raise HTTPException(status_code=400,detail=str(error))
    except httpx.HTTPError as error:
        raise HTTPException(status_code=502,detail="Unable to communicate with UMS API")