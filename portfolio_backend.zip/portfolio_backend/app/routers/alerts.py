from fastapi import APIRouter, HTTPException
from app.repositories.alert_repository import AlertRepository

router = APIRouter( prefix="/alerts", tags=["Alerts"] )
@router.get("")
def get_alerts():
    try:
        return AlertRepository.get_alerts()
    except Exception as error:
        raise HTTPException(status_code=500, detail="Unable to fetch alerts from the database")