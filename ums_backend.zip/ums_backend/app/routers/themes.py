from fastapi import (
    APIRouter,
    HTTPException
)
 
from pydantic import BaseModel
from typing import List, Optional

from app.repositories.master_repository import (
    MasterRepository
)
 
 
router = APIRouter(
    prefix="/themes",
    tags=["Investment Themes"]
)
 
 
class ThemeRequest(BaseModel):
 
    theme_name: str
 
    description: str | None = None
 
    risk_level: str | None = None
 
    investment_horizon: str | None = None
 
    status: str = "ACTIVE"
 
class AllocationItem(BaseModel):
 
    asset_class_id: int
 
    target_percentage: float

@router.get("")
def get_themes():
 
    return MasterRepository.get_themes()
 
 
@router.post("")
def create_theme(
    data: ThemeRequest
):
 
    return MasterRepository.create_theme(
        data.model_dump()
    )
 
 
@router.put("/{theme_id}")
def update_theme(
    theme_id: int,
    data: ThemeRequest
):
 
    updated = MasterRepository.update_theme(
        theme_id,
        data.model_dump()
    )
 
    if updated == 0:
 
        raise HTTPException(
            status_code=404,
            detail="Theme not found"
        )
 
    return {
        "message":
        "Theme updated successfully"
    }
 
 
@router.get("/{theme_id}/allocations")
def get_theme_allocations(
    theme_id: int
):
 
    return MasterRepository.get_theme_allocations(
        theme_id
    )

@router.put("/{theme_id}/allocations")
def save_theme_allocations(
    theme_id: int,
    allocations: List[AllocationItem]
):
 
    # -----------------------------------------
    # Validate each percentage
    # -----------------------------------------
 
    for allocation in allocations:
 
        if (
            allocation.target_percentage < 0
            or
            allocation.target_percentage > 100
        ):
 
            raise HTTPException(
                status_code=400,
                detail=
                "Target percentage must be between 0 and 100"
            )
 
 
    # -----------------------------------------
    # Validate total = 100
    # -----------------------------------------
 
    total = sum(
        item.target_percentage
        for item in allocations
    )
 
 
    if round(total, 2) != 100:
 
        raise HTTPException(
            status_code=400,
            detail=
            f"Total allocation must be 100%. Current total is {total}%"
        )
 
 
    saved = (
        MasterRepository.save_theme_allocations(
            theme_id,
            [
                item.model_dump()
                for item in allocations
            ]
        )
    )
 
 
    if not saved:
 
        raise HTTPException(
            status_code=404,
            detail="Theme not found"
        )
 
 
    return {
        "message":
        "Theme allocation saved successfully",
 
        "total_percentage":
        total
    }