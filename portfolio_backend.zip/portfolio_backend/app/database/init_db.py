from app.database.connection import get_db_connection
 
 
def create_portfolio_tables():
 
    conn = get_db_connection()
    cursor = conn.cursor()
 
    try:
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS portfolio_details (
 
                portfolio_id SERIAL PRIMARY KEY,
 
                portfolio_name VARCHAR(150)
                    NOT NULL,
 
                portfolio_type VARCHAR(100),
 
                currency VARCHAR(10)
                    NOT NULL,
 
                exchange VARCHAR(50)
                    NOT NULL,
 
                benchmark_id INTEGER
                    NOT NULL,
 
                rebalancing_frequency VARCHAR(50),
 
                amount NUMERIC(18,2)
                    DEFAULT 0,
 
                status VARCHAR(20)
                    NOT NULL
                    DEFAULT 'NEW',
 
                theme_id INTEGER
                    NOT NULL,
 
                CONSTRAINT fk_portfolio_benchmark
                    FOREIGN KEY (benchmark_id)
                    REFERENCES benchmark(benchmark_id),
 
                CONSTRAINT fk_portfolio_theme
                    FOREIGN KEY (theme_id)
                    REFERENCES investment_theme(theme_id),
 
                CONSTRAINT check_portfolio_status
                    CHECK (
                        status IN ('NEW', 'ACTIVE', 'CLOSED')
                    )
            );
        """)

        cursor.execute("""
            ALTER TABLE portfolio_details
            DROP CONSTRAINT IF EXISTS check_portfolio_status;
        """)

        cursor.execute("""
            ALTER TABLE portfolio_details
            ADD CONSTRAINT check_portfolio_status
            CHECK (status IN ('NEW', 'ACTIVE', 'CLOSED'));
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS assets_and_holdings (
 
                asset_holding_id SERIAL PRIMARY KEY,
 
                portfolio_id INTEGER
                    NOT NULL,
 
                security_id BIGINT
                    NOT NULL,
 
                quantity NUMERIC(18,4)
                    NOT NULL,
 
                security_price NUMERIC(18,4)
                    NOT NULL,
 
                total_value NUMERIC(18,2)
                    NOT NULL,
 
                CONSTRAINT fk_holding_portfolio
                    FOREIGN KEY (portfolio_id)
                    REFERENCES portfolio_details(portfolio_id)
                    ON DELETE CASCADE,
 
                CONSTRAINT fk_holding_security
                    FOREIGN KEY (security_id)
                    REFERENCES unified_security_master(security_id),
 
                CONSTRAINT check_quantity
                    CHECK (quantity > 0),
 
                CONSTRAINT unique_portfolio_security
                    UNIQUE (portfolio_id, security_id)
            );
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS alerts (
 
                alert_id SERIAL PRIMARY KEY,
 
                portfolio_id INTEGER
                    NOT NULL,
 
                asset_class_id INTEGER
                    NOT NULL,
 
                alert_type VARCHAR(100),
 
                alert_message TEXT,
 
                target_percentage NUMERIC(7,2),
 
                current_percentage NUMERIC(7,2),
 
                deviation_percentage NUMERIC(7,2),
 
                status VARCHAR(20)
                    DEFAULT 'ACTIVE',
 
                CONSTRAINT fk_alert_portfolio
                    FOREIGN KEY (portfolio_id)
                    REFERENCES portfolio_details(portfolio_id)
                    ON DELETE CASCADE,
 
                CONSTRAINT fk_alert_asset_class
                    FOREIGN KEY (asset_class_id)
                    REFERENCES asset_class(asset_class_id),
 
                CONSTRAINT check_alert_status
                    CHECK (
                        status IN ('ACTIVE', 'RESOLVED')
                    )
            );
        """)
 
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS
            idx_holdings_portfolio
 
            ON assets_and_holdings(portfolio_id);
        """)
 
 
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS
            idx_holdings_security
 
            ON assets_and_holdings(security_id);
        """)
 
 
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS
            idx_alerts_portfolio
 
            ON alerts(portfolio_id);
        """)
 
 
        conn.commit()
 
        print(
            "Portfolio tables created successfully"
        )
 
 
    except Exception as error:
 
        conn.rollback()
 
        print(
            "Error creating Portfolio tables:"
        )
 
        print(error)
 
        raise
 
 
    finally:
 
        cursor.close()
        conn.close()