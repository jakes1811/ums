from fastapi import APIRouter
 
from app.repositories.master_repository import (
    MasterRepository
)
 
 
router = APIRouter(
    prefix="/gics",
    tags=["GICS"]
)
 
 
@router.get("")
def get_gics():
 
    return MasterRepository.get_gics()