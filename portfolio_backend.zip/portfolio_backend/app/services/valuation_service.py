from datetime import date
 
from app.repositories.portfolio_repository import (
    PortfolioRepository
)
 
from app.repositories.holding_repository import (
    HoldingRepository
)
 
from app.services.ums_service import (
    UMSService
)
 
 
class ValuationService:
 
    @staticmethod
    async def get_portfolio_valuation(
        portfolio_id: int,
        valuation_date: date
    ):
 
        # ==========================================
        # 1. GET PORTFOLIO
        # ==========================================
 
        portfolio = (
            PortfolioRepository
            .get_portfolio_by_id(
                portfolio_id
            )
        )
 
 
        if portfolio is None:
 
            raise ValueError(
                "Portfolio not found"
            )
 
 
        # ==========================================
        # 2. GET HOLDINGS
        # ==========================================
 
        holdings = (
            HoldingRepository
            .get_holdings_by_portfolio(
                portfolio_id
            )
        )
 
 
        valuation_rows = []
 
        total_invested_value = 0
 
        total_current_value = 0
 
 
        # ==========================================
        # 3. VALUE EACH HOLDING
        # ==========================================
 
        for holding in holdings:
 
            security_id = (
                holding["security_id"]
            )
 
            quantity = float(
                holding["quantity"]
            )
 
            buy_price = float(
                holding["security_price"]
            )
 
            invested_value = float(
                holding["total_value"]
            )
 
 
            # --------------------------------------
            # SECURITY DETAILS FROM UMS
            # --------------------------------------
 
            security = await (
                UMSService.get_security(
                    security_id
                )
            )
 
 
            # --------------------------------------
            # SELECTED DATE PRICE FROM UMS
            # --------------------------------------
 
            price_data = await (
                UMSService.get_security_price(
                    security_id,
                    valuation_date
                )
            )
 
 
            current_price = float(
                price_data["close_price"]
            )
 
 
            # --------------------------------------
            # CURRENT VALUE
            # --------------------------------------
 
            current_value = (
                quantity
                *
                current_price
            )
 
 
            # --------------------------------------
            # PROFIT / LOSS
            # --------------------------------------
 
            profit_loss = (
                current_value
                -
                invested_value
            )
 
 
            if invested_value > 0:
 
                return_percentage = (
                    profit_loss
                    /
                    invested_value
                    *
                    100
                )
 
            else:
 
                return_percentage = 0
 
 
            total_invested_value += (
                invested_value
            )
 
            total_current_value += (
                current_value
            )
 
 
            valuation_rows.append({
 
                "asset_holding_id":
                    holding[
                        "asset_holding_id"
                    ],
 
                "security_id":
                    security_id,
 
                "symbol":
                    security["symbol"],
 
                "security_name":
                    security[
                        "security_name"
                    ],
 
                "asset_class":
                    security[
                        "asset_class"
                    ],
 
                "quantity":
                    quantity,
 
                "buy_price":
                    round(
                        buy_price,
                        4
                    ),
 
                "current_price":
                    round(
                        current_price,
                        4
                    ),
 
                "invested_value":
                    round(
                        invested_value,
                        2
                    ),
 
                "current_value":
                    round(
                        current_value,
                        2
                    ),
 
                "profit_loss":
                    round(
                        profit_loss,
                        2
                    ),
 
                "return_percentage":
                    round(
                        return_percentage,
                        2
                    )
            })
 
 
        # ==========================================
        # 4. PORTFOLIO TOTAL P/L
        # ==========================================
 
        total_profit_loss = (
            total_current_value
            -
            total_invested_value
        )
 
 
        if total_invested_value > 0:
 
            portfolio_return = (
                total_profit_loss
                /
                total_invested_value
                *
                100
            )
 
        else:
 
            portfolio_return = 0
 
 
        # ==========================================
        # 5. RESPONSE
        # ==========================================
 
        return {
 
            "portfolio_id":
                portfolio_id,
 
            "portfolio_name":
                portfolio[
                    "portfolio_name"
                ],
 
            "exchange":
                portfolio[
                    "exchange"
                ],
 
            "currency":
                portfolio[
                    "currency"
                ],
 
            "status":
                portfolio[
                    "status"
                ],
 
            "valuation_date":
                valuation_date,
 
            "total_invested_value":
                round(
                    total_invested_value,
                    2
                ),
 
            "total_current_value":
                round(
                    total_current_value,
                    2
                ),
 
            "total_profit_loss":
                round(
                    total_profit_loss,
                    2
                ),
 
            "portfolio_return_percentage":
                round(
                    portfolio_return,
                    2
                ),
 
            "holdings":
                valuation_rows
        }
 