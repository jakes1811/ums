import httpx
 
from fastapi import (
    APIRouter,
    HTTPException
)
 
from pydantic import (
    BaseModel,
    Field
)
 
from app.services.holding_service import (
    HoldingService
)
from datetime import date
from app.repositories.transaction_repository import TransactionRepository

router = APIRouter(
    prefix="/portfolios",
    tags=["Holdings"]
)
 
 
class HoldingCreate(BaseModel):
 
    security_id: int
 
    quantity: float = Field(
        gt=0
    )

class BuyMoreRequest(BaseModel):
    quantity: float = Field(gt=0)
    purchase_date: date

class SellRequest(BaseModel):
    quantity: float = Field(gt=0)
    sell_date: date
 
@router.post(
    "/{portfolio_id}/holdings"
)
async def add_holding(
    portfolio_id: int,
    data: HoldingCreate
):
 
    try:
 
        return await (
            HoldingService.add_holding(
 
                portfolio_id=
                    portfolio_id,
 
                security_id=
                    data.security_id,
 
                quantity=
                    data.quantity
            )
        )
 
 
    except ValueError as error:
 
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )
 
 
    except httpx.HTTPError:
 
        raise HTTPException(
            status_code=502,
            detail=
            "Unable to communicate with UMS API"
        )

 
@router.get(
    "/{portfolio_id}/holdings"
)
async def get_holdings(
    portfolio_id: int
):
 
    try:
 
        return await (
            HoldingService
            .get_holdings(
                portfolio_id
            )
        )
 
    except ValueError as error:
 
        raise HTTPException(
            status_code=404,
            detail=str(error)
        )
 
@router.post(
    "/{portfolio_id}/holdings/{holding_id}/buy-more"
)
async def buy_more(
    portfolio_id: int,
    holding_id: int,
    data: BuyMoreRequest
):
 
    try:
 
        return await (
            HoldingService.buy_more(
                portfolio_id=
                    portfolio_id,
 
                holding_id=
                    holding_id,
 
                quantity=
                    data.quantity,
 
                purchase_date=
                    data.purchase_date
            )
        )
 
    except ValueError as error:
 
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )
 
    except httpx.HTTPError:
 
        raise HTTPException(
            status_code=502,
            detail=
            "Unable to fetch market price"
        )
 
 
# =====================================================
# SELL
# =====================================================
 
@router.post(
    "/{portfolio_id}/holdings/{holding_id}/sell"
)
async def sell_holding(
    portfolio_id: int,
    holding_id: int,
    data: SellRequest
):
 
    try:
 
        return await (
            HoldingService.sell_holding(
                portfolio_id=
                    portfolio_id,
 
                holding_id=
                    holding_id,
 
                quantity=
                    data.quantity,
 
                sell_date=
                    data.sell_date
            )
        )
 
    except ValueError as error:
 
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )
 
    except httpx.HTTPError:
 
        raise HTTPException(
            status_code=502,
            detail=
            "Unable to fetch market price"
        )

 
@router.delete(
    "/{portfolio_id}/holdings/{holding_id}"
)
async def delete_holding(
    portfolio_id: int,
    holding_id: int
):
 
    try:
 
        return  await (
            HoldingService.delete_holding(
                portfolio_id=
                    portfolio_id,
 
                holding_id=
                    holding_id
            )
        )
 
    except ValueError as error:
 
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )