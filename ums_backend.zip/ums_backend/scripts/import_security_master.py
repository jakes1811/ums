import csv
from pathlib import Path
from app.database.connection import get_db_connection
BATCH_SIZE = 500
def import_security_master(): 
    project_folder = Path(__file__).resolve().parents[2]

    csv_file = (
        project_folder
        / "data"
        / "unified_security_master_mock.csv"
    )
    if not csv_file.exists():
        print("CSV file not found:")
        print(csv_file)
        return
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""SELECT asset_class_id, asset_class FROM asset_class;""") 
        asset_class_lookup = {}
        for row in cursor.fetchall():
            asset_class_id = row[0]
            asset_class_name = row[1]
            asset_class_lookup[asset_class_name.strip().lower()] = asset_class_id
        cursor.execute("""SELECT gics_id, sector_code FROM gics;""")
        gics_lookup = {}
        for row in cursor.fetchall():
            gics_id = row[0]
            sector_code = row[1]
            if sector_code:
                gics_lookup[sector_code.strip()] = gics_id
        rows_to_insert = []
        missing_asset_classes = set()
        missing_gics_codes = set()
        with open(csv_file,"r", encoding="utf-8-sig" ) as file:
            reader = csv.DictReader(file)
            for row in reader:
                asset_class_name = (row["asset_class"].strip())
                asset_class_id = (asset_class_lookup.get(asset_class_name.lower()))
                if asset_class_id is None:
                    missing_asset_classes.add(asset_class_name)
                    continue
                sector_code = (row.get("sector_code", "").strip())
                gics_id = None
                if (sector_code and sector_code != "0"):
                    gics_id = (gics_lookup.get(sector_code))
                    if gics_id is None:
                        missing_gics_codes.add(sector_code)
                        continue
                rows_to_insert.append(
                    (
                        int(row["security_id"]),
                        row["isin"].strip(),
                        row["symbol"].strip(),
                        row["stock_exchange"].strip(),
                        row["series"].strip(),
                        row["description"].strip(),
                        row["security_code"].strip(),
                        row["security_name"].strip(),
                        row["country"].strip(),
                        row["currency"].strip(),
                        row["sector"].strip(),
                        row["industry"].strip(),
                        gics_id,
                        asset_class_id,
                        row["equity_category"].strip()
                    )
                )
        if missing_asset_classes:
            print(
                "Missing Asset Classes:",
                missing_asset_classes
            )
            raise Exception(
                "Some Asset Classes could not be mapped"
            )
        if missing_gics_codes:
            print(
                "Missing GICS codes:",
                missing_gics_codes
            )
            raise Exception(
                "Some GICS codes could not be mapped"
            )
        print(
            "Rows ready for import:",
            len(rows_to_insert)
        )
        insert_query = """
            INSERT INTO unified_security_master
            (
                security_id,
                isin,
                symbol,
                stock_exchange,
                series,
                description,
                security_code,
                security_name,
                country,
                currency,
                sector,
                industry,
                gics_id,
                asset_class_id,
                equity_category
            )
            VALUES
            (
                %s, %s, %s, %s, %s, %s, %s,
                %s, %s, %s, %s, %s, %s, %s, %s
            )
            ON CONFLICT (security_id)
            DO UPDATE SET
                isin = EXCLUDED.isin,
                symbol = EXCLUDED.symbol,
                stock_exchange = EXCLUDED.stock_exchange,
                series = EXCLUDED.series,
                description = EXCLUDED.description,
                security_code = EXCLUDED.security_code,
                security_name = EXCLUDED.security_name,
                country = EXCLUDED.country,
                currency = EXCLUDED.currency,
                sector = EXCLUDED.sector,
                industry = EXCLUDED.industry,
                gics_id = EXCLUDED.gics_id,
                asset_class_id = EXCLUDED.asset_class_id,
                equity_category = EXCLUDED.equity_category;
        """
        total_inserted = 0
        for start in range(0, len(rows_to_insert),BATCH_SIZE):
            batch = rows_to_insert[
                start:
                start + BATCH_SIZE
            ]
            cursor.executemany( insert_query, batch) 
            total_inserted += len(batch) 
            print(f"Processed {total_inserted} securities")
        cursor.execute("""
            SELECT setval(
                pg_get_serial_sequence(
                    'unified_security_master',
                    'security_id'
                ),
                (
                    SELECT MAX(security_id)
                    FROM unified_security_master
                ),
                true
            );
        """)
        conn.commit()
        cursor.execute(""" SELECT COUNT(*) FROM unified_security_master;""")
        total_count = cursor.fetchone()[0]
        cursor.execute("""
            SELECT
                stock_exchange,
                COUNT(*)
            FROM unified_security_master
            GROUP BY stock_exchange
            ORDER BY stock_exchange;
        """)
        exchange_counts = cursor.fetchall()
        print()
        print("----------------------------------")
        print("SECURITY MASTER IMPORT COMPLETE")
        print("----------------------------------")
        print( "Total securities:", total_count)
        print()
        for exchange, count in exchange_counts:
            print(exchange,":",count)
    except Exception as error:
        conn.rollback()
        print()
        print("Security Master import failed:")
        print(error)
        raise error
    finally:
        cursor.close()
        conn.close()
if __name__ == "__main__":
    import_security_master()
 