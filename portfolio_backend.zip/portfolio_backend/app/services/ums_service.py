import os
 
import httpx
from dotenv import load_dotenv
 
 
load_dotenv()
 
 
UMS_API_URL = os.getenv(
    "UMS_API_URL",
    "http://127.0.0.1:8000"
)
 
 
class UMSService:
 
    # ==========================================
    # GET THEMES
    # ==========================================
 
    @staticmethod
    async def get_themes():
 
        async with httpx.AsyncClient() as client:
 
            response = await client.get(
                f"{UMS_API_URL}/themes"
            )
 
            response.raise_for_status()
 
            return response.json()
 
 
    # ==========================================
    # GET THEME ALLOCATION
    # ==========================================
 
    @staticmethod
    async def get_theme_allocations(
        theme_id: int
    ):
 
        async with httpx.AsyncClient() as client:
 
            response = await client.get(
                f"{UMS_API_URL}/themes/{theme_id}/allocations"
            )
 
            response.raise_for_status()
 
            return response.json()
 
 
    # ==========================================
    # GET BENCHMARKS
    # ==========================================
 
    @staticmethod
    async def get_benchmarks():
 
        async with httpx.AsyncClient() as client:
 
            response = await client.get(
                f"{UMS_API_URL}/benchmarks"
            )
 
            response.raise_for_status()
 
            return response.json()
 
 
    # ==========================================
    # GET SECURITIES
    # ==========================================
 
    @staticmethod
    async def get_securities(
        exchange=None,
        search=None,
        asset_class=None,
        equity_category=None,
        page=1,
        page_size=50
    ):

        params = {
            "page": page,
            "page_size": page_size
        }

        if exchange:
            params["exchange"] = exchange

        if search:
            params["search"] = search

        if asset_class:
            params["asset_class"] = asset_class

        if equity_category:
            params["equity_category"] = equity_category

        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{UMS_API_URL}/securities",
                params=params
            )

            response.raise_for_status()

            return response.json()
 
 
    # ==========================================
    # GET ONE SECURITY
    # ==========================================
 
    @staticmethod
    async def get_security(
        security_id: int
    ):
 
        async with httpx.AsyncClient() as client:
 
            response = await client.get(
                f"{UMS_API_URL}/securities/{security_id}"
            )
 
            response.raise_for_status()
 
            return response.json()
 
 
    # ==========================================
    # GET SECURITY PRICE FOR DATE
    # ==========================================
 
    @staticmethod
    async def get_security_price(
        security_id: int,
        valuation_date
    ):
 
        async with httpx.AsyncClient() as client:
 
            response = await client.get(
                f"{UMS_API_URL}/securities/{security_id}/price",
                params={
                    "date": valuation_date
                }
            )
 
            response.raise_for_status()
 
            return response.json()