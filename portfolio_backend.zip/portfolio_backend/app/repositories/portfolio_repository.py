from app.database.connection import get_db_connection

class PortfolioRepository:

    @staticmethod
    def create_portfolio(
        portfolio_name,
        portfolio_type,
        fund_manager_name,
        currency,
        exchange,
        benchmark_id,
        rebalancing_frequency,
        amount,
        theme_id
    ):
        conn = get_db_connection()
        cursor = conn.cursor()

        try:
            cursor.execute(
                """
                INSERT INTO portfolio_details
                (
                    portfolio_name,
                    portfolio_type,
                    fund_manager_name,
                    currency,
                    exchange,
                    benchmark_id,
                    rebalancing_frequency,
                    amount,
                    status,
                    theme_id
                )
                VALUES
                (
                    %s, %s, %s, %s, %s,
                    %s, %s, %s, 'NEW', %s
                )
                RETURNING portfolio_id;
                """,
                (
                    portfolio_name,
                    portfolio_type,
                    fund_manager_name,
                    currency,
                    exchange,
                    benchmark_id,
                    rebalancing_frequency,
                    amount,
                    theme_id
                )
            )

            portfolio_id = cursor.fetchone()[0]

            conn.commit()

            return portfolio_id

        except Exception:
            conn.rollback()
            raise

        finally:
            cursor.close()
            conn.close()


    @staticmethod
    def get_all_portfolios():
        conn = get_db_connection()
        cursor = conn.cursor()

        try:
            cursor.execute(
                """
                SELECT
                    portfolio_id,
                    portfolio_name,
                    portfolio_type,
                    fund_manager_name,
                    currency,
                    exchange,
                    benchmark_id,
                    rebalancing_frequency,
                    amount,
                    status,
                    theme_id
                FROM portfolio_details
                ORDER BY portfolio_id DESC;
                """
            )

            rows = cursor.fetchall()

            return [
                {
                    "portfolio_id": row[0],
                    "portfolio_name": row[1],
                    "portfolio_type": row[2],
                    "fund_manager_name": row[3],
                    "currency": row[4],
                    "exchange": row[5],
                    "benchmark_id": row[6],
                    "rebalancing_frequency": row[7],
                    "amount": float(row[8] or 0),
                    "status": row[9],
                    "theme_id": row[10]
                }
                for row in rows
            ]

        finally:
            cursor.close()
            conn.close()


    @staticmethod
    def get_portfolio_by_id(
        portfolio_id
    ):
        conn = get_db_connection()
        cursor = conn.cursor()

        try:
            cursor.execute(
                """
                SELECT
                    portfolio_id,
                    portfolio_name,
                    portfolio_type,
                    fund_manager_name,
                    currency,
                    exchange,
                    benchmark_id,
                    rebalancing_frequency,
                    amount,
                    status,
                    theme_id
                FROM portfolio_details
                WHERE portfolio_id = %s;
                """,
                (portfolio_id,)
            )

            row = cursor.fetchone()

            if row is None:
                return None

            return {
                "portfolio_id": row[0],
                "portfolio_name": row[1],
                "portfolio_type": row[2],
                "fund_manager_name": row[3],
                "currency": row[4],
                "exchange": row[5],
                "benchmark_id": row[6],
                "rebalancing_frequency": row[7],
                "amount": float(row[8] or 0),
                "status": row[9],
                "theme_id": row[10]
            }

        finally:
            cursor.close()
            conn.close()


    @staticmethod
    def delete_portfolio(
        portfolio_id: int
    ):
        conn = get_db_connection()
        cursor = conn.cursor()

        try:
            cursor.execute(
                """
                DELETE FROM portfolio_details
                WHERE portfolio_id = %s;
                """,
                (portfolio_id,)
            )

            conn.commit()

            return cursor.rowcount

        except Exception:
            conn.rollback()
            raise

        finally:
            cursor.close()
            conn.close()


    @staticmethod
    def update_status(
        portfolio_id: int,
        status: str
    ):
        conn = get_db_connection()
        cursor = conn.cursor()

        try:
            cursor.execute(
                """
                UPDATE portfolio_details
                SET status = %s
                WHERE portfolio_id = %s;
                """,
                (
                    status,
                    portfolio_id
                )
            )

            updated = cursor.rowcount

            conn.commit()

            return updated

        except Exception:
            conn.rollback()
            raise

        finally:
            cursor.close()
            conn.close()


    @staticmethod
    def update_amount(
        portfolio_id: int,
        amount
    ):
        conn = get_db_connection()
        cursor = conn.cursor()

        try:
            cursor.execute(
                """
                UPDATE portfolio_details
                SET amount = %s
                WHERE portfolio_id = %s;
                """,
                (
                    amount,
                    portfolio_id
                )
            )

            conn.commit()

        except Exception:
            conn.rollback()
            raise

        finally:
            cursor.close()
            conn.close()
            
