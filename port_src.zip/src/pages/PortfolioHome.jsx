import {
  useEffect,
  useState,
} from "react";

import {
  Badge,
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  Divider,
  IconButton,
  Stack,
  Tooltip,
  Typography,
} from "@mui/material";

import {
  DataGrid,
} from "@mui/x-data-grid";

import AddIcon
  from "@mui/icons-material/Add";

import NotificationsIcon
  from "@mui/icons-material/Notifications";

import VisibilityIcon
  from "@mui/icons-material/Visibility";

import RefreshIcon
  from "@mui/icons-material/Refresh";

import ArrowForwardIcon
  from "@mui/icons-material/ArrowForward";

import AccountBalanceWalletOutlinedIcon
  from "@mui/icons-material/AccountBalanceWalletOutlined";

import TrendingUpOutlinedIcon
  from "@mui/icons-material/TrendingUpOutlined";

import WarningAmberOutlinedIcon
  from "@mui/icons-material/WarningAmberOutlined";

import DeleteOutlinedIcon
  from "@mui/icons-material/DeleteOutlined";

import {
  useNavigate,
} from "react-router-dom";

import {
  getAlerts,
  getPortfolios,
  deletePortfolio
} from "../api/api";

import CreatePortfolioDialog
  from "../components/CreatePortfolioDialog";

import "./PortfolioHome.css";


function PortfolioHome() {

  const navigate = useNavigate();

  const [rows, setRows] = useState([]);

  const [loading, setLoading] =
    useState(false);

  const [alerts, setAlerts] =
    useState([]);

  const [createOpen, setCreateOpen] =
    useState(false);


  // ====================================================
  // LOAD PORTFOLIOS
  // ====================================================

  async function loadPortfolios() {

    try {

      setLoading(true);

      const data =
        await getPortfolios();

      setRows(data);

    }
    catch (error) {

      console.error(
        "Portfolio loading error:",
        error
      );

    }
    finally {

      setLoading(false);

    }

  }


  //delete
  async function handleDeletePortfolio(
  portfolioId,
  portfolioName
) {
  const confirmed = window.confirm(
    `Are you sure you want to delete "${portfolioName}"?\n\nThis action cannot be undone.`
  );

  if (!confirmed) {
    return;
  }

  try {
    setLoading(true);

    await deletePortfolio(portfolioId);

    await loadPortfolios();
    await loadAlerts();

  } catch (error) {
    console.error(
      "Portfolio deletion error:",
      error
    );

    window.alert(
      "Failed to delete portfolio."
    );

  } finally {
    setLoading(false);
  }
}


  // ====================================================
  // LOAD ALERTS
  // ====================================================

  async function loadAlerts() {

    try {

      const data =
        await getAlerts();

      setAlerts(data);

    }
    catch (error) {

      console.error(
        "Alert loading error:",
        error
      );

    }

  }


  // ====================================================
  // INITIAL LOAD
  // ====================================================

  useEffect(() => {

    loadPortfolios();

    loadAlerts();

  }, []);


  // ====================================================
  // ACTIVE ALERT COUNT
  // ====================================================

  const activeAlertCount =
    alerts.filter(
      (alert) =>
        alert.status === "ACTIVE"
    ).length;


  // ====================================================
  // DASHBOARD VALUES
  // ====================================================

  const activePortfolioCount =
    rows.filter(
      (portfolio) =>
        portfolio.status === "ACTIVE"
    ).length;


  const totalInvested =
    rows.reduce(
      (total, portfolio) =>
        total +
        Number(
          portfolio.amount || 0
        ),
      0
    );


  const formatCurrency = (value) => {

    return `₹${Number(
      value || 0
    ).toLocaleString("en-IN", {
      minimumFractionDigits: 0,
      maximumFractionDigits: 2,
    })}`;

  };


  // ====================================================
  // DATA GRID COLUMNS
  // ====================================================

  const columns = [

    {
      field: "portfolio_id",
      headerName: "ID",
      width: 80,
    },

    {
      field: "portfolio_name",
      headerName: "Portfolio Name",
      width: 230,
    },

    {
      field: "portfolio_type",
      headerName: "Type",
      width: 140,
    },

    {
      field: "exchange",
      headerName: "Exchange",
      width: 120,
    },

    {
      field: "currency",
      headerName: "Currency",
      width: 110,
    },

    {
      field: "theme_name",
      headerName: "Theme",
      width: 160,
    },

    {
      field: "benchmark_name",
      headerName: "Benchmark",
      width: 170,
    },

    {
      field: "rebalancing_frequency",
      headerName: "Rebalancing",
      width: 160,
    },

    {
      field: "amount",
      headerName: "Invested Investment",
      width: 160,

      valueFormatter: (value) => {

        if (
          value === null ||
          value === undefined
        ) {
          return "-";
        }

        return Number(
          value
        ).toLocaleString("en-IN");

      },
    },

    {
      field: "status",
      headerName: "Status",
      width: 120,

      renderCell: (params) => (

        <Chip
          label={params.value || "-"}
          size="small"
          className={
            params.value === "ACTIVE"
              ? "dashboard-status-active"
              : "dashboard-status-default"
          }
        />

      ),
    },

    {
      field: "actions",
      headerName: "Action",
      width: 120,
      sortable: false,
      filterable: false,

      renderCell: (params) => (
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 0.5,
          }}
        >
          <Tooltip title="View Portfolio">
            <IconButton
              size="small"
              onClick={() =>
                navigate(
                  `/portfolios/${params.row.portfolio_id}`
                )
              }
            >
              <VisibilityIcon />
            </IconButton>
          </Tooltip>

          <Tooltip title="Delete Portfolio">
            <IconButton
              size="small"
              onClick={() =>
                handleDeletePortfolio(
                  params.row.portfolio_id,
                  params.row.portfolio_name
                )
              }
            >
              <DeleteOutlinedIcon />
            </IconButton>
          </Tooltip>
        </Box>
      ),
    },
  ];


  return (

    <Box className="portfolio-dashboard">


      {/* =================================================
          DASHBOARD HEADER
      ================================================= */}

      <Box className="dashboard-header">

        <Box>

          <Typography
            className="dashboard-title"
          >
            Portfolio Dashboard
          </Typography>

          <Typography
            className="dashboard-subtitle"
          >
            Overview of your investment portfolios
          </Typography>

        </Box>


        <Stack
          direction="row"
          spacing={1}
        >

          {/* ALERTS */}

          <Tooltip title="Alerts">

            <IconButton
              onClick={() =>
                navigate("/alerts")
              }
            >

              <Badge
                badgeContent={
                  activeAlertCount
                }
                color="error"
              >

                <NotificationsIcon />

              </Badge>

            </IconButton>

          </Tooltip>


          {/* REFRESH */}

          <Tooltip title="Refresh">

            <IconButton
              onClick={() => {

                loadPortfolios();

                loadAlerts();

              }}
            >

              <RefreshIcon />

            </IconButton>

          </Tooltip>


          {/* CREATE PORTFOLIO */}

          <Button
            variant="contained"
            startIcon={<AddIcon />}
            onClick={() =>
              setCreateOpen(true)
            }
          >
            Create Portfolio
          </Button>

        </Stack>

      </Box>


      {/* =================================================
          KPI CARDS
      ================================================= */}

      <Box className="dashboard-kpi-grid">


        {/* TOTAL PORTFOLIOS */}

        <Card className="dashboard-kpi-card">

          <CardContent>

            <Box className="kpi-icon-row">

              <Box className="kpi-icon blue">
                <AccountBalanceWalletOutlinedIcon />
              </Box>

              <Typography className="kpi-label">
                TOTAL PORTFOLIOS
              </Typography>

            </Box>

            <Typography className="kpi-value">
              {rows.length}
            </Typography>

            <Typography className="kpi-helper">
              Investment portfolios
            </Typography>

          </CardContent>

        </Card>


        {/* ACTIVE PORTFOLIOS */}

        <Card className="dashboard-kpi-card">

          <CardContent>

            <Box className="kpi-icon-row">

              <Box className="kpi-icon green">
                <TrendingUpOutlinedIcon />
              </Box>

              <Typography className="kpi-label">
                ACTIVE PORTFOLIOS
              </Typography>

            </Box>

            <Typography className="kpi-value">
              {activePortfolioCount}
            </Typography>

            <Typography className="kpi-helper">
              Currently active
            </Typography>

          </CardContent>

        </Card>


        {/* INVESTED CAPITAL */}

        <Card className="dashboard-kpi-card">

          <CardContent>

            <Box className="kpi-icon-row">

              <Box className="kpi-icon blue">
                <AccountBalanceWalletOutlinedIcon />
              </Box>

              <Typography className="kpi-label">
                INVESTED CAPITAL
              </Typography>

            </Box>

            <Typography className="kpi-value currency">
              {formatCurrency(totalInvested)}
            </Typography>

            <Typography className="kpi-helper">
              Across all portfolios
            </Typography>

          </CardContent>

        </Card>


        {/* ACTIVE ALERTS */}

        <Card
          className={
            activeAlertCount > 0
              ? "dashboard-kpi-card alert-card"
              : "dashboard-kpi-card"
          }
        >

          <CardContent>

            <Box className="kpi-icon-row">

              <Box className="kpi-icon orange">
                <WarningAmberOutlinedIcon />
              </Box>

              <Typography className="kpi-label">
                ACTIVE ALERTS
              </Typography>

            </Box>

            <Typography className="kpi-value">
              {activeAlertCount}
            </Typography>

            <Typography className="kpi-helper">

              {activeAlertCount > 0
                ? "Requires attention"
                : "No active alerts"}

            </Typography>

          </CardContent>

        </Card>

      </Box>


      {/* =================================================
          PORTFOLIOS + ALERTS
      ================================================= */}

      <Box className="dashboard-main-grid">


        {/* =================================================
            MY PORTFOLIOS
        ================================================= */}

        <Card className="dashboard-section-card">

          <Box className="section-header">

            <Box>

              <Typography className="section-title">
                My Portfolios
              </Typography>

              <Typography className="section-subtitle">
                Your investment portfolios
              </Typography>

            </Box>

            <Chip
              label={`${rows.length} Total`}
              size="small"
              className="section-count"
            />

          </Box>


          <Divider />


          <Box className="portfolio-list">

            {rows.length === 0 && (

              <Box className="dashboard-empty">
                No portfolios available.
              </Box>

            )}


            {rows
              .slice(0, 4)
              .map((portfolio) => (

                <Box
                  key={portfolio.portfolio_id}
                  className="portfolio-item"
                  onClick={() =>
                    navigate(
                      `/portfolios/${portfolio.portfolio_id}`
                    )
                  }
                >

                  <Box className="portfolio-main">

                    <Typography className="portfolio-name">
                      {portfolio.portfolio_name}
                    </Typography>

                    <Typography className="portfolio-theme">

                      {portfolio.theme_name ||
                        "Investment Portfolio"}

                    </Typography>

                    <Typography className="portfolio-meta">

                      {portfolio.exchange || "-"}
                      {" • "}
                      {portfolio.benchmark_name || "-"}

                    </Typography>

                  </Box>


                  <Box className="portfolio-value">

                    <Typography className="portfolio-amount">
                      {formatCurrency(
                        portfolio.amount
                      )}
                    </Typography>

                    <Chip
                      label={
                        portfolio.status ||
                        "-"
                      }
                      size="small"
                      className={
                        portfolio.status === "ACTIVE"
                          ? "dashboard-status-active"
                          : "dashboard-status-default"
                      }
                    />

                  </Box>


                  <ArrowForwardIcon
                    className="portfolio-arrow"
                  />

                </Box>

              ))}

          </Box>

        </Card>


        {/* =================================================
            ALERTS
        ================================================= */}

        <Card className="dashboard-section-card">

          <Box className="section-header">

            <Box>

              <Typography className="section-title">
                Alerts
              </Typography>

              <Typography className="section-subtitle">
                Portfolio notifications
              </Typography>

            </Box>

            <Chip
              label={`${activeAlertCount} Active`}
              size="small"
              className={
                activeAlertCount > 0
                  ? "alert-count-active"
                  : "alert-count-clear"
              }
            />

          </Box>


          <Divider />


          {activeAlertCount === 0 ? (

            <Box className="no-alerts">

              <Box className="no-alert-icon">
                ✓
              </Box>

              <Typography className="no-alert-title">
                No active alerts
              </Typography>

              <Typography className="no-alert-text">
                Your portfolios are looking good.
              </Typography>

            </Box>

          ) : (

            <Box className="active-alert-box">

              <Box className="alert-warning-icon">
                <WarningAmberOutlinedIcon />
              </Box>

              <Box>

                <Typography className="alert-main-text">
                  {activeAlertCount} active alert
                  {activeAlertCount !== 1
                    ? "s"
                    : ""}
                </Typography>

                <Typography className="alert-sub-text">
                  Review your portfolio alerts.
                </Typography>

              </Box>

            </Box>

          )}


          <Box className="alert-footer">

            <Button
              size="small"
              endIcon={<ArrowForwardIcon />}
              onClick={() =>
                navigate("/alerts")
              }
            >
              View Alerts
            </Button>

          </Box>

        </Card>

      </Box>


      {/* =================================================
          ALL PORTFOLIOS
      ================================================= */}

      <Card className="dashboard-grid-card">

        <Box className="grid-section-header">

          <Box>

            <Typography className="section-title">
              All Portfolios
            </Typography>

            <Typography className="section-subtitle">
              Detailed portfolio information
            </Typography>

          </Box>

          <Button
            variant="outlined"
            size="small"
            startIcon={<RefreshIcon />}
            onClick={() => {

              loadPortfolios();

              loadAlerts();

            }}
          >
            Refresh
          </Button>

        </Box>


        <Box className="dashboard-data-grid">

          <DataGrid

            rows={rows}

            columns={columns}

            getRowId={
              (row) =>
                row.portfolio_id
            }

            loading={loading}

            pageSizeOptions={[
              5,
              10,
              25,
              50,
            ]}

            initialState={{
              pagination: {
                paginationModel: {
                  page: 0,
                  pageSize: 10,
                },
              },
            }}

            disableRowSelectionOnClick

            showToolbar

          />

        </Box>

      </Card>


      {/* =================================================
          CREATE PORTFOLIO
      ================================================= */}

      <CreatePortfolioDialog

        open={createOpen}

        onClose={() =>
          setCreateOpen(false)
        }

        onCreated={async () => {

          setCreateOpen(false);

          await loadPortfolios();

          await loadAlerts();

        }}

      />

    </Box>

  );

}


export default PortfolioHome;