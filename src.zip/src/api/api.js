import axios from "axios";

const API = axios.create({
  baseURL: "http://127.0.0.1:8000",
});
 
export async function getSecurities({
  page = 1,
  pageSize = 50,
  search = "",
  exchange = "",
  assetClass = "",
}) {
 
  const response = await API.get(
    "/securities",
    {
      params: {
        page: page,
        page_size: pageSize,
 
        search:
          search || undefined,
 
        exchange:
          exchange || undefined,
 
        asset_class:
          assetClass || undefined,
      },
    }
  );
 
  return response.data;
}

export async function getSecurityById(
  securityId
) {
 
  const response = await API.get(
    `/securities/${securityId}`
  );
 
  return response.data;
}
 
export async function getSecurityPrices(
  securityId
) {
 
  const response = await API.get(
    `/securities/${securityId}/prices`
  );
 
  return response.data;
}
 
export async function getAssetClasses() {
 
  const response = await API.get(
    "/asset-classes"
  );
 
  return response.data;
}
 

export async function createAssetClass(data){
    const response = await API.post("/asset-classes", data);
    return response.data;
}

export async function updateAssetClass(assetClassId, data){
    const response = await API.put(`/asset-classes/${assetClassId}`, data);
    return response.data;
}
 
export async function getGics(){
    const response = await API.get("/gics");
    return response.data;
}

export async function getThemes() {
 
  const response = await API.get(
    "/themes"
  );
 
  return response.data;
}
 
 
export async function createTheme(data) {
 
  const response = await API.post(
    "/themes",
    data
  );
 
  return response.data;
}
 
 
export async function updateTheme(
  themeId,
  data
) {
 
  const response = await API.put(
    `/themes/${themeId}`,
    data
  );
 
  return response.data;
}
 
 
export async function getThemeAllocations(
  themeId
) {
 
  const response = await API.get(
    `/themes/${themeId}/allocations`
  );
 
  return response.data;
}

export async function saveThemeAllocations(themeId, allocations) {
    const response = await API.put(`/themes/${themeId}/allocations`,  allocations );
    return response.data;
}

export async function getBenchmarks() {
    const response = await API.get("/benchmarks");
    return response.data;
}
 
export async function getMarketPrices({
  page = 1,
  pageSize = 50,
  search = "",
  exchange = "",
  tradeDate = "",
}) {
 
  const response = await API.get(
    "/market-prices",
    {
      params: {
 
        page,
 
        page_size: pageSize,
 
        search:
          search || undefined,
 
        exchange:
          exchange || undefined,
 
        trade_date:
          tradeDate || undefined,
      },
    }
  );
 
  return response.data;
}
 
 
export async function getMarketPriceDates() {
 
  const response = await API.get(
    "/market-prices/dates"
  );
 
  return response.data;
}
 
export default API;