from pathlib import Path
import csv
from app.database.connection import get_db_connection

def seed_master_data():
    conn = get_db_connection()
    cursor = conn.cursor() 
    try:
        asset_classes = [
            (
                "Equity",
                "Listed equity securities",
                "Listed Equity",
                "High",
                "Long Term",
                "Shares of listed companies",
                "Large / Mid / Small Cap"
            ),
            (
                "ETF",
                "Exchange traded investment funds",
                "Exchange Traded Fund",
                "Medium",
                "Medium to Long Term",
                "Funds traded through an exchange",
                None
            ),
            (
                "Mutual Fund",
                "Pooled investment schemes",
                "Open Ended Fund",
                "Medium",
                "Medium to Long Term",
                "NAV based investment funds",
                None
            ),
            (
                "Government Security",
                "Government backed fixed income securities",
                "Government Bond",
                "Low",
                "Medium to Long Term",
                "Government issued debt securities",
                None
            ),
            (
                "Corporate Bond",
                "Corporate fixed income securities",
                "Corporate Debt",
                "Medium",
                "Medium Term",
                "Debt securities issued by companies",
                None
            ),
            (
                "REIT/InvIT",
                "Listed real estate and infrastructure trusts",
                "Listed Trust",
                "Medium",
                "Long Term",
                "Income producing investment trusts",
                None
            ),
            (
                "Money Market",
                "Short term money market instruments",
                "Short Term Instrument",
                "Low",
                "Short Term",
                "Short maturity investment instruments",
                None
            )
        ]
        for asset in asset_classes:
            cursor.execute(
                """
                INSERT INTO asset_class
                (
                    asset_class,
                    asset_description,
                    sub_asset_class,
                    risk,
                    investment_horizon,
                    sub_asset_description,
                    equity_category
                )
                VALUES
                (
                    %s, %s, %s, %s, %s, %s, %s
                )
                ON CONFLICT (asset_class)
                DO NOTHING;
                """,
                asset
            )
        gics_data = [
            (
                "10",
                "Energy",
                "Oil, Gas & Consumable Fuels",
                "Oil & Gas",
                "Energy sector classification"
            ),
            (
                "15",
                "Materials",
                "Chemicals",
                "Specialty Chemicals",
                "Materials sector classification"
            ),
            (
                "20",
                "Industrials",
                "Capital Goods",
                "Industrial Machinery",
                "Industrials sector classification"
            ),
            (
                "25",
                "Consumer Discretionary",
                "Automobiles & Components",
                "Automobiles",
                "Consumer discretionary classification"
            ),
            (
                "30",
                "Consumer Staples",
                "Food, Beverage & Tobacco",
                "Packaged Foods",
                "Consumer staples classification"
            ),
            (
                "35",
                "Health Care",
                "Pharmaceuticals & Biotechnology",
                "Pharmaceuticals",
                "Health care classification"
            ),
            (
                "40",
                "Financials",
                "Banks",
                "Diversified Banks",
                "Financial sector classification"
            ),
            (
                "45",
                "Information Technology",
                "Software & Services",
                "IT Services",
                "Information technology classification"
            ),
            (
                "50",
                "Communication Services",
                "Telecommunication Services",
                "Telecom",
                "Communication services classification"
            ),
            (
                "55",
                "Utilities",
                "Utilities",
                "Electric Utilities",
                "Utilities classification"
            ),
            (
                "60",
                "Real Estate",
                "Equity Real Estate",
                "Listed Trusts",
                "Real estate classification"
            )
        ]
        for gics in gics_data:
            cursor.execute(
                """ SELECT gics_id FROM gics WHERE sector_code = %s;""",
                (gics[0],)
            )
            existing = cursor.fetchone()
            if existing is None:
                cursor.execute(
                    """
                    INSERT INTO gics
                    (
                        sector_code,
                        sector_name,
                        industry,
                        industry_name,
                        description
                    )
                    VALUES (%s, %s, %s, %s, %s);""", gics
                )
        themes = [
            (
                "Aggressive",
                "Growth oriented investment theme",
                "High",
                "Long Term",
                "ACTIVE"
            ),
            (
                "Modrately Aggressive",
                "Balanced growth and stability investment theme",
                "Medium",
                "Medium to Long Term",
                "ACTIVE"
            ),
            (
                "Conservative",
                "Capital preservation oriented investment theme",
                "Low",
                "Short to Medium Term",
                "ACTIVE"
            )
        ]
        for theme in themes:
            cursor.execute(
                """
                INSERT INTO investment_theme
                (
                    theme_name,
                    description,
                    risk_level,
                    investment_horizon,
                    status
                )
                VALUES
                (%s, %s, %s, %s, %s)
                ON CONFLICT (theme_name)
                DO NOTHING;
                """,
                theme
            )
        allocations = {
            "Aggressive": {
                "Equity": 55,
                "ETF": 15,
                "Mutual Fund": 10,
                "Government Security": 5,
                "Corporate Bond": 5,
                "REIT/InvIT": 3,
                "Money Market": 7
            },
 
            "Modrately Aggressive": {
                "Equity": 35,
                "ETF": 15,
                "Mutual Fund": 15,
                "Government Security": 10,
                "Corporate Bond": 10,
                "REIT/InvIT": 5,
                "Money Market": 10
            },
 
            "Conservative": {
                "Equity": 20,
                "ETF": 10,
                "Mutual Fund": 15,
                "Government Security": 20,
                "Corporate Bond": 15,
                "REIT/InvIT": 5,
                "Money Market": 15
            }
        } 
        for theme_name, asset_values in allocations.items():
            cursor.execute(
                """SELECT theme_id FROM investment_theme WHERE theme_name = %s; """,
                (theme_name,)
            )
            theme_id = cursor.fetchone()[0] 
            for asset_name, target_percentage in asset_values.items():
                cursor.execute(
                    """ SELECT asset_class_id FROM asset_class WHERE asset_class = %s; """,
                    (asset_name,)
                )
                asset_class_id = cursor.fetchone()[0]
                cursor.execute(
                    """
                    INSERT INTO theme_allocation
                    (theme_id, target_percentage, asset_class_id)
                    VALUES(%s,%s,%s)
                    ON CONFLICT(theme_id, asset_class_id)
                    DO UPDATE SET
                        target_percentage = EXCLUDED.target_percentage;
                    """,(theme_id, target_percentage, asset_class_id)
                )

        project_folder = Path(__file__).resolve().parents[2]
        benchmark_file = (
            project_folder
            / "data"
            / "benchmark_2days_mock.csv"
        )
        if benchmark_file.exists():
            latest_benchmarks = {}
            with open(benchmark_file, "r", encoding="utf-8") as file:
                reader = csv.DictReader(file)
                for row in reader:
                    code = row["benchmark_code"]
                    if (
                        code not in latest_benchmarks
                        or
                        row["trade_date"]
                        >
                        latest_benchmarks[code]["trade_date"]
                    ):
                        latest_benchmarks[code] = row
 
            for row in latest_benchmarks.values():
                cursor.execute(
                    """
                    INSERT INTO benchmark
                    (
                        benchmark_code,
                        benchmark_name,
                        exchange,
                        country,
                        currency,
                        description,
                        status,
                        trade_date,
                        previous_close,
                        close_price
                    )
                    VALUES
                    (%s, %s, %s, %s, %s,%s, %s, %s, %s, %s)
                    ON CONFLICT (benchmark_code)
                    DO UPDATE SET
                        benchmark_name = EXCLUDED.benchmark_name,
                        exchange = EXCLUDED.exchange,
                        country = EXCLUDED.country,
                        currency = EXCLUDED.currency,
                        trade_date = EXCLUDED.trade_date,
                        previous_close = EXCLUDED.previous_close,
                        close_price = EXCLUDED.close_price;
                    """,
                    (
                        row["benchmark_code"],
                        row["benchmark_name"],
                        row["stock_exchange"],
                        row["country"],
                        row["currency"],
                        "Mock benchmark for portfolio comparison",
                        row["status"],
                        row["trade_date"],
                        row["previous_close"],
                        row["close_price"]
                    )
                )
        else:
            print(
                "Benchmark CSV not found:",
                benchmark_file
            )
        conn.commit()
        print("Master data inserted successfully")
    except Exception as error:
        conn.rollback()
        print("Error while inserting master data:")
        print(error)
        raise error
    finally:
        cursor.close()
        conn.close()

if __name__ == "__main__": 
    seed_master_data()
 