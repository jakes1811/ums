from app.database.connection import get_db_connection
def create_ums_tables(): 
    conn = get_db_connection()
    cursor = conn.cursor() 
    try:
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS asset_class (
                asset_class_id SERIAL PRIMARY KEY,
                asset_class VARCHAR(100) UNIQUE NOT NULL,
                asset_description TEXT,
                sub_asset_class VARCHAR(150),
                risk VARCHAR(50),
                investment_horizon VARCHAR(100),
                sub_asset_description TEXT,
                equity_category VARCHAR(100)
            );
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS gics (
                gics_id SERIAL PRIMARY KEY,
                sector_code VARCHAR(20),
                sector_name VARCHAR(150),
                industry VARCHAR(150),
                industry_name VARCHAR(150),
                description TEXT
            );
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS investment_theme (
                theme_id SERIAL PRIMARY KEY,
                theme_name VARCHAR(100) UNIQUE NOT NULL,
                description TEXT,
                risk_level VARCHAR(50),
                investment_horizon VARCHAR(100),
                status VARCHAR(20) DEFAULT 'ACTIVE'
            );
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS benchmark ( 
                benchmark_id SERIAL PRIMARY KEY,
                benchmark_code VARCHAR(50) UNIQUE NOT NULL,
                benchmark_name VARCHAR(150) NOT NULL,
                exchange VARCHAR(50),
                country VARCHAR(100),
                currency VARCHAR(10),
                description TEXT,
                status VARCHAR(20) DEFAULT 'ACTIVE',
                trade_date DATE,
                close_price NUMERIC(18,4),
                previous_close NUMERIC(18,4)
            );
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS theme_allocation (
                theme_allocation_id SERIAL PRIMARY KEY,
                theme_id INTEGER NOT NULL,
                target_percentage NUMERIC(5,2) NOT NULL,
                asset_class_id INTEGER NOT NULL,
                CONSTRAINT fk_theme_allocation_theme FOREIGN KEY (theme_id) REFERENCES investment_theme(theme_id),
                CONSTRAINT fk_theme_allocation_asset FOREIGN KEY (asset_class_id) REFERENCES asset_class(asset_class_id),
                CONSTRAINT unique_theme_asset UNIQUE (theme_id, asset_class_id),
                CONSTRAINT check_target_percentage
                    CHECK (target_percentage >= 0 AND target_percentage <= 100)
            );
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS unified_security_master (
                security_id BIGSERIAL PRIMARY KEY,
                isin VARCHAR(30) UNIQUE NOT NULL,
                symbol VARCHAR(50) NOT NULL,
                stock_exchange VARCHAR(50) NOT NULL,
                series VARCHAR(50),
                description TEXT,
                security_code VARCHAR(100),
                security_name VARCHAR(250) NOT NULL,
                country VARCHAR(100),
                currency VARCHAR(10),
                sector VARCHAR(150),
                industry VARCHAR(150),
                gics_id INTEGER,
                asset_class_id INTEGER NOT NULL,
                equity_category VARCHAR(100),
                CONSTRAINT fk_security_gics
                    FOREIGN KEY (gics_id) REFERENCES gics(gics_id),
                CONSTRAINT fk_security_asset_class
                    FOREIGN KEY (asset_class_id) REFERENCES asset_class(asset_class_id)
            );
        """) 
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS market_price (
                price_id BIGSERIAL PRIMARY KEY,
                security_id BIGINT
                    NOT NULL,
                trade_date DATE
                    NOT NULL,
                previous_close NUMERIC(18,4),
                open_price NUMERIC(18,4),
                high_price NUMERIC(18,4),
                low_price NUMERIC(18,4),
                close_price NUMERIC(18,4),
                volume BIGINT,
                turnover NUMERIC(22,2),
                CONSTRAINT fk_market_price_security
                    FOREIGN KEY (security_id)
                    REFERENCES unified_security_master(security_id),
                CONSTRAINT unique_security_trade_date
                    UNIQUE (security_id, trade_date)
            );
        """) 
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_security_symbol
            ON unified_security_master(symbol);
        """)
 
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_security_exchange
            ON unified_security_master(stock_exchange);
        """)
 
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_security_asset_class
            ON unified_security_master(asset_class_id);
        """)
 
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_security_gics
            ON unified_security_master(gics_id);
        """)
 
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_market_price_security_date
            ON market_price(security_id, trade_date);
        """)
        conn.commit()
        print("USM tables created successfully")
    except Exception as error:
        conn.rollback()
        print("Error while creating UMS tables:")
        print(error)
        raise error
    finally:
        cursor.close()
        conn.close()
 