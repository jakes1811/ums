import {
  useEffect,
  useState,
} from "react";
 
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  MenuItem,
  TextField,
  Tooltip,
  Typography,
} from "@mui/material";
 
import {
  DataGrid,
} from "@mui/x-data-grid";
 
import AddIcon
  from "@mui/icons-material/Add";
 
import EditIcon
  from "@mui/icons-material/Edit";
 
import {
  createAssetClass,
  getAssetClasses,
  updateAssetClass,
} from "../api/usmApi";
 
 
const emptyForm = {
 
  asset_class: "",
 
  asset_description: "",
 
  sub_asset_class: "",
 
  risk: "",
 
  investment_horizon: "",
 
  sub_asset_description: "",
 
  equity_category: "",
};
 
 
function AssetClasses() {
 
  const [rows, setRows] =
    useState([]);
 
  const [loading, setLoading] =
    useState(false);
 
  const [dialogOpen, setDialogOpen] =
    useState(false);
 
  const [editingId, setEditingId] =
    useState(null);
 
  const [form, setForm] =
    useState(emptyForm);
 
  const [message, setMessage] =
    useState("");
 
 
  // ====================================================
  // LOAD DATA
  // ====================================================
 
  async function loadAssetClasses() {
 
    try {
 
      setLoading(true);
 
      const data =
        await getAssetClasses();
 
      setRows(data);
 
    }
    catch (error) {
 
      console.error(
        "Asset Class load error:",
        error
      );
 
    }
    finally {
 
      setLoading(false);
    }
  }
 
 
  useEffect(() => {
 
    loadAssetClasses();
 
  }, []);
 
 
  // ====================================================
  // FORM CHANGE
  // ====================================================
 
  function handleChange(event) {
 
    const {
      name,
      value
    } = event.target;
 
 
    setForm(
      previous => ({
        ...previous,
 
        [name]: value,
      })
    );
  }
 
 
  // ====================================================
  // ADD
  // ====================================================
 
  function handleAdd() {
 
    setEditingId(null);
 
    setForm(emptyForm);
 
    setMessage("");
 
    setDialogOpen(true);
  }
 
 
  // ====================================================
  // EDIT
  // ====================================================
 
  function handleEdit(row) {
 
    setEditingId(
      row.asset_class_id
    );
 
 
    setForm({
 
      asset_class:
        row.asset_class || "",
 
      asset_description:
        row.asset_description || "",
 
      sub_asset_class:
        row.sub_asset_class || "",
 
      risk:
        row.risk || "",
 
      investment_horizon:
        row.investment_horizon || "",
 
      sub_asset_description:
        row.sub_asset_description || "",
 
      equity_category:
        row.equity_category || "",
    });
 
 
    setMessage("");
 
    setDialogOpen(true);
  }
 
 
  // ====================================================
  // SAVE
  // ====================================================
 
  async function handleSave() {
 
    if (
      form.asset_class.trim() === ""
    ) {
 
      setMessage(
        "Asset Class is required"
      );
 
      return;
    }
 
 
    try {
 
      if (editingId) {
 
        await updateAssetClass(
          editingId,
          form
        );
 
      }
      else {
 
        await createAssetClass(
          form
        );
      }
 
 
      setDialogOpen(false);
 
      setEditingId(null);
 
      setForm(emptyForm);
 
      await loadAssetClasses();
 
    }
    catch (error) {
 
      console.error(
        "Asset Class save error:",
        error
      );
 
 
      if (
        error.response?.status === 500
      ) {
 
        setMessage(
          "Asset Class may already exist"
        );
 
      }
      else {
 
        setMessage(
          "Unable to save Asset Class"
        );
      }
    }
  }
 
 
  // ====================================================
  // COLUMNS
  // ====================================================
 
  const columns = [
 
    {
      field: "asset_class_id",
      headerName: "ID",
      width: 80,
    },
 
    {
      field: "asset_class",
      headerName: "Asset Class",
      width: 170,
    },
 
    {
      field: "asset_description",
      headerName: "Description",
      width: 260,
    },
 
    {
      field: "sub_asset_class",
      headerName: "Sub Asset Class",
      width: 190,
    },
 
    {
      field: "risk",
      headerName: "Risk",
      width: 120,
    },
 
    {
      field: "investment_horizon",
      headerName: "Investment Horizon",
      width: 190,
    },
 
    {
      field: "sub_asset_description",
      headerName: "Sub Asset Description",
      width: 260,
    },
 
    {
      field: "equity_category",
      headerName: "Equity Category",
      width: 190,
    },
 
    {
      field: "actions",
      headerName: "Action",
      width: 100,
      sortable: false,
      filterable: false,
 
      renderCell: (params) => (
 
        <Tooltip title="Edit">
 
          <IconButton
            onClick={() =>
              handleEdit(
                params.row
              )
            }
          >
 
            <EditIcon />
 
          </IconButton>
 
        </Tooltip>
      ),
    },
  ];
 
 
  return (
 
    <Box>
 
      {/* HEADER */}
 
      <Box
        sx={{
          display: "flex",
          justifyContent:
            "space-between",
          alignItems: "center",
          mb: 3,
        }}
      >
 
        <Box>
 
          <Typography
            variant="h4"
            fontWeight="bold"
          >
            Asset Classes
          </Typography>
 
          <Typography
            color="text.secondary"
          >
            Manage security asset classifications
          </Typography>
 
        </Box>
 
 
        <Button
          variant="contained"
          startIcon={
            <AddIcon />
          }
          onClick={handleAdd}
        >
          Add Asset Class
        </Button>
 
      </Box>
 
 
      {/* DATA GRID */}
 
      <Box
        sx={{
          height: 620,
          width: "100%",
        }}
      >
 
        <DataGrid
 
          rows={rows}
 
          columns={columns}
 
          getRowId={
            (row) =>
              row.asset_class_id
          }
 
          loading={loading}
 
          pageSizeOptions={[
            5,
            10,
            25,
          ]}
 
          initialState={{
            pagination: {
              paginationModel: {
                page: 0,
                pageSize: 10,
              },
            },
          }}
 
          disableRowSelectionOnClick
 
          showToolbar
 
        />
 
      </Box>
 
 
      {/* ADD / EDIT POPUP */}
 
      <Dialog
        open={dialogOpen}
 
        onClose={() =>
          setDialogOpen(false)
        }
 
        fullWidth
        maxWidth="md"
      >
 
        <DialogTitle>
 
          {
            editingId
              ? "Edit Asset Class"
              : "Add Asset Class"
          }
 
        </DialogTitle>
 
 
        <DialogContent>
 
          <Box
            sx={{
              display: "grid",
 
              gridTemplateColumns:
                "1fr 1fr",
 
              gap: 2,
 
              mt: 1,
            }}
          >
 
            <TextField
              label="Asset Class"
              name="asset_class"
              value={
                form.asset_class
              }
              onChange={
                handleChange
              }
              required
            />
 
 
            <TextField
              label="Sub Asset Class"
              name="sub_asset_class"
              value={
                form.sub_asset_class
              }
              onChange={
                handleChange
              }
            />
 
 
            <TextField
              select
              label="Risk"
              name="risk"
              value={
                form.risk
              }
              onChange={
                handleChange
              }
            >
 
              <MenuItem value="">
                Select Risk
              </MenuItem>
 
              <MenuItem value="Low">
                Low
              </MenuItem>
 
              <MenuItem value="Medium">
                Medium
              </MenuItem>
 
              <MenuItem value="High">
                High
              </MenuItem>
 
            </TextField>
 
 
            <TextField
              label="Investment Horizon"
              name="investment_horizon"
              value={
                form.investment_horizon
              }
              onChange={
                handleChange
              }
            />
 
 
            <TextField
              label="Equity Category"
              name="equity_category"
              value={
                form.equity_category
              }
              onChange={
                handleChange
              }
            />
 
 
            <TextField
              label="Asset Description"
              name="asset_description"
              value={
                form.asset_description
              }
              onChange={
                handleChange
              }
              multiline
              rows={3}
            />
 
 
            <TextField
              label="Sub Asset Description"
              name="sub_asset_description"
              value={
                form.sub_asset_description
              }
              onChange={
                handleChange
              }
              multiline
              rows={3}
            />
 
          </Box>
 
 
          {
            message &&
            (
              <Typography
                color="error"
                sx={{
                  mt: 2,
                }}
              >
                {message}
              </Typography>
            )
          }
 
        </DialogContent>
 
 
        <DialogActions>
 
          <Button
            onClick={() =>
              setDialogOpen(false)
            }
          >
            Cancel
          </Button>
 
 
          <Button
            variant="contained"
            onClick={
              handleSave
            }
          >
 
            {
              editingId
                ? "Update"
                : "Save"
            }
 
          </Button>
 
        </DialogActions>
 
      </Dialog>
 
    </Box>
  );
}
 
 
export default AssetClasses;