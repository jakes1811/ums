from app.repositories.security_repository import (
    SecurityRepository
)
 
from app.repositories.price_repository import (
    PriceRepository
)
 
class SecurityService:
    @staticmethod
    def get_securities(
        page,
        page_size,
        search,
        exchange,
        asset_class,
        equity_category
    ):
 
        return SecurityRepository.get_securities(
            page=page,
            page_size=page_size,
            search=search,
            exchange=exchange,
            asset_class=asset_class,
            equity_category=equity_category
        )
 
 
    @staticmethod
    def get_security_by_id(
        security_id
    ):
 
        return SecurityRepository.get_security_by_id(
            security_id
        )
 
 
    @staticmethod
    def get_security_price(
        security_id,
        trade_date
    ):
 
        return PriceRepository.get_price_by_date(
            security_id,
            trade_date
        )

    @staticmethod
    def get_security_prices(
        security_id
    ):
    
        return PriceRepository.get_all_prices_for_security(
            security_id
        )