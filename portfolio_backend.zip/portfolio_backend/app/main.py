from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.database.init_db import create_portfolio_tables
from app.routers import ums_test,portfolios,holdings,alerts,reference_data,transactions

app = FastAPI(
    title="Portfolio Management API",
    version="1.0.0"
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:5174", "http://127.0.0.1:5173", "http://127.0.0.1:5174",],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)
create_portfolio_tables()
app.include_router(ums_test.router)
app.include_router(portfolios.router)
app.include_router(holdings.router)
app.include_router(alerts.router)
app.include_router(reference_data.router)
app.include_router(transactions.router)
@app.get("/")
def home():
    return {"message": "Welcome to the Portfolio Management API!"}