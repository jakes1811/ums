from datetime import date
 
from fastapi import (
    APIRouter,
    Query,
    HTTPException
)
 
from app.services.security_service import (
    SecurityService
)
 
 
router = APIRouter(
    prefix="/securities",
    tags=["Securities"]
)
 
 
# =========================================================
# GET ALL SECURITIES
# =========================================================
 
@router.get("")
def get_securities(
 
    page: int = Query(
        default=1,
        ge=1
    ),
 
    page_size: int = Query(
        default=50,
        ge=1,
        le=200
    ),
 
    search: str | None = None,
 
    exchange: str | None = None,
 
    asset_class: str | None = None,
 
    equity_category: str | None = None
):
 
    return SecurityService.get_securities(
        page=page,
        page_size=page_size,
        search=search,
        exchange=exchange,
        asset_class=asset_class,
        equity_category=equity_category
    )

@router.get("/{security_id}/prices")
def get_security_prices(
    security_id: int
):
 
    return SecurityService.get_security_prices(
        security_id
    )
 
# =========================================================
# GET SECURITY PRICE FOR A DATE
# =========================================================
 
@router.get("/{security_id}/price")
def get_security_price(
 
    security_id: int,
 
    date: date = Query(...)
):
 
    price = SecurityService.get_security_price(
        security_id,
        date
    )
 
    if price is None:
 
        raise HTTPException(
            status_code=404,
            detail="Price not found for this security and date"
        )
 
    return price
 
 
# =========================================================
# GET ONE SECURITY
# =========================================================
 
@router.get("/{security_id}")
def get_security_by_id(
    security_id: int
):
 
    security = SecurityService.get_security_by_id(
        security_id
    )
 
    if security is None:
 
        raise HTTPException(
            status_code=404,
            detail="Security not found"
        )
 
    return security