from fastapi import (
    APIRouter,
    HTTPException,
    Query
)
 
import httpx
 
from app.services.ums_service import UMSService
 
 
router = APIRouter(
    prefix="/reference",
    tags=["Reference Data"]
)
 
 
@router.get("/themes")
async def get_themes():
 
    try:
        return await UMSService.get_themes()
 
    except httpx.HTTPError:
 
        raise HTTPException(
            status_code=502,
            detail="Unable to communicate with UMS API"
        )
 
 
@router.get("/benchmarks")
async def get_benchmarks():
 
    try:
        return await UMSService.get_benchmarks()
 
    except httpx.HTTPError:
 
        raise HTTPException(
            status_code=502,
            detail="Unable to communicate with UMS API"
        )
 
@router.get("/securities")
async def get_securities(
 
    exchange: str | None = None,
 
    search: str | None = None,
 
    asset_class: str | None = None,
 
    equity_category: str | None = None,
 
    page: int = Query(
        default=1,
        ge=1
    ),

    page_size: int = Query(
        default=50,
        ge=1,
        le=2500
    )
):

    try:

        return await UMSService.get_securities(
            exchange=exchange,
            search=search,
            asset_class=asset_class,
            equity_category=equity_category,
            page=page,
            page_size=page_size
        )

    except httpx.HTTPError:

        raise HTTPException(
            status_code=502,
            detail="Unable to communicate with UMS API"
        )
 