import {
  useEffect,
  useState,
} from "react";
 
import {
  Box,
  Button,
  FormControl,
  IconButton,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Tooltip,
  Typography,
} from "@mui/material";
 
import {
  DataGrid,
} from "@mui/x-data-grid";
 
import RefreshIcon
  from "@mui/icons-material/Refresh";
 
import VisibilityIcon
  from "@mui/icons-material/Visibility";
 
import {
  getAssetClasses,
  getSecurities,
  getSecurityById,
  getSecurityPrices,
} from "../api/usmApi";
 
import SecurityDetailsDialog
  from "../components/SecurityDetailsDialog";
 
 
function SecurityMaster() {
 
  const [rows, setRows] =
    useState([]);
 
  const [totalRows, setTotalRows] =
    useState(0);
 
  const [loading, setLoading] =
    useState(false);
 
 
  const [
    paginationModel,
    setPaginationModel
  ] = useState({
    page: 0,
    pageSize: 50,
  });
 
 
  const [search, setSearch] =
    useState("");
 
  const [exchange, setExchange] =
    useState("");
 
  const [
    assetClass,
    setAssetClass
  ] = useState("");
 
  const [
    assetClasses,
    setAssetClasses
  ] = useState([]);
 
 
  // ==================================================
  // DETAILS POPUP
  // ==================================================
 
  const [
    detailsOpen,
    setDetailsOpen
  ] = useState(false);
 
  const [
    selectedSecurity,
    setSelectedSecurity
  ] = useState(null);
 
  const [
    securityPrices,
    setSecurityPrices
  ] = useState([]);
 
  const [
    detailsLoading,
    setDetailsLoading
  ] = useState(false);
 
 
  // ==================================================
  // LOAD ASSET CLASSES
  // ==================================================
 
  useEffect(() => {
 
    async function loadAssetClasses() {
 
      try {
 
        const data =
          await getAssetClasses();
 
        setAssetClasses(data);
 
      }
      catch (error) {
 
        console.error(
          "Asset class error:",
          error
        );
      }
    }
 
    loadAssetClasses();
 
  }, []);
 
 
  // ==================================================
  // LOAD SECURITIES
  // ==================================================
 
  async function loadSecurities() {
 
    try {
 
      setLoading(true);
 
      const data =
        await getSecurities({
 
          page:
            paginationModel.page + 1,
 
          pageSize:
            paginationModel.pageSize,
 
          search,
 
          exchange,
 
          assetClass,
        });
 
 
      setRows(data.rows);
 
      setTotalRows(data.total);
 
    }
    catch (error) {
 
      console.error(
        "Security loading error:",
        error
      );
 
    }
    finally {
 
      setLoading(false);
    }
  }
 
 
  useEffect(() => {
 
    loadSecurities();
 
  }, [
    paginationModel.page,
    paginationModel.pageSize,
    exchange,
    assetClass,
  ]);
 
 
  // ==================================================
  // SEARCH
  // ==================================================
 
  function handleSearch() {
 
    if (paginationModel.page === 0) {
 
      loadSecurities();
 
    }
    else {
 
      setPaginationModel(
        previous => ({
          ...previous,
          page: 0,
        })
      );
    }
  }
 
 
  function handleReset() {
 
    setSearch("");
    setExchange("");
    setAssetClass("");
 
    setPaginationModel({
      page: 0,
      pageSize: 50,
    });
  }
 
 
  // ==================================================
  // VIEW SECURITY
  // ==================================================
 
  async function handleView(
    securityId
  ) {
 
    try {
 
      setDetailsLoading(true);
 
      setDetailsOpen(true);
 
 
      const [
        security,
        prices
      ] = await Promise.all([
 
        getSecurityById(
          securityId
        ),
 
        getSecurityPrices(
          securityId
        ),
 
      ]);
 
 
      setSelectedSecurity(
        security
      );
 
      setSecurityPrices(
        prices
      );
 
    }
    catch (error) {
 
      console.error(
        "Security details error:",
        error
      );
 
    }
    finally {
 
      setDetailsLoading(false);
    }
  }
 
 
  function handleCloseDetails() {
 
    setDetailsOpen(false);
 
    setSelectedSecurity(null);
 
    setSecurityPrices([]);
  }
 
 
  // ==================================================
  // COLUMNS
  // ==================================================
 
  const columns = [
 
    {
      field: "security_id",
      headerName: "ID",
      width: 80,
    },
 
    {
      field: "symbol",
      headerName: "Symbol",
      width: 140,
    },
 
    {
      field: "security_name",
      headerName: "Security Name",
      width: 250,
    },
 
    {
      field: "isin",
      headerName: "ISIN",
      width: 170,
    },
 
    {
      field: "stock_exchange",
      headerName: "Exchange",
      width: 120,
    },
 
    {
      field: "asset_class",
      headerName: "Asset Class",
      width: 170,
    },
 
    {
      field: "series",
      headerName: "Series",
      width: 100,
    },
 
    {
      field: "country",
      headerName: "Country",
      width: 160,
    },
 
    {
      field: "currency",
      headerName: "Currency",
      width: 100,
    },
 
    {
      field: "sector",
      headerName: "Sector",
      width: 200,
    },
 
    {
      field: "industry",
      headerName: "Industry",
      width: 200,
    },
 
    {
      field: "actions",
      headerName: "Action",
      width: 100,
      sortable: false,
      filterable: false,
 
      renderCell: (params) => (
 
        <Tooltip title="View">
 
          <IconButton
            onClick={() =>
              handleView(
                params.row.security_id
              )
            }
          >
 
            <VisibilityIcon />
 
          </IconButton>
 
        </Tooltip>
      ),
    },
  ];
 
 
  return (
 
    <Box>
 
      <Typography
        variant="h4"
        fontWeight="bold"
        sx={{
          mb: 3,
        }}
      >
        Unified Security Master
      </Typography>
 
 
      {/* FILTER GRID */}
 
      <Box
        sx={{
          display: "grid",
 
          gridTemplateColumns:
            "2fr 1fr 1fr auto auto",
 
          gap: 2,
 
          mb: 3,
 
          alignItems: "center",
        }}
      >
 
        <TextField
          label="Search securities"
          size="small"
 
          value={search}
 
          onChange={(e) =>
            setSearch(
              e.target.value
            )
          }
 
          onKeyDown={(e) => {
 
            if (
              e.key === "Enter"
            ) {
              handleSearch();
            }
 
          }}
        />
 
 
        <FormControl
          size="small"
        >
 
          <InputLabel>
            Exchange
          </InputLabel>
 
          <Select
            label="Exchange"
 
            value={exchange}
 
            onChange={(e) => {
 
              setExchange(
                e.target.value
              );
 
              setPaginationModel(
                previous => ({
                  ...previous,
                  page: 0,
                })
              );
 
            }}
          >
 
            <MenuItem value="">
              All
            </MenuItem>
 
            <MenuItem value="NSE">
              NSE
            </MenuItem>
 
            <MenuItem value="NASDAQ">
              NASDAQ
            </MenuItem>
 
            <MenuItem value="LSE">
              LSE
            </MenuItem>
 
          </Select>
 
        </FormControl>
 
 
        <FormControl
          size="small"
        >
 
          <InputLabel>
            Asset Class
          </InputLabel>
 
          <Select
            label="Asset Class"
 
            value={assetClass}
 
            onChange={(e) => {
 
              setAssetClass(
                e.target.value
              );
 
              setPaginationModel(
                previous => ({
                  ...previous,
                  page: 0,
                })
              );
 
            }}
          >
 
            <MenuItem value="">
              All
            </MenuItem>
 
            {
              assetClasses.map(
                (asset) => (
 
                  <MenuItem
                    key={
                      asset.asset_class_id
                    }
 
                    value={
                      asset.asset_class
                    }
                  >
 
                    {asset.asset_class}
 
                  </MenuItem>
 
                )
              )
            }
 
          </Select>
 
        </FormControl>
 
 
        <Button
          variant="contained"
          onClick={handleSearch}
        >
          Search
        </Button>
 
 
        <Button
          variant="outlined"
 
          startIcon={
            <RefreshIcon />
          }
 
          onClick={
            handleReset
          }
        >
          Reset
        </Button>
 
      </Box>
 
 
      <Typography
        sx={{
          mb: 1,
        }}
      >
        Total Securities:
        {" "}
 
        <strong>
          {totalRows}
        </strong>
      </Typography>
 
 
      {/* MAIN DATA GRID */}
 
      <Box
        sx={{
          height: 650,
          width: "100%",
        }}
      >
 
        <DataGrid
 
          rows={rows}
 
          columns={columns}
 
          getRowId={
            (row) =>
              row.security_id
          }
 
          loading={loading}
 
 
          paginationMode="server"
 
          rowCount={totalRows}
 
          paginationModel={
            paginationModel
          }
 
          onPaginationModelChange={
            setPaginationModel
          }
 
          pageSizeOptions={[
            10,
            25,
            50,
            100,
          ]}
 
 
          disableRowSelectionOnClick
 
          showToolbar
 
        />
 
      </Box>
 
 
      {/* DETAILS POPUP */}
 
      <SecurityDetailsDialog
 
        open={detailsOpen}
 
        onClose={
          handleCloseDetails
        }
 
        security={
          selectedSecurity
        }
 
        prices={
          securityPrices
        }
 
        loading={
          detailsLoading
        }
 
      />
 
    </Box>
  );
}
 
 
export default SecurityMaster;