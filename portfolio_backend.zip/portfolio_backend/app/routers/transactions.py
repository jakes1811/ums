from fastapi import APIRouter, HTTPException

from app.repositories.portfolio_repository import PortfolioRepository
from app.repositories.transaction_repository import TransactionRepository

router = APIRouter(
    prefix="/portfolios",
    tags=["Transaction History"]
)


@router.get("/{portfolio_id}/transactions")
def get_portfolio_transactions(portfolio_id: int):
    portfolio = PortfolioRepository.get_portfolio_by_id(portfolio_id)

    if portfolio is None:
        raise HTTPException(
            status_code=404,
            detail="Portfolio not found"
        )

    return TransactionRepository.get_transactions_by_portfolio(portfolio_id)
