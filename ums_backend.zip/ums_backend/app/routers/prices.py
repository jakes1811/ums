from datetime import date
 
from fastapi import (
    APIRouter,
    Query
)
 
from app.services.price_service import (
    PriceService
)
 
 
router = APIRouter(
    prefix="/market-prices",
    tags=["Market Prices"]
)
 
 
@router.get("/dates")
def get_trade_dates():
 
    return PriceService.get_trade_dates()
 
 
@router.get("")
def get_market_prices(
 
    page: int = Query(
        default=1,
        ge=1
    ),
 
    page_size: int = Query(
        default=50,
        ge=1,
        le=200
    ),
 
    search: str | None = None,
 
    exchange: str | None = None,
 
    trade_date: date | None = None
):
 
    return PriceService.get_market_prices(
 
        page=page,
 
        page_size=page_size,
 
        search=search,
 
        exchange=exchange,
 
        trade_date=trade_date
    )
 