import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  Grid,
  Typography,
} from "@mui/material";
 
import { DataGrid } from "@mui/x-data-grid";
 
 
function SecurityDetailsDialog({
  open,
  onClose,
  security,
  prices,
  loading,
}) {
 
  const priceColumns = [
    {
      field: "trade_date",
      headerName: "Trade Date",
      width: 130,
    },
    {
      field: "previous_close",
      headerName: "Previous Close",
      width: 150,
    },
    {
      field: "open_price",
      headerName: "Open",
      width: 120,
    },
    {
      field: "high_price",
      headerName: "High",
      width: 120,
    },
    {
      field: "low_price",
      headerName: "Low",
      width: 120,
    },
    {
      field: "close_price",
      headerName: "Close",
      width: 120,
    },
    {
      field: "volume",
      headerName: "Volume",
      width: 140,
    },
    {
      field: "turnover",
      headerName: "Turnover",
      width: 160,
    },
  ];
 
 
  return (
    <Dialog
      open={open}
      onClose={onClose}
      fullWidth
      maxWidth="lg"
    >
 
      <DialogTitle>
        Security Details
      </DialogTitle>
 
 
      <DialogContent>
 
        {security && (
 
          <>
            <Box
              sx={{
                mt: 1,
                mb: 3,
              }}
            >
 
              <Grid
                container
                spacing={2}
              >
 
                <Grid item xs={12} md={4}>
                  <Typography variant="caption">
                    Symbol
                  </Typography>
 
                  <Typography fontWeight="bold">
                    {security.symbol}
                  </Typography>
                </Grid>
 
 
                <Grid item xs={12} md={4}>
                  <Typography variant="caption">
                    Security Name
                  </Typography>
 
                  <Typography fontWeight="bold">
                    {security.security_name}
                  </Typography>
                </Grid>
 
 
                <Grid item xs={12} md={4}>
                  <Typography variant="caption">
                    ISIN
                  </Typography>
 
                  <Typography fontWeight="bold">
                    {security.isin}
                  </Typography>
                </Grid>
 
 
                <Grid item xs={12} md={4}>
                  <Typography variant="caption">
                    Exchange
                  </Typography>
 
                  <Typography>
                    {security.stock_exchange}
                  </Typography>
                </Grid>
 
 
                <Grid item xs={12} md={4}>
                  <Typography variant="caption">
                    Asset Class
                  </Typography>
 
                  <Typography>
                    {security.asset_class}
                  </Typography>
                </Grid>
 
 
                <Grid item xs={12} md={4}>
                  <Typography variant="caption">
                    Currency
                  </Typography>
 
                  <Typography>
                    {security.currency}
                  </Typography>
                </Grid>
 
 
                <Grid item xs={12} md={4}>
                  <Typography variant="caption">
                    Sector
                  </Typography>
 
                  <Typography>
                    {security.sector || "-"}
                  </Typography>
                </Grid>
 
 
                <Grid item xs={12} md={4}>
                  <Typography variant="caption">
                    Industry
                  </Typography>
 
                  <Typography>
                    {security.industry || "-"}
                  </Typography>
                </Grid>
 
 
                <Grid item xs={12} md={4}>
                  <Typography variant="caption">
                    Country
                  </Typography>
 
                  <Typography>
                    {security.country}
                  </Typography>
                </Grid>
 
              </Grid>
 
            </Box>
 
 
            <Divider />
 
 
            <Typography
              variant="h6"
              fontWeight="bold"
              sx={{
                mt: 3,
                mb: 2,
              }}
            >
              Market Price - 2 Days
            </Typography>
 
 
            <Box
              sx={{
                height: 300,
                width: "100%",
              }}
            >
 
              <DataGrid
                rows={prices}
                columns={priceColumns}
                getRowId={(row) => row.price_id}
                loading={loading}
                disableRowSelectionOnClick
                hideFooter
              />
 
            </Box>
          </>
        )}
 
      </DialogContent>
 
 
      <DialogActions>
 
        <Button
          onClick={onClose}
          variant="contained"
        >
          Close
        </Button>
 
      </DialogActions>
 
    </Dialog>
  );
}
 
 
export default SecurityDetailsDialog;