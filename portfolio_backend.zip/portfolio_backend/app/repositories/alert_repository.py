from app.database.connection import get_db_connection
 
 
class AlertRepository:
 
    @staticmethod
    def get_active_alert(
        portfolio_id,
        asset_class_id
    ):
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            cursor.execute(
                """
                SELECT alert_id
 
                FROM alerts
 
                WHERE portfolio_id = %s
                AND asset_class_id = %s
                AND status = 'ACTIVE'
 
                ORDER BY alert_id DESC
 
                LIMIT 1;
                """,
                (
                    portfolio_id,
                    asset_class_id
                )
            )
 
            row = cursor.fetchone()
 
            if row:
                return row[0]
 
            return None
 
        finally:
 
            cursor.close()
            conn.close()
 
 
    @staticmethod
    def create_alert(
        portfolio_id,
        asset_class_id,
        alert_type,
        alert_message,
        target_percentage,
        current_percentage,
        deviation_percentage
    ):
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            cursor.execute(
                """
                INSERT INTO alerts
                (
                    portfolio_id,
                    asset_class_id,
                    alert_type,
                    alert_message,
                    target_percentage,
                    current_percentage,
                    deviation_percentage,
                    status
                )
 
                VALUES
                (
                    %s, %s, %s, %s,
                    %s, %s, %s,
                    'ACTIVE'
                )
 
                RETURNING alert_id;
                """,
                (
                    portfolio_id,
                    asset_class_id,
                    alert_type,
                    alert_message,
                    target_percentage,
                    current_percentage,
                    deviation_percentage
                )
            )
 
            alert_id = cursor.fetchone()[0]
 
            conn.commit()
 
            return alert_id
 
        except Exception:
 
            conn.rollback()
            raise
 
        finally:
 
            cursor.close()
            conn.close()
 
 
    @staticmethod
    def update_alert(
        alert_id,
        alert_type,
        alert_message,
        target_percentage,
        current_percentage,
        deviation_percentage
    ):
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            cursor.execute(
                """
                UPDATE alerts
 
                SET
                    alert_type = %s,
                    alert_message = %s,
                    target_percentage = %s,
                    current_percentage = %s,
                    deviation_percentage = %s,
                    status = 'ACTIVE'
 
                WHERE alert_id = %s;
                """,
                (
                    alert_type,
                    alert_message,
                    target_percentage,
                    current_percentage,
                    deviation_percentage,
                    alert_id
                )
            )
 
            conn.commit()
 
        except Exception:
 
            conn.rollback()
            raise
 
        finally:
 
            cursor.close()
            conn.close()
 
 
    @staticmethod
    def resolve_alert(
        portfolio_id,
        asset_class_id
    ):
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            cursor.execute(
                """
                UPDATE alerts
 
                SET status = 'RESOLVED'
 
                WHERE portfolio_id = %s
                AND asset_class_id = %s
                AND status = 'ACTIVE';
                """,
                (
                    portfolio_id,
                    asset_class_id
                )
            )
 
            conn.commit()
 
        except Exception:
 
            conn.rollback()
            raise
 
        finally:
 
            cursor.close()
            conn.close()
 
 
    @staticmethod
    def get_alerts():
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            cursor.execute(
                """
                SELECT
                    al.alert_id,
                    al.portfolio_id,
                    p.portfolio_name,
                    al.asset_class_id,
                    a.asset_class,
                    al.alert_type,
                    al.alert_message,
                    al.target_percentage,
                    al.current_percentage,
                    al.deviation_percentage,
                    al.status
 
                FROM alerts al
 
                JOIN portfolio_details p
                ON p.portfolio_id = al.portfolio_id
 
                JOIN asset_class a
                ON a.asset_class_id = al.asset_class_id
 
                ORDER BY al.alert_id DESC;
                """
            )
 
            rows = cursor.fetchall()
 
            return [
                {
                    "alert_id": row[0],
                    "portfolio_id": row[1],
                    "portfolio_name": row[2],
                    "asset_class_id": row[3],
                    "asset_class": row[4],
                    "alert_type": row[5],
                    "alert_message": row[6],
                    "target_percentage": float(row[7]),
                    "current_percentage": float(row[8]),
                    "deviation_percentage": float(row[9]),
                    "status": row[10]
                }
 
                for row in rows
            ]
 
        finally:
 
            cursor.close()
            conn.close()
 