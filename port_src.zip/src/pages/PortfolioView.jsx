import {
  useEffect,
  useMemo,
  useState,
} from "react";
 
import {
  Alert,
  Box,
  Button,
  Chip,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  Link,
  MenuItem,
  TextField,
  Tooltip,
  Typography,
} from "@mui/material";

import {
  Add as AddIcon,
  Delete as DeleteIcon,
  Remove as RemoveIcon,
} from "@mui/icons-material";

import {
  activatePortfolio,
} from "../api/api";
 
import {
  DataGrid,
} from "@mui/x-data-grid";
 
import {
  useNavigate,
  useParams,
} from "react-router-dom";
 
import {
    buyMoreHolding,
    deleteHolding,
  getHoldings,
  getPortfolioById,
  getPortfolioValuation,
  getPortfolioAllocation,
  getPortfolioPerformance,
  sellHolding,
  closePortfolio,
} from "../api/api";
 
import AddHoldingDialog
  from "../components/AddHoldingDialog";
 
 
function PortfolioView() {
 
  const { portfolioId } =
    useParams();
 
  const navigate =
    useNavigate();
 
 
  const [portfolio, setPortfolio] =
    useState(null);
 
  const [holdings, setHoldings] =
    useState([]);
 
  const [valuation, setValuation] =
    useState(null);
 
  const [valuationDate, setValuationDate] =
    useState("2026-10-02");
 
  const [loading, setLoading] =
    useState(true);
 
  const [error, setError] =
    useState("");
 
  const [addOpen, setAddOpen] =
    useState(false);
 
  const [allocationOpen, setAllocationOpen] = useState(false);
  const [ allocationRows, setAllocationRows] = useState([])
  const [ allocationLoading, setAllocationLoading] = useState(false);
  const [ allocationError, setAllocationError] = useState("");

  const [ performanceOpen, setPerformanceOpen] = useState(false);
  const [ performanceRows, setPerformanceRows] = useState([])
  const [ performanceLoading, setPerformanceLoading] = useState(false);
  const [ performanceError, setPerformanceError] = useState("");

  const [
  tradeOpen,
  setTradeOpen
] = useState(false);
 
const [
  tradeType,
  setTradeType
] = useState("");
 
const [
  selectedHolding,
  setSelectedHolding
] = useState(null);
 
const [
  tradeQuantity,
  setTradeQuantity
] = useState("");
 
const [
  tradeSaving,
  setTradeSaving
] = useState(false);
 
const [
  tradeError,
  setTradeError
] = useState("");
 
const [
  tradeResult,
  setTradeResult
] = useState(null);
 

  async function loadPortfolio() {
 
    try {
 
      setLoading(true);
      setError("");
 
 
      const [
        portfolioData,
        holdingData,
      ] = await Promise.all([
 
        getPortfolioById(
          portfolioId
        ),
 
        getHoldings(
          portfolioId
        ),
 
      ]);
 
 
      setPortfolio(
        portfolioData
      );
 
      setHoldings(
        holdingData
      );
 
 
      if (
        holdingData.length > 0
      ) {
 
        const valuationData =
          await getPortfolioValuation(
            portfolioId,
            valuationDate
          );
 
        setValuation(
          valuationData
        );
 
      }
      else {
 
        setValuation(null);
 
      }
 
    }
    catch (err) {
 
      console.error(err);
 
      setError(
        err.response?.data?.detail ||
        "Unable to load portfolio"
      );
 
    }
    finally {
 
      setLoading(false);
 
    }
 
  }
 
 
  useEffect(() => {
 
    loadPortfolio();
 
  }, [
    portfolioId,
    valuationDate,
  ]);
 
 
  const compositionRows =
    useMemo(() => {
 
      return holdings.map(
        (holding) => {
 
          const valueData =
            valuation?.holdings?.find(
              (item) =>
                item.security_id ===
                holding.security_id
            );
 
 
          return {
 
            ...holding,
 
            ...(valueData || {}),
 
          };
 
        }
      );
 
    }, [
      holdings,
      valuation,
    ]);
 
 
  const columns = [
 
    {
      field: "symbol",
      headerName: "Symbol",
      width: 130,
    },
 
    {
      field: "security_name",
      headerName: "Security Name",
      width: 230,
    },
 
    {
      field: "asset_class",
      headerName: "Asset Class",
      width: 150,
    },
 
    {
      field: "sub_asset_class",
      headerName: "Sub Asset Class",
      width: 170,
 
      valueFormatter: (value) =>
        value || "-",
    },
 
    {
      field: "equity_category",
      headerName: "Equity Category",
      width: 160,
 
      valueFormatter: (value) =>
        value || "-",
    },
 
    {
      field: "buy_price",
      headerName: "Buy Price",
      width: 130,
 
      valueGetter: (
        value,
        row
      ) =>
        row.buy_price ??
        row.security_price,
 
      valueFormatter: (value) =>
        value == null
          ? "-"
          : Number(value).toFixed(2),
    },
 
    {
      field: "current_price",
      headerName: "Current Price",
      width: 140,
 
      valueFormatter: (value) =>
        value == null
          ? "-"
          : Number(value).toFixed(2),
    },
 
    {
      field: "quantity",
      headerName: "Qty",
      width: 100,
    },
 
    {
      field: "invested_value",
      headerName: "Invested Value",
      width: 150,
 
      valueGetter: (
        value,
        row
      ) =>
        row.invested_value ??
        row.total_value,
 
      valueFormatter: (value) =>
        value == null
          ? "-"
          : Number(value).toFixed(2),
    },
 
    {
      field: "current_value",
      headerName: "Current Value",
      width: 150,
 
      valueFormatter: (value) =>
        value == null
          ? "-"
          : Number(value).toFixed(2),
    },
 
    {
      field: "profit_loss",
      headerName: "P/L",
      width: 120,
 
      renderCell: (params) => {
        const value = params.value;
        const numericValue = value == null ? null : Number(value);

        if (numericValue == null || Number.isNaN(numericValue)) {
          return "-";
        }

        return (
          <Box
            component="span"
            sx={{
              color: numericValue < 0 ? "error.main" : "success.main",
              fontWeight: 600,
            }}
          >
            {Number(numericValue).toFixed(2)}
          </Box>
        );
      },
    },
 
    {
      field: "return_percentage",
      headerName: "Return %",
      width: 120,
 
      renderCell: (params) => {
        const value = params.value;
        const numericValue = value == null ? null : Number(value);

        if (numericValue == null || Number.isNaN(numericValue)) {
          return "-";
        }

        return (
          <Box
            component="span"
            sx={{
              color: numericValue < 0 ? "error.main" : "success.main",
              fontWeight: 600,
            }}
          >
            {`${Number(numericValue).toFixed(2)}%`}
          </Box>
        );
      },
    },

    {
        field: "actions",
        
        headerName: "Actions",
        
        width: 150,
        
        sortable: false,
        
        filterable: false,
        
        renderCell: (params) => {
          if (portfolio.status === "CLOSED") {
            return (
              <Typography color="text.secondary" fontSize="13px">
                View Only
              </Typography>
            );
          }

          if (portfolio.status === "NEW") {
            return (
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  width: "100%",
                  height: "100%",
                }}
              >
                <Tooltip title="Buy More">
                  <IconButton
                    size="small"
                    color="primary"
                    onClick={() => openBuyMore(params.row)}
                    sx={{
                      backgroundColor: "#1976d2",
                      color: "white",
                      width: 28,
                      height: 28,
                      minWidth: 28,
                      p: 0,
                      '&:hover': {
                        backgroundColor: "#1565c0",
                      },
                    }}
                  >
                    <AddIcon fontSize="small" />
                  </IconButton>
                </Tooltip>
              </Box>
            );
          }

          return (
            <Box
              sx={{
                display: "flex",
                gap: 0.5,
                alignItems: "center",
                justifyContent: "center",
                width: "100%",
                height: "100%",
                py: 0,
              }}
            >
              <Tooltip title="Buy More">
                <IconButton
                  size="small"
                  color="primary"
                  onClick={() => openBuyMore(params.row)}
                  sx={{
                    backgroundColor: "#1976d2",
                    color: "white",
                    width: 28,
                    height: 28,
                    minWidth: 28,
                    p: 0,
                    '&:hover': {
                      backgroundColor: "#1565c0",
                    },
                  }}
                >
                  <AddIcon fontSize="small" />
                </IconButton>
              </Tooltip>

              <Tooltip title="Sell">
                <IconButton
                  size="small"
                  color="secondary"
                  onClick={() => openSell(params.row)}
                  sx={{
                    border: "1px solid #d0d7de",
                    backgroundColor: "white",
                    color: "#3c3c3c",
                    width: 28,
                    height: 28,
                    minWidth: 28,
                    p: 0,
                  }}
                >
                  <RemoveIcon fontSize="small" />
                </IconButton>
              </Tooltip>

              <Tooltip title="Delete">
                <IconButton
                  size="small"
                  color="error"
                  onClick={() => handleDelete(params.row)}
                  sx={{
                    width: 28,
                    height: 28,
                    minWidth: 28,
                    p: 0,
                  }}
                >
                  <DeleteIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            </Box>
          );
        },
    },
 
  ];
 
 
  if (loading) {
 
    return (
 
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          mt: 8,
        }}
      >
 
        <CircularProgress />
 
      </Box>
 
    );
 
  }
 
 
  if (!portfolio) {
 
    return (
 
      <Box sx={{ p: 4 }}>
 
        <Alert severity="error">
          Portfolio not found
        </Alert>
      </Box>
    );
  }
 
 
  async function handleViewAllocation() { 
  try {
 
    setAllocationLoading(true);
    setAllocationError("");
 
    const data =
      await getPortfolioAllocation(
        portfolioId,
        valuationDate
      );
 
 
    console.log(
      "ALLOCATION RESPONSE:",
      data
    );
 
 
    /*
      Supports either:
      [
        {...},
        {...}
      ]
 
      OR
 
      {
        allocations: [...]
      }
    */
 
    const rows = Array.isArray(data)
      ? data
      : data.allocations ||
        data.allocation ||
        [];
 
 
    setAllocationRows(
      rows.map(
        (item, index) => ({
          ...item,
          id:
            item.asset_class_id ??
            index + 1,
        })
      )
    );
 
 
    setAllocationOpen(true);
 
  }
  catch (err) {
 
    console.error(err);
 
    setAllocationError(
      err.response?.data?.detail ||
      "Unable to load allocation"
    );
 
    setAllocationOpen(true);
 
  }
  finally {
 
    setAllocationLoading(false);
 
  }
}

async function handleViewPerformance() {
 
  try {
 
    setPerformanceLoading(true);
    setPerformanceError("");
 
    const data =
      await getPortfolioPerformance(
        portfolioId,
        valuationDate
      );
 
 
    console.log(
      "PERFORMANCE RESPONSE:",
      data
    );
 
 
    const rows = [
 
      {
        id: 1,
        metric: "Portfolio Return",
        value:
          data.portfolio_return_percentage == null
            ? "-"
            : `${Number(
                data.portfolio_return_percentage
              ).toFixed(2)}%`,
      },
 
      {
        id: 2,
        metric: `${portfolio.benchmark_name || "Benchmark"} Return`,
        value:
          data.benchmark_return_percentage == null
            ? "-"
            : `${Number(
                data.benchmark_return_percentage
              ).toFixed(2)}%`,
      },
 
      {
        id: 3,
        metric: "Relative Performance",
        value:
          data.relative_return_percentage == null
            ? "-"
            : `${Number(
                data.relative_return_percentage
              ).toFixed(2)}%`,
      },
 
      {
        id: 4,
        metric: "Performance Status",
        value:
          data.performance_status || "-",
      },
 
      {
        id: 5,
        metric: "Current Portfolio Value",
        value:
          data.total_current_value == null
            ? "-"
            : `${portfolio.currency} ${Number(
                data.total_current_value
              ).toLocaleString()}`,
      },
 
      {
        id: 6,
        metric: "Profit / Loss",
        value:
          data.total_profit_loss == null
            ? "-"
            : `${portfolio.currency} ${Number(
                data.total_profit_loss
              ).toLocaleString()}`,
      },
 
      {
        id: 7,
        metric: "Benchmark Start Value",
        value:
          data.benchmark_start_value == null
            ? "-"
            : Number(
                data.benchmark_start_value
              ).toFixed(2),
      },
 
      {
        id: 8,
        metric: "Benchmark Current Value",
        value:
          data.benchmark_current_value == null
            ? "-"
            : Number(
                data.benchmark_current_value
              ).toFixed(2),
      },
 
      {
        id: 9,
        metric: "Benchmark Latest Date",
        value:
          data.valuation_date || "-",
      },
 
    ];
 
 
    setPerformanceRows(
      rows
    );
 
    setPerformanceOpen(true);
 
  }
  catch (err) {
 
    console.error(err);
 
    setPerformanceError(
      err.response?.data?.detail ||
      "Unable to load performance"
    );
 
    setPerformanceOpen(true);
 
  }
  finally {
 
    setPerformanceLoading(false);
 
  }
}

function openBuyMore(row) {
 
  setSelectedHolding(row);
 
  setTradeType(
    "BUY_MORE"
  );
 
  setTradeQuantity("");
 
  setTradeError("");
 
  setTradeResult(null);
 
  setTradeOpen(true);
}
 
 
function openSell(row) {
 
  setSelectedHolding(row);
 
  setTradeType(
    "SELL"
  );
 
  setTradeQuantity("");
 
  setTradeError("");
 
  setTradeResult(null);
 
  setTradeOpen(true);
}
 

async function handleTrade() {
 
  if (tradeType === "SELL" && portfolio?.status === "NEW") {
    setTradeError("Portfolio is in NEW status. Activate it before selling holdings.");
    return;
  }

  const quantity = Number(tradeQuantity);

  if (!quantity || quantity <= 0) {
    setTradeError("Enter a valid quantity");
    return;
  }

  if (tradeType === "SELL" && quantity > Number(selectedHolding.quantity)) {
    setTradeError("Sell quantity cannot be greater than available quantity");
    return;
  }

  try {
    setTradeSaving(true);
    setTradeError("");

    let result;

    if (tradeType === "BUY_MORE") {
      result = await buyMoreHolding(
        portfolioId,
        selectedHolding.asset_holding_id,
        {
          quantity: quantity,
          purchase_date: valuationDate,
        }
      );
    }
    else {
      result = await sellHolding(
        portfolioId,
        selectedHolding.asset_holding_id,
        {
          quantity: quantity,
          sell_date: valuationDate,
        }
      );
    }

    setTradeResult(result);
    await loadPortfolio();

    try {
      await getPortfolioAllocation(portfolioId, valuationDate);
    }
    catch (error) {
      console.log(error);
    }
  }
  catch (err) {
    console.error(err);
    setTradeError(err.response?.data?.detail || "Transaction failed");
  }
  finally {
    setTradeSaving(false);
  }
}

async function handleDelete(row) {
  if (portfolio?.status === "NEW") {
    setError("Portfolio is in NEW status. Activate it before deleting holdings.");
    return;
  }

  const confirmed = window.confirm(
    `Delete ${row.symbol} from this portfolio?\n\nDelete is only for correcting/removing an incorrect holding.`
  );

  if (!confirmed) {
    return;
  }

  try {
    await deleteHolding(portfolioId, row.asset_holding_id);
    await loadPortfolio();

    try {
      await getPortfolioAllocation(portfolioId, valuationDate);
    }
    catch (error) {
      console.log(error);
    }
  }
  catch (err) {
    setError(err.response?.data?.detail || "Unable to delete holding");
  }
}

async function handleActivatePortfolio() {
  if (portfolio.status === "ACTIVE") {
    return;
  }

  try {
    setError("");
    await activatePortfolio(portfolioId);
    setPortfolio((prev) => (prev ? { ...prev, status: "ACTIVE" } : prev));
    await loadPortfolio();
  }
  catch (err) {
    console.error(err);
    setError(err.response?.data?.detail || "Unable to activate portfolio");
  }
}

async function handleClosePortfolio(){
   const confirmed=window.confirm("Are you sure you want to close this portfolio?\nAfter closing, no further buying, selling, or holding chnages will be allowed.");
   if(!confirmed){
    return;
   }
    try{
      setError("");
      await closePortfolio(portfolioId);
      setPortfolio((prev) => (prev ? { ...prev, status: "CLOSED" } : prev));
      await loadPortfolio();
    }
    catch(err){
      console.error(err);
      setError(err.response?.data?.detail || "Unable to close portfolio");
    }
}

async function handleStatusChange(event) {
  const nextStatus = event.target.value;

  if (nextStatus === portfolio.status) {
    return;
  }

  if (nextStatus === "NEW") {
    setError("Portfolio remains NEW until it is activated manually.");
    return;
  }

  try {
    setError("");

    if (nextStatus === "ACTIVE") {
      await activatePortfolio(portfolioId);
      setPortfolio((prev) => (prev ? { ...prev, status: "ACTIVE" } : prev));
    }
    else if (nextStatus === "CLOSED") {
      await closePortfolio(portfolioId);
      setPortfolio((prev) => (prev ? { ...prev, status: "CLOSED" } : prev));
    }

    await loadPortfolio();
  }
  catch (err) {
    console.error(err);
    setError(err.response?.data?.detail || "Unable to update portfolio status");
  }
}

const performanceColumns = [
 
  {
    field: "metric",
    headerName: "Performance Metric",
    flex: 1,
    minWidth: 240,
  },
 
  {
    field: "value",
    headerName: "Value",
    flex: 1,
    minWidth: 220,
  },
 
];
 
const allocationColumns = [
 
  {
    field: "asset_class",
    headerName: "Asset Class",
    flex: 1,
    minWidth: 180,
  },
 
  {
    field: "target_percentage",
    headerName: "Target %",
    width: 130,
 
    valueFormatter: (value) =>
      value == null
        ? "-"
        : `${Number(value).toFixed(2)}%`,
  },
 
  {
    field: "current_percentage",
    headerName: "Current %",
    width: 130,
 
    valueFormatter: (value) =>
      value == null
        ? "-"
        : `${Number(value).toFixed(2)}%`,
  },
 
  {
    field: "deviation_percentage",
    headerName: "Deviation %",
    width: 140,
 
    valueFormatter: (value) => {
 
      if (
        value === null ||
        value === undefined
      ) {
        return "-";
      }
 
      const number =
        Number(value);
 
      return `${
        number > 0
          ? "+"
          : ""
      }${number.toFixed(2)}%`;
    },
  },
 
  {
    field: "recommendation",
    headerName: "Recommendation",
    width: 180,
 
    valueGetter: (
      value,
      row
    ) => {
 
      if (row.recommendation) {
        return row.recommendation;
      }
 
      const deviation =
        Number(
          row.deviation_percentage || 0
        );
 
      if (
        Math.abs(deviation) <= 5
      ) {
        return "Within Range";
      }
 
      if (deviation > 5) {
        return "Reduce";
      }
 
      return "Add";
    },
  },
 
  {
    field: "alert",
    headerName: "Status",
    width: 150,
 
    valueGetter: (
      value,
      row
    ) => {
 
      const deviation =
        Math.abs(
          Number(
            row.deviation_percentage || 0
          )
        );
 
      return deviation > 5
        ? "Alert"
        : "OK";
    },
  },
 
];

  return (
 
    <Box
      sx={{
        p: 0,
        minHeight: "100vh",
        backgroundColor: "#f5f6f8",
      }}
    >
 
      <Button
        onClick={() =>
          navigate("/portfolios")
        }
        sx={{
          mb: 1,
          minWidth: 0,
          px: 1.25,
          py: 0.5,
        }}
      >
        ← Back to Portfolios
      </Button>
 
 
      {/* =====================================
          PORTFOLIO HEADER
      ===================================== */}
 
      <Box
        sx={{
          backgroundColor: "white",
          borderRadius: 2,
          mb: 2,
          overflow: "hidden",
        }}
      >
 
        <Box
          sx={{
            p: 1.5,
            pb: 1,
            borderBottom:
              "1px solid #ddd",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            gap: 1.5,
          }}
        >
 
          <Typography
            variant="h5"
            fontWeight="bold"
          >
            Portfolio Header
          </Typography>

          <Link
            component="button"
            underline="hover"
            onClick={handleViewAllocation}
            sx={{
                fontWeight: "bold",
                cursor: "pointer",
                fontSize: "15px",
            }}
          >
            View allocation
          </Link>

          <Link
            component="button"
            underline="hover"
            onClick={handleViewPerformance}
            sx={{
                fontWeight: "bold",
                cursor: "pointer",
                fontSize: "15px",
            }}
          >
            View Performance
          </Link>

          {portfolio.status === "ACTIVE" && (
            <Button variant="outlined"
                    color="error"
                    size="small"
                    onClick={handleClosePortfolio}
            >
              Close Portfolio
            </Button>
          )}
 
        </Box>
 
 
        <Box
          sx={{
            p: 1.5,
            display: "grid",
            gridTemplateColumns:
              "repeat(4, minmax(0, 1fr))",
            gap: 1.25,
          }}
        >
 
          <Info
            label="Portfolio Name"
            value={
              portfolio.portfolio_name
            }
          />
 
 
          <Info
            label="Theme of Investment"
            value={
              portfolio.theme_name
            }
          />
 
 
          <Box>
 
            <Typography
              color="text.secondary"
              sx={{ mb: 0.75 }}
            >
              Status
            </Typography>
 
            <TextField
              select
              size="small"
              value={portfolio.status || "NEW"}
              onChange={handleStatusChange}
              sx={{
                minWidth: 110,
                '& .MuiInputBase-root': {
                  minHeight: 32,
                  fontSize: 13,
                },
              }}
            >
              <MenuItem value="NEW">NEW</MenuItem>
              <MenuItem value="ACTIVE">ACTIVE</MenuItem>
              <MenuItem value="CLOSED">CLOSED</MenuItem>
            </TextField>
 
          </Box>
 
 
          <Info
            label="Available Balance"
            value={(() => {
              const amount = Number(portfolio.amount || 0);
              const invested = Number(valuation?.total_invested_value || 0);
              const sold = Number(
                portfolio.total_sell ??
                portfolio.sell_amount ??
                portfolio.sell_value ??
                0
              );
              const fallbackBalance = amount - invested + sold;
              const balance =
                portfolio.available_balance != null
                  ? Number(portfolio.available_balance)
                  : fallbackBalance;

              return Number.isFinite(balance)
                ? `${portfolio.currency} ${balance.toLocaleString()}`
                : "-";
            })()}
          />
 
 
          <Info
            label="Base Currency"
            value={
              portfolio.currency
            }
          />
 
 
          <Info
            label="Exchange"
            value={
              portfolio.exchange
            }
          />
 
 
          <Info
            label="Initial Investment"
            value={
              `${portfolio.currency} ${Number(
                portfolio.amount || 0
              ).toLocaleString()}`
            }
          />
 
 
          <Info
            label="Current Value of Investment"
            value={
              valuation
                ? `${portfolio.currency} ${Number(
                    valuation
                      .total_current_value
                  ).toLocaleString()}`
                : "-"
            }
          />
 
 
          <Info
            label="Benchmark"
            value={
              portfolio.benchmark_name
            }
          />
 
 
          <Info
            label="Rebalancing Frequency"
            value={
              portfolio
                .rebalancing_frequency
            }
          />
 
 
          <Info
            label="Invested Value"
            value={
              valuation
                ? `${portfolio.currency} ${Number(
                    valuation
                      .total_invested_value
                  ).toLocaleString()}`
                : "-"
            }
          />
 
 
          <Box>
 
            <Typography
              color="text.secondary"
              sx={{
                mb: 0.5,
              }}
            >
              Valuation Date
            </Typography>
 
            <TextField
              select
              size="small"
              value={
                valuationDate
              }
              onChange={(event) =>
                setValuationDate(
                  event.target.value
                )
              }
              sx={{
                minWidth: 180,
              }}
            >
 
              <MenuItem
                value="2026-10-01"
              >
                01-10-2026
              </MenuItem>
 
              <MenuItem
                value="2026-10-02"
              >
                02-10-2026
              </MenuItem>
 
            </TextField>
 
          </Box>
 
        </Box>
 
      </Box>
 
 
      {/* =====================================
          PORTFOLIO COMPOSITION
      ===================================== */}
 
      <Box
        sx={{
          display: "flex",
          justifyContent:
            "space-between",
          alignItems: "center",
          mb: 1,
        }}
      >
 
        <Box>
 
          <Typography
            variant="h5"
            fontWeight="bold"
          >
            Portfolio Details
            {" "}
            (Composition)
          </Typography>
 
          <Typography
            color="text.secondary"
          >
            Total Holdings:{" "}
            {holdings.length}
          </Typography>
 
        </Box>
 
        {portfolio.status !== "CLOSED" && (
          <Button
              variant="contained"
              onClick={() =>
                setAddOpen(true)
              }
            >
              + Add Holding
            </Button>
        )}
 
      </Box>
 
 
      <Box
        sx={{
          height: 500,
          width: "100%",
          backgroundColor: "white",
        }}
      >
 
        <DataGrid
 
          rows={
            compositionRows
          }
 
          columns={
            columns
          }
 
          getRowId={
            (row) =>
              row.asset_holding_id
          }
 
          pageSizeOptions={[
            5,
            10,
            25,
            50,
            100,
          ]}
 
          initialState={{
            pagination: {
              paginationModel: {
                page: 0,
                pageSize: 10,
              },
            },
          }}
 
          disableRowSelectionOnClick
 
          showToolbar
 
        />
 
      </Box>
 
 
      <AddHoldingDialog
 
        open={
          addOpen
        }
 
        portfolio={
          portfolio
        }
 
        onClose={() =>
          setAddOpen(false)
        }
 
        onAdded={async () => {
 
          await loadPortfolio();
 
        }}
 
      />

      <Dialog
        open={allocationOpen}
        
        onClose={() =>
            setAllocationOpen(false)
        }
        
        fullWidth
        maxWidth="md"
        >
        
        <DialogTitle>
        
            Current vs Target Allocation
        
        </DialogTitle>
        
        
        <DialogContent>
        
            <Typography
            sx={{
                mb: 2,
            }}
            >
        
            Portfolio:{" "}
        
            <strong>
                {portfolio.portfolio_name}
            </strong>
        
            {" | "}
        
            Theme:{" "}
        
            <strong>
                {portfolio.theme_name}
            </strong>
        
            {" | "}
        
            Valuation Date:{" "}
        
            <strong>
                {valuationDate}
            </strong>
        
            </Typography>
        
        
            {allocationError && (
        
            <Alert
                severity="error"
                sx={{
                mb: 2,
                }}
            >
                {allocationError}
            </Alert>
        
            )}
        
        
            <Box
            sx={{
                height: 420,
                width: "100%",
            }}
            >
        
            <DataGrid
        
                rows={
                allocationRows
                }
        
                columns={
                allocationColumns
                }
        
                loading={
                allocationLoading
                }
        
                getRowId={
                (row) =>
                    row.id
                }
        
                pageSizeOptions={[
                5,
                10,
                25,
                ]}
        
                initialState={{
                pagination: {
                    paginationModel: {
                    page: 0,
                    pageSize: 10,
                    },
                },
                }}
        
                disableRowSelectionOnClick
        
            />
        
            </Box>
        
        </DialogContent>
        
        
        <DialogActions>
        
            <Button
            onClick={() =>
                setAllocationOpen(false)
            }
            >
            Close
            </Button>
        
        </DialogActions>
        
        </Dialog>

        <Dialog
 
            open={
                performanceOpen
            }
            
            onClose={() =>
                setPerformanceOpen(false)
            }
            
            fullWidth
            
            maxWidth="md"
            
            >
            
            <DialogTitle>
            
                Portfolio vs Benchmark Performance
            
            </DialogTitle>
            
            
            <DialogContent>
            
                <Typography
                sx={{
                    mb: 2,
                }}
                >
            
                Portfolio:{" "}
            
                <strong>
                    {portfolio.portfolio_name}
                </strong>
            
                {" | "}
            
                Benchmark:{" "}
            
                <strong>
                    {portfolio.benchmark_name}
                </strong>
            
                {" | "}
            
                Valuation Date:{" "}
            
                <strong>
                    {valuationDate}
                </strong>
            
                </Typography>
            
            
                {performanceError && (
            
                <Alert
                    severity="error"
                    sx={{
                    mb: 2,
                    }}
                >
                    {performanceError}
                </Alert>
            
                )}
            
            
                <Box
                sx={{
                    height: 470,
                    width: "100%",
                }}
                >
            
                <DataGrid
            
                    rows={
                    performanceRows
                    }
            
                    columns={
                    performanceColumns
                    }
            
                    loading={
                    performanceLoading
                    }
            
                    getRowId={
                    row =>
                        row.id
                    }
            
                    hideFooter
            
                    disableRowSelectionOnClick
            
                />
            
                </Box>
            
            </DialogContent>
            
            
            <DialogActions>
            
                <Button
                onClick={() =>
                    setPerformanceOpen(false)
                }
                >
                Close
                </Button>
            
            </DialogActions>
        
        </Dialog>

        <Dialog
            open={tradeOpen}
            
            onClose={() =>
                setTradeOpen(false)
            }
            
            fullWidth
            
            maxWidth="sm"
            >
            
            <DialogTitle>
            
                {
                tradeType === "BUY_MORE"
                    ? "Buy More"
                    : "Sell Holding"
                }
            
            </DialogTitle>
            
            
            <DialogContent>
            
                {selectedHolding && (
            
                <Box sx={{ mt: 1 }}>
            
                    <Typography
                    sx={{
                        mb: 2,
                    }}
                    >
            
                    <strong>
                        {selectedHolding.symbol}
                    </strong>
            
                    {" - "}
            
                    {
                        selectedHolding
                        .security_name
                    }
            
                    </Typography>
            
            
                    <Box
                    sx={{
                        display: "grid",
                        gridTemplateColumns:
                        "1fr 1fr",
                        gap: 2,
                    }}
                    >
            
                    <TextField
                        label="Available Quantity"
            
                        value={
                        selectedHolding.quantity
                        }
            
                        slotProps={{
                        input: {
                            readOnly: true,
                        },
                        }}
                    />
            
            
                    <TextField
                        label={
                        tradeType ===
                        "BUY_MORE"
                            ? "Purchase Price"
                            : "Sell Price"
                        }
            
                        value={
                        selectedHolding
                            .current_price != null
                            ? Number(
                                selectedHolding
                                .current_price
                            ).toFixed(2)
                            : "-"
                        }
            
                        slotProps={{
                        input: {
                            readOnly: true,
                        },
                        }}
                    />
            
            
                    <TextField
            
                        label={
                        tradeType ===
                        "BUY_MORE"
                            ? "Quantity to Buy"
                            : "Quantity to Sell"
                        }
            
                        type="number"
            
                        value={
                        tradeQuantity
                        }
            
                        onChange={(event) =>
                        setTradeQuantity(
                            event.target.value
                        )
                        }
            
                        slotProps={{
                        htmlInput: {
                            min: 0.0001,
            
                            max:
                            tradeType ===
                            "SELL"
                                ? selectedHolding
                                    .quantity
                                : undefined,
                        },
                        }}
                    />
            
            
                    <TextField
                        label={
                        tradeType ===
                        "BUY_MORE"
                            ? "Purchase Value"
                            : "Sale Value"
                        }
            
                        value={
                        selectedHolding
                            .current_price != null
                            ?
                            (
                            Number(
                                tradeQuantity || 0
                            )
                            *
                            Number(
                                selectedHolding
                                .current_price
                            )
                            ).toFixed(2)
                            :
                            "-"
                        }
            
                        slotProps={{
                        input: {
                            readOnly: true,
                        },
                        }}
                    />
            
                    </Box>
            
            
                    {tradeError && (
            
                    <Alert
                        severity="error"
                        sx={{
                        mt: 2,
                        }}
                    >
                        {tradeError}
                    </Alert>
            
                    )}
            
            
                    {tradeResult &&
                    tradeType === "SELL" && (
            
                    <Alert
                        severity={
                        Number(
                            tradeResult
                            .realized_profit_loss
                        ) >= 0
                            ? "success"
                            : "warning"
                        }
            
                        sx={{
                        mt: 2,
                        }}
                    >
            
                        Sale Value:{" "}
                        {portfolio.currency}{" "}
                        {
                        Number(
                            tradeResult.sale_value
                        ).toFixed(2)
                        }
            
                        <br />
            
                        Realized P/L:{" "}
                        {portfolio.currency}{" "}
                        {
                        Number(
                            tradeResult
                            .realized_profit_loss
                        ).toFixed(2)
                        }
            
                        <br />
            
                        Remaining Quantity:{" "}
                        {
                        tradeResult
                            .remaining_quantity
                        }
            
                    </Alert>
            
                    )}
            
            
                    {tradeResult &&
                    tradeType ===
                    "BUY_MORE" && (
            
                    <Alert
                        severity="success"
                        sx={{
                        mt: 2,
                        }}
                    >
            
                        New Quantity:{" "}
                        {
                        tradeResult
                            .new_quantity
                        }
            
                        <br />
            
                        New Average Buy Price:{" "}
                        {
                        Number(
                            tradeResult
                            .average_buy_price
                        ).toFixed(2)
                        }
            
                    </Alert>
            
                    )}
            
                </Box>
            
                )}
            
            </DialogContent>
            
            
            <DialogActions>
            
                <Button
                onClick={() =>
                    setTradeOpen(false)
                }
                >
                Close
                </Button>
            
            
                {!tradeResult && (
            
                <Button
                    variant="contained"
            
                    color={
                    tradeType === "SELL"
                        ? "warning"
                        : "primary"
                    }
            
                    disabled={
                    tradeSaving
                    }
            
                    onClick={
                    handleTrade
                    }
                >
            
                    {
                    tradeSaving
                        ? "Processing..."
                        : tradeType ===
                        "BUY_MORE"
                        ? "Buy"
                        : "Sell"
                    }
            
                </Button>
            
                )}
            
            </DialogActions>
            
            </Dialog>
 
 
    </Box>
 
  );
 
}

function Info({label, value,}){
    return(
        <Box sx={{ display: "flex", flexDirection: "column", gap: 0.25 }}>
            <Typography color="text.secondary" sx={{ lineHeight: 1.3 }}>
                {label}
            </Typography>
            <Typography fontWeight="bold" sx={{ lineHeight: 1.3 }}>
                {
                    value === null ||
                    value === undefined ||
                    value === "" ? "-" : value
                }
            </Typography>
        </Box>
    );
}

export default PortfolioView;