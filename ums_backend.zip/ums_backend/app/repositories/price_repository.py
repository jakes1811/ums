from app.database.connection import get_db_connection
 
 
class PriceRepository:
 
    @staticmethod
    def get_price_by_date(
        security_id: int,
        trade_date
    ):
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            cursor.execute(
                """
                SELECT
                    p.price_id,
                    p.security_id,
                    s.symbol,
                    s.security_name,
                    s.stock_exchange,
                    s.currency,
                    p.trade_date,
                    p.previous_close,
                    p.open_price,
                    p.high_price,
                    p.low_price,
                    p.close_price,
                    p.volume,
                    p.turnover
 
                FROM market_price p
 
                JOIN unified_security_master s
                ON s.security_id = p.security_id
 
                WHERE
                    p.security_id = %s
                    AND
                    p.trade_date = %s;
                """,
                (
                    security_id,
                    trade_date
                )
            )
 
            row = cursor.fetchone()
 
            if row is None:
                return None
 
            return {
                "price_id": row[0],
                "security_id": row[1],
                "symbol": row[2],
                "security_name": row[3],
                "stock_exchange": row[4],
                "currency": row[5],
                "trade_date": row[6],
                "previous_close": row[7],
                "open_price": row[8],
                "high_price": row[9],
                "low_price": row[10],
                "close_price": row[11],
                "volume": row[12],
                "turnover": row[13]
            }
 
        finally:
 
            cursor.close()
            conn.close()

    @staticmethod
    def get_all_prices_for_security(
        security_id: int
    ):
    
        conn = get_db_connection()
        cursor = conn.cursor()
    
        try:
    
            cursor.execute(
                """
                SELECT
                    price_id,
                    security_id,
                    trade_date,
                    previous_close,
                    open_price,
                    high_price,
                    low_price,
                    close_price,
                    volume,
                    turnover
    
                FROM market_price
    
                WHERE security_id = %s
    
                ORDER BY trade_date;
                """,
                (security_id,)
            )
    
            rows = cursor.fetchall()
    
            return [
                {
                    "price_id": row[0],
                    "security_id": row[1],
                    "trade_date": row[2],
                    "previous_close": row[3],
                    "open_price": row[4],
                    "high_price": row[5],
                    "low_price": row[6],
                    "close_price": row[7],
                    "volume": row[8],
                    "turnover": row[9]
                }
                for row in rows
            ]
    
        finally:
            cursor.close()
            conn.close()

    @staticmethod
    def get_market_prices(
        page: int,
        page_size: int,
        search: str | None = None,
        exchange: str | None = None,
        trade_date=None
    ):
    
        conn = get_db_connection()
        cursor = conn.cursor()
    
        try:
    
            conditions = []
            values = []
    
    
            # =========================================
            # SEARCH
            # =========================================
    
            if search:
    
                conditions.append("""
                    (
                        s.symbol ILIKE %s
                        OR
                        s.security_name ILIKE %s
                        OR
                        s.isin ILIKE %s
                    )
                """)
    
                search_value = f"%{search}%"
    
                values.extend([
                    search_value,
                    search_value,
                    search_value
                ])
    
    
            # =========================================
            # EXCHANGE
            # =========================================
    
            if exchange:
    
                conditions.append(
                    "s.stock_exchange = %s"
                )
    
                values.append(exchange)
    
    
            # =========================================
            # TRADE DATE
            # =========================================
    
            if trade_date:
    
                conditions.append(
                    "p.trade_date = %s"
                )
    
                values.append(trade_date)
    
    
            where_clause = ""
    
            if conditions:
    
                where_clause = (
                    " WHERE "
                    + " AND ".join(conditions)
                )
    
    
            # =========================================
            # TOTAL COUNT
            # =========================================
    
            count_query = f"""
                SELECT COUNT(*)
    
                FROM market_price p
    
                JOIN unified_security_master s
                ON s.security_id = p.security_id
    
                {where_clause};
            """
    
    
            cursor.execute(
                count_query,
                values
            )
    
            total = cursor.fetchone()[0]
    
    
            # =========================================
            # DATA
            # =========================================
    
            offset = (
                page - 1
            ) * page_size
    
    
            data_query = f"""
                SELECT
                    p.price_id,
                    p.security_id,
                    s.symbol,
                    s.security_name,
                    s.stock_exchange,
                    s.currency,
                    p.trade_date,
                    p.previous_close,
                    p.open_price,
                    p.high_price,
                    p.low_price,
                    p.close_price,
                    p.volume,
                    p.turnover
    
                FROM market_price p
    
                JOIN unified_security_master s
                ON s.security_id = p.security_id
    
                {where_clause}
    
                ORDER BY
                    p.trade_date,
                    p.security_id
    
                LIMIT %s
                OFFSET %s;
            """
    
    
            data_values = (
                values
                +
                [
                    page_size,
                    offset
                ]
            )
    
    
            cursor.execute(
                data_query,
                data_values
            )
    
            rows = cursor.fetchall()
    
    
            result = []
    
            for row in rows:
    
                result.append({
    
                    "price_id": row[0],
    
                    "security_id": row[1],
    
                    "symbol": row[2],
    
                    "security_name": row[3],
    
                    "stock_exchange": row[4],
    
                    "currency": row[5],
    
                    "trade_date": row[6],
    
                    "previous_close": row[7],
    
                    "open_price": row[8],
    
                    "high_price": row[9],
    
                    "low_price": row[10],
    
                    "close_price": row[11],
    
                    "volume": row[12],
    
                    "turnover": row[13]
                })
    
    
            return {
    
                "rows": result,
    
                "total": total,
    
                "page": page,
    
                "page_size": page_size
            }
    
    
        finally:
    
            cursor.close()
            conn.close()
    
    
    @staticmethod
    def get_trade_dates():
    
        conn = get_db_connection()
        cursor = conn.cursor()
    
        try:
    
            cursor.execute("""
                SELECT DISTINCT trade_date
                FROM market_price
                ORDER BY trade_date;
            """)
    
            rows = cursor.fetchall()
    
            return [
                row[0]
                for row in rows
            ]
    
        finally:
    
            cursor.close()
            conn.close()
    