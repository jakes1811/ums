import asyncio
from datetime import date

import pytest

from app.services.holding_service import HoldingService


def test_sell_holding_is_blocked_when_portfolio_is_new(monkeypatch):
    monkeypatch.setattr(
        "app.repositories.portfolio_repository.PortfolioRepository.get_portfolio_by_id",
        lambda portfolio_id: {"status": "NEW"},
    )
    monkeypatch.setattr(
        "app.repositories.holding_repository.HoldingRepository.get_holding_by_id",
        lambda holding_id: {
            "portfolio_id": 7,
            "security_id": 3,
            "quantity": 10,
            "security_price": 100.0,
        },
    )

    with pytest.raises(ValueError, match="NEW.*ACTIVE"):
        asyncio.run(HoldingService.sell_holding(7, 55, 2, date(2026, 10, 1)))


def test_sell_holding_allows_active_portfolio(monkeypatch):
    monkeypatch.setattr(
        "app.repositories.portfolio_repository.PortfolioRepository.get_portfolio_by_id",
        lambda portfolio_id: {"status": "ACTIVE"},
    )
    monkeypatch.setattr(
        "app.repositories.holding_repository.HoldingRepository.get_holding_by_id",
        lambda holding_id: {
            "portfolio_id": 7,
            "security_id": 3,
            "quantity": 10,
            "security_price": 100.0,
        },
    )
    async def fake_get_security_price(security_id, sell_date):
        return {"close_price": "105"}

    monkeypatch.setattr(
        "app.services.ums_service.UMSService.get_security_price",
        fake_get_security_price,
    )
    monkeypatch.setattr(
        "app.repositories.holding_repository.HoldingRepository.update_holding",
        lambda **kwargs: None,
    )
    monkeypatch.setattr(
        "app.repositories.transaction_repository.TransactionRepository.create_transaction",
        lambda **kwargs: None,
    )

    result = asyncio.run(HoldingService.sell_holding(7, 55, 2, date(2026, 10, 1)))

    assert result["message"] == "Security sold successfully"
