from app.database.connection import get_db_connection
 
 
class MasterRepository:
 
    # =========================================================
    # ASSET CLASS
    # =========================================================
 
    @staticmethod
    def get_asset_classes():
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            cursor.execute("""
                SELECT
                    asset_class_id,
                    asset_class,
                    asset_description,
                    sub_asset_class,
                    risk,
                    investment_horizon,
                    sub_asset_description,
                    equity_category
 
                FROM asset_class
 
                ORDER BY asset_class_id;
            """)
 
            rows = cursor.fetchall()
 
            return [
                {
                    "asset_class_id": row[0],
                    "asset_class": row[1],
                    "asset_description": row[2],
                    "sub_asset_class": row[3],
                    "risk": row[4],
                    "investment_horizon": row[5],
                    "sub_asset_description": row[6],
                    "equity_category": row[7]
                }
                for row in rows
            ]
 
        finally:
            cursor.close()
            conn.close()
 
 
    @staticmethod
    def create_asset_class(data):
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            cursor.execute(
                """
                INSERT INTO asset_class
                (
                    asset_class,
                    asset_description,
                    sub_asset_class,
                    risk,
                    investment_horizon,
                    sub_asset_description,
                    equity_category
                )
                VALUES
                (%s,%s,%s,%s,%s,%s,%s)
 
                RETURNING asset_class_id;
                """,
                (
                    data["asset_class"],
                    data.get("asset_description"),
                    data.get("sub_asset_class"),
                    data.get("risk"),
                    data.get("investment_horizon"),
                    data.get("sub_asset_description"),
                    data.get("equity_category")
                )
            )
 
            asset_class_id = cursor.fetchone()[0]
 
            conn.commit()
 
            return {
                "message": "Asset class created successfully",
                "asset_class_id": asset_class_id
            }
 
        except:
            conn.rollback()
            raise
 
        finally:
            cursor.close()
            conn.close()
 
 
    @staticmethod
    def update_asset_class(asset_class_id, data):
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            cursor.execute(
                """
                UPDATE asset_class
 
                SET
                    asset_class = %s,
                    asset_description = %s,
                    sub_asset_class = %s,
                    risk = %s,
                    investment_horizon = %s,
                    sub_asset_description = %s,
                    equity_category = %s
 
                WHERE asset_class_id = %s;
                """,
                (
                    data["asset_class"],
                    data.get("asset_description"),
                    data.get("sub_asset_class"),
                    data.get("risk"),
                    data.get("investment_horizon"),
                    data.get("sub_asset_description"),
                    data.get("equity_category"),
                    asset_class_id
                )
            )
 
            updated = cursor.rowcount
 
            conn.commit()
 
            return updated
 
        except:
            conn.rollback()
            raise
 
        finally:
            cursor.close()
            conn.close()
 
 
    # =========================================================
    # GICS
    # =========================================================
 
    @staticmethod
    def get_gics():
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            cursor.execute("""
                SELECT
                    gics_id,
                    sector_code,
                    sector_name,
                    industry,
                    industry_name,
                    description
 
                FROM gics
 
                ORDER BY gics_id;
            """)
 
            rows = cursor.fetchall()
 
            return [
                {
                    "gics_id": row[0],
                    "sector_code": row[1],
                    "sector_name": row[2],
                    "industry": row[3],
                    "industry_name": row[4],
                    "description": row[5]
                }
                for row in rows
            ]
 
        finally:
            cursor.close()
            conn.close()
 
 
    # =========================================================
    # THEMES
    # =========================================================
 
    @staticmethod
    def get_themes():
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            cursor.execute("""
                SELECT
                    theme_id,
                    theme_name,
                    description,
                    risk_level,
                    investment_horizon,
                    status
 
                FROM investment_theme
 
                ORDER BY theme_id;
            """)
 
            rows = cursor.fetchall()
 
            return [
                {
                    "theme_id": row[0],
                    "theme_name": row[1],
                    "description": row[2],
                    "risk_level": row[3],
                    "investment_horizon": row[4],
                    "status": row[5]
                }
                for row in rows
            ]
 
        finally:
            cursor.close()
            conn.close()
 
 
    @staticmethod
    def create_theme(data):
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            cursor.execute(
                """
                INSERT INTO investment_theme
                (
                    theme_name,
                    description,
                    risk_level,
                    investment_horizon,
                    status
                )
 
                VALUES (%s,%s,%s,%s,%s)
 
                RETURNING theme_id;
                """,
                (
                    data["theme_name"],
                    data.get("description"),
                    data.get("risk_level"),
                    data.get("investment_horizon"),
                    data.get("status", "ACTIVE")
                )
            )
 
            theme_id = cursor.fetchone()[0]
 
            conn.commit()
 
            return {
                "message": "Theme created successfully",
                "theme_id": theme_id
            }
 
        except:
            conn.rollback()
            raise
 
        finally:
            cursor.close()
            conn.close()
 
 
    @staticmethod
    def update_theme(theme_id, data):
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            cursor.execute(
                """
                UPDATE investment_theme
 
                SET
                    theme_name = %s,
                    description = %s,
                    risk_level = %s,
                    investment_horizon = %s,
                    status = %s
 
                WHERE theme_id = %s;
                """,
                (
                    data["theme_name"],
                    data.get("description"),
                    data.get("risk_level"),
                    data.get("investment_horizon"),
                    data.get("status", "ACTIVE"),
                    theme_id
                )
            )
 
            updated = cursor.rowcount
 
            conn.commit()
 
            return updated
 
        except:
            conn.rollback()
            raise
 
        finally:
            cursor.close()
            conn.close()
 
 
    # =========================================================
    # THEME ALLOCATION
    # =========================================================
 
    @staticmethod
    def get_theme_allocations(theme_id):
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            cursor.execute(
                """
                SELECT
                    ta.theme_allocation_id,
                    ta.theme_id,
                    t.theme_name,
                    ta.asset_class_id,
                    a.asset_class,
                    ta.target_percentage
                FROM theme_allocation ta
                JOIN investment_theme t
                ON t.theme_id = ta.theme_id
                JOIN asset_class a
                ON a.asset_class_id = ta.asset_class_id
                WHERE ta.theme_id = %s
                ORDER BY a.asset_class;
                """,
                (theme_id,)
            )
 
            rows = cursor.fetchall()
 
            return [
                {
                    "theme_allocation_id": row[0],
                    "theme_id": row[1],
                    "theme_name": row[2],
                    "asset_class_id": row[3],
                    "asset_class": row[4],
                    "target_percentage": row[5]
                }
                for row in rows
            ]
 
        finally:
            cursor.close()
            conn.close()
 
 
    # =========================================================
    # BENCHMARK
    # =========================================================
 
    @staticmethod
    def get_benchmarks():
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            cursor.execute("""
                SELECT
                    benchmark_id,
                    benchmark_code,
                    benchmark_name,
                    exchange,
                    country,
                    currency,
                    description,
                    status,
                    trade_date,
                    previous_close,
                    close_price
 
                FROM benchmark
 
                ORDER BY benchmark_id;
            """)
 
            rows = cursor.fetchall()
 
            return [
                {
                    "benchmark_id": row[0],
                    "benchmark_code": row[1],
                    "benchmark_name": row[2],
                    "exchange": row[3],
                    "country": row[4],
                    "currency": row[5],
                    "description": row[6],
                    "status": row[7],
                    "trade_date": row[8],
                    "previous_close": row[9],
                    "close_price": row[10]
                }
                for row in rows
            ]
 
        finally:
            cursor.close()
            conn.close()

    @staticmethod
    def save_theme_allocations(
        theme_id,
        allocations
    ):
    
        conn = get_db_connection()
        cursor = conn.cursor()
    
        try:
    
            # -----------------------------------------
            # Validate theme
            # -----------------------------------------
    
            cursor.execute(
                """
                SELECT theme_id
                FROM investment_theme
                WHERE theme_id = %s;
                """,
                (theme_id,)
            )
    
            if cursor.fetchone() is None:
    
                return False
    
    
            # -----------------------------------------
            # Save every asset allocation
            # -----------------------------------------
    
            for item in allocations:
    
                cursor.execute(
                    """
                    INSERT INTO theme_allocation
                    (
                        theme_id,
                        asset_class_id,
                        target_percentage
                    )
                    VALUES
                    (
                        %s,
                        %s,
                        %s
                    )
    
                    ON CONFLICT
                    (
                        theme_id,
                        asset_class_id
                    )
    
                    DO UPDATE SET
    
                        target_percentage =
                        EXCLUDED.target_percentage;
                    """,
                    (
                        theme_id,
                        item["asset_class_id"],
                        item["target_percentage"]
                    )
                )
    
    
            conn.commit()
    
            return True
    
    
        except Exception:
    
            conn.rollback()
            raise
    
    
        finally:
    
            cursor.close()
            conn.close()