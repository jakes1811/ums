import {
  useEffect,
  useState,
} from "react";
 
import {
  Box,
  Button,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Typography,
} from "@mui/material";
 
import {
  DataGrid,
} from "@mui/x-data-grid";
 
import RefreshIcon
  from "@mui/icons-material/Refresh";
 
import {
  getMarketPrices,
  getMarketPriceDates,
} from "../api/api";
 
 
function MarketPrices() {
 
  const [rows, setRows] =
    useState([]);
 
  const [totalRows, setTotalRows] =
    useState(0);
 
  const [loading, setLoading] =
    useState(false);
 
  const [dates, setDates] =
    useState([]);
 
 
  const [
    paginationModel,
    setPaginationModel
  ] = useState({
    page: 0,
    pageSize: 50,
  });
 
 
  const [search, setSearch] =
    useState("");
 
  const [exchange, setExchange] =
    useState("");
 
  const [tradeDate, setTradeDate] =
    useState("");

  useEffect(() => {
 
    async function loadDates() {
 
      try {
 
        const data =
          await getMarketPriceDates();
 
        setDates(data);
 
      }
      catch (error) {
 
        console.error(
          "Date loading error:",
          error
        );
      }
    }
 
    loadDates();
 
  }, []);
 

 
  async function loadPrices() {
 
    try {
 
      setLoading(true);
 
 
      const data =
        await getMarketPrices({
 
          page:
            paginationModel.page + 1,
 
          pageSize:
            paginationModel.pageSize,
 
          search,
 
          exchange,
 
          tradeDate,
        });
 
 
      setRows(data.rows);
 
      setTotalRows(data.total);
 
    }
    catch (error) {
 
      console.error(
        "Price loading error:",
        error
      );
 
    }
    finally {
 
      setLoading(false);
    }
  }
 
 
  useEffect(() => {
 
    loadPrices();
 
  }, [
    paginationModel.page,
    paginationModel.pageSize,
    exchange,
    tradeDate,
  ]);

 
  function handleSearch() {
 
    if (
      paginationModel.page === 0
    ) {
 
      loadPrices();
 
    }
    else {
 
      setPaginationModel(
        previous => ({
          ...previous,
          page: 0,
        })
      );
    }
  }
 
 
  function handleReset() {
 
    setSearch("");
 
    setExchange("");
 
    setTradeDate("");
 
    setPaginationModel({
      page: 0,
      pageSize: 50,
    });
  }

 
  const columns = [
 
    {
      field: "price_id",
      headerName: "Price ID",
      width: 100,
    },
 
    {
      field: "security_id",
      headerName: "Security ID",
      width: 110,
    },
 
    {
      field: "symbol",
      headerName: "Symbol",
      width: 140,
    },
 
    {
      field: "security_name",
      headerName: "Security Name",
      width: 250,
    },
 
    {
      field: "stock_exchange",
      headerName: "Exchange",
      width: 120,
    },
 
    {
      field: "trade_date",
      headerName: "Trade Date",
      width: 140,
    },
 
    {
      field: "previous_close",
      headerName: "Previous Close",
      width: 150,
    },
 
    {
      field: "open_price",
      headerName: "Open",
      width: 120,
    },
 
    {
      field: "high_price",
      headerName: "High",
      width: 120,
    },
 
    {
      field: "low_price",
      headerName: "Low",
      width: 120,
    },
 
    {
      field: "close_price",
      headerName: "Close",
      width: 120,
    },
 
    {
      field: "volume",
      headerName: "Volume",
      width: 150,
    },
 
    {
      field: "turnover",
      headerName: "Turnover",
      width: 180,
    },
 
    {
      field: "currency",
      headerName: "Currency",
      width: 100,
    },
  ];
 
 
  return (
 
    <Box>
 
      <Typography
        variant="h4"
        fontWeight="bold"
        sx={{
          mb: 1,
        }}
      >
        Market Prices
      </Typography>
 
 
      <Typography
        color="text.secondary"
        sx={{
          mb: 3,
        }}
      >
        Two-day market price data
        for Unified Security Master
      </Typography>
 
 
      {/* FILTERS */}
 
      <Box
        sx={{
          display: "grid",
 
          gridTemplateColumns:
            "2fr 1fr 1fr auto auto",
 
          gap: 2,
 
          mb: 3,
 
          alignItems: "center",
        }}
      >
 
        <TextField
 
          label="Search security"
 
          size="small"
 
          value={search}
 
          onChange={
            (event) =>
              setSearch(
                event.target.value
              )
          }
 
          onKeyDown={
            (event) => {
 
              if (
                event.key === "Enter"
              ) {
 
                handleSearch();
              }
            }
          }
 
        />
 
 
        <FormControl
          size="small"
        >
 
          <InputLabel>
            Exchange
          </InputLabel>
 
          <Select
 
            label="Exchange"
 
            value={exchange}
 
            onChange={
              (event) => {
 
                setExchange(
                  event.target.value
                );
 
                setPaginationModel(
                  previous => ({
                    ...previous,
                    page: 0,
                  })
                );
              }
            }
          >
 
            <MenuItem value="">
              All
            </MenuItem>
 
            <MenuItem value="NSE">
              NSE
            </MenuItem>
 
            <MenuItem value="NASDAQ">
              NASDAQ
            </MenuItem>
 
            <MenuItem value="LSE">
              LSE
            </MenuItem>
 
          </Select>
 
        </FormControl>
 
 
        <FormControl
          size="small"
        >
 
          <InputLabel>
            Trade Date
          </InputLabel>
 
          <Select
 
            label="Trade Date"
 
            value={tradeDate}
 
            onChange={
              (event) => {
 
                setTradeDate(
                  event.target.value
                );
 
                setPaginationModel(
                  previous => ({
                    ...previous,
                    page: 0,
                  })
                );
              }
            }
          >
 
            <MenuItem value="">
              All Dates
            </MenuItem>
 
 
            {
              dates.map(
                (date) => (
 
                  <MenuItem
                    key={date}
                    value={date}
                  >
                    {date}
                  </MenuItem>
 
                )
              )
            }
 
          </Select>
 
        </FormControl>
 
 
        <Button
          variant="contained"
          onClick={
            handleSearch
          }
        >
          Search
        </Button>
 
 
        <Button
 
          variant="outlined"
 
          startIcon={
            <RefreshIcon />
          }
 
          onClick={
            handleReset
          }
 
        >
          Reset
        </Button>
 
      </Box>
 
 
      <Typography
        sx={{
          mb: 1,
        }}
      >
 
        Total Price Records:
 
        {" "}
 
        <strong>
          {totalRows}
        </strong>
 
      </Typography>
 
 
      {/* DATA GRID */}
 
      <Box
        sx={{
          height: 640,
          width: "100%",
        }}
      >
 
        <DataGrid
 
          rows={rows}
 
          columns={columns}
 
          getRowId={
            (row) =>
              row.price_id
          }
 
          loading={loading}
 
 
          paginationMode="server"
 
          rowCount={
            totalRows
          }
 
          paginationModel={
            paginationModel
          }
 
          onPaginationModelChange={
            setPaginationModel
          }
 
          pageSizeOptions={[
            10,
            25,
            50,
            100,
          ]}
 
          disableRowSelectionOnClick
 
          showToolbar
 
        />
 
      </Box>
 
    </Box>
  );
}
 
 
export default MarketPrices;
 