import {
  useEffect,
  useState,
} from "react";
 
import {
  Box,
  Typography,
} from "@mui/material";
 
import {
  DataGrid,
} from "@mui/x-data-grid";
 
import {
  getBenchmarks,
} from "../api/api";
 
 
function Benchmarks() {
 
  const [rows, setRows] =
    useState([]);
 
  const [loading, setLoading] =
    useState(false);
 
  async function loadBenchmarks() {
 
    try {
 
      setLoading(true);
 
      const data =
        await getBenchmarks();
 
      const formattedData =
        data.map(
          (item) => {
 
            let benchmarkReturn = 0;
 
 
            if (
              item.previous_close
              &&
              Number(item.previous_close) !== 0
            ) {
 
              benchmarkReturn = (
 
                (
                  Number(item.close_price)
                  -
                  Number(item.previous_close)
                )
 
                /
 
                Number(
                  item.previous_close
                )
 
                * 100
 
              );
            }
 
 
            return {
 
              ...item,
 
              benchmark_return:
                benchmarkReturn.toFixed(2),
            };
          }
        );
 
 
      setRows(
        formattedData
      );
 
    }
    catch (error) {
 
      console.error(
        "Benchmark loading error:",
        error
      );
 
    }
    finally {
 
      setLoading(false);
    }
  }
 
 
  useEffect(() => {
 
    loadBenchmarks();
 
  }, []);
 
  const columns = [
 
    {
      field: "benchmark_id",
      headerName: "ID",
      width: 70,
    },
 
    {
      field: "benchmark_code",
      headerName: "Code",
      width: 130,
    },
 
    {
      field: "benchmark_name",
      headerName: "Benchmark",
      width: 190,
    },
 
    {
      field: "exchange",
      headerName: "Exchange",
      width: 130,
    },
 
    {
      field: "country",
      headerName: "Country",
      width: 170,
    },
 
    {
      field: "currency",
      headerName: "Currency",
      width: 110,
    },
 
    {
      field: "trade_date",
      headerName: "Trade Date",
      width: 140,
    },
 
    {
      field: "previous_close",
      headerName: "Previous Close",
      width: 160,
    },
 
    {
      field: "close_price",
      headerName: "Close Price",
      width: 150,
    },
 
    {
      field: "benchmark_return",
      headerName: "Return %",
      width: 130,
 
      valueFormatter: (value) =>
        `${value}%`,
    },
 
    {
      field: "status",
      headerName: "Status",
      width: 120,
    },
 
    {
      field: "description",
      headerName: "Description",
      width: 280,
    },
  ];
 
 
  return (
 
    <Box>
 
      <Typography
        variant="h4"
        fontWeight="bold"
        sx={{
          mb: 1,
        }}
      >
        Benchmarks
      </Typography>
 
 
      <Typography
        color="text.secondary"
        sx={{
          mb: 3,
        }}
      >
        Market benchmarks used for
        portfolio performance comparison
      </Typography>
 
 
      <Box
        sx={{
          height: 550,
          width: "100%",
        }}
      >
 
        <DataGrid
 
          rows={rows}
 
          columns={columns}
 
          getRowId={
            (row) =>
              row.benchmark_id
          }
 
          loading={loading}
 
          disableRowSelectionOnClick
 
          hideFooter
 
          showToolbar
 
        />
 
      </Box>
 
    </Box>
  );
}
 
 
export default Benchmarks;