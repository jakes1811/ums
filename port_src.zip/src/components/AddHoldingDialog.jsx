import {
  useEffect,
  useState,
} from "react";
 
import {
  Alert,
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  MenuItem,
  TextField,
  Typography,
} from "@mui/material";
 
import {
  DataGrid,
} from "@mui/x-data-grid";
 
import {
  addHolding,
  getReferenceSecurities,
} from "../api/api";
 
 
function AddHoldingDialog({
  open,
  onClose,
  portfolio,
  onAdded,
}) {
 
  const [rows, setRows] =
    useState([]);
 
  const [total, setTotal] =
    useState(0);
 
  const [loading, setLoading] =
    useState(false);
 
  const [search, setSearch] =
    useState("");
 
  const [appliedSearch, setAppliedSearch] =
    useState("");

  const [equityCategory, setEquityCategory] =
    useState("All");
 
  const [quantityMap, setQuantityMap] =
    useState({});
 
  const [message, setMessage] =
    useState("");
 
  const [error, setError] =
    useState("");
 
 
  const [
    paginationModel,
    setPaginationModel,
  ] = useState({
 
    page: 0,
    pageSize: 25,
 
  });
 
 
  async function loadSecurities() {
 
    if (!portfolio) {
      return;
    }
 
 
    try {
 
      setLoading(true);
      setError("");
 
 
      const isAll =
        paginationModel.pageSize === -1;
 
 
      const data =
        await getReferenceSecurities({
 
          exchange:
            portfolio.exchange,
 
          search:
            appliedSearch,

          equity_category:
            equityCategory === "All"
              ? ""
              : equityCategory,
 
          page:
            isAll
              ? 1
              : paginationModel.page + 1,
 
          pageSize:
            isAll
              ? 2100
              : paginationModel.pageSize,
 
        });
 
 
      setRows(
        data.rows || []
      );
 
      setTotal(
        data.total || 0
      );
 
    }
    catch (err) {
 
      console.error(err);
 
      setError(
        "Unable to load securities"
      );
 
    }
    finally {
 
      setLoading(false);
 
    }
  }
 
 
  useEffect(() => {
 
    if (
      open &&
      portfolio
    ) {
 
      loadSecurities();
 
    }
 
  }, [
    open,
    portfolio?.portfolio_id,
    paginationModel.page,
    paginationModel.pageSize,
    appliedSearch,
    equityCategory,
  ]);
 
 
  useEffect(() => {
 
    if (open) {
 
      setSearch("");
      setAppliedSearch("");
      setEquityCategory("All");
      setQuantityMap({});
      setMessage("");
      setError("");
 
      setPaginationModel({
        page: 0,
        pageSize: 25,
      });
 
    }
 
  }, [open]);
 
 
  function handleQuantityChange(
    securityId,
    value
  ) {
 
    setQuantityMap(
      (previous) => ({
 
        ...previous,
 
        [securityId]:
          value,
 
      })
    );
 
  }
 
 
  async function handleBuy(
    security
  ) {
 
    const quantity =
      Number(
        quantityMap[
          security.security_id
        ]
      );
 
 
    if (
      !quantity ||
      quantity <= 0
    ) {
 
      setError(
        "Enter a valid quantity"
      );
 
      return;
 
    }
 
 
    try {
 
      setError("");
      setMessage("");
 
 
      await addHolding(
 
        portfolio.portfolio_id,
 
        {
 
          security_id:
            security.security_id,
 
          quantity:
            quantity,
 
        }
 
      );
 
 
      setMessage(
        `${security.symbol} purchased successfully`
      );
 
 
      setQuantityMap(
        (previous) => ({
 
          ...previous,
 
          [security.security_id]:
            "",
 
        })
      );
 
 
      if (onAdded) {
 
        await onAdded();
 
      }
 
    }
    catch (err) {
 
      console.error(err);
 
      setError(
 
        err.response?.data?.detail
        ||
        "Unable to buy security"
 
      );
 
    }
 
  }
 
 
  const categoryOptions = [
    "All",
    "Large Cap",
    "Medium Cap",
    "Small Cap",
  ];


  const columns = [
 
    {
      field: "symbol",
      headerName: "Symbol",
      width: 140,
    },
 
    {
      field: "security_name",
      headerName: "Security Name",
      width: 250,
    },
 
    {
      field: "stock_exchange",
      headerName: "Exchange",
      width: 120,
    },
 
    {
      field: "asset_class",
      headerName: "Asset Class",
      width: 160,
    },
 
    {
      field: "equity_category",
      headerName: "Category",
      width: 140,
    },

    {
      headerName: "Currency",
      width: 100,
    },
 
    {
      field: "quantity",
      headerName: "Quantity",
      width: 130,
 
      sortable: false,
 
      renderCell: (params) => (
 
        <TextField
 
          size="small"
 
          type="number"
 
          value={
            quantityMap[
              params.row.security_id
            ]
            || ""
          }
 
          onChange={(event) =>
            handleQuantityChange(
 
              params.row.security_id,
 
              event.target.value
 
            )
          }
 
          slotProps={{
            htmlInput: {
              min: 0.0001,
            },
          }}
 
        />
 
      ),
 
    },
 
    {
      field: "buy",
      headerName: "Action",
      width: 110,
 
      sortable: false,
      filterable: false,
 
      renderCell: (params) => (
 
        <Button
          size="small"
          variant="contained"
 
          onClick={() =>
            handleBuy(
              params.row
            )
          }
        >
          Buy
        </Button>
 
      ),
 
    },
 
  ];
 
 
  return (
 
    <Dialog
      open={open}
      onClose={onClose}
 
      fullWidth
      maxWidth="lg"
    >
 
      <DialogTitle>
 
        Add Holding
 
      </DialogTitle>
 
 
      <DialogContent>
 
        {portfolio && (
 
          <Typography
            sx={{
              mb: 2,
            }}
          >
 
            Portfolio:{" "}
 
            <strong>
              {portfolio.portfolio_name}
            </strong>
 
            {" | "}
 
            Preferred Exchange:{" "}
 
            <strong>
              {portfolio.exchange}
            </strong>
 
          </Typography>
 
        )}
 
 
        {error && (
 
          <Alert
            severity="error"
            sx={{
              mb: 2,
            }}
          >
            {error}
          </Alert>
 
        )}
 
 
        {message && (
 
          <Alert
            severity="success"
            sx={{
              mb: 2,
            }}
          >
            {message}
          </Alert>
 
        )}
 
 
        <Box
          sx={{
            display: "flex",
            gap: 1,
            mb: 2,
            alignItems: "center",
          }}
        >
 
          <TextField
 
            fullWidth
 
            size="small"
 
            label="Search securities"
 
            value={
              search
            }
 
            onChange={(event) =>
              setSearch(
                event.target.value
              )
            }
 
            onKeyDown={(event) => {
 
              if (
                event.key === "Enter"
              ) {
 
                setPaginationModel(
                  (previous) => ({
                    ...previous,
                    page: 0,
                  })
                );
 
                setAppliedSearch(
                  search
                );
 
              }
 
            }}
 
          />

          <TextField
            select
            size="small"
            label="Category"
            value={equityCategory}
            onChange={(event) => setEquityCategory(event.target.value)}
            sx={{ minWidth: 170 }}
          >
            {categoryOptions.map((option) => (
              <MenuItem key={option} value={option}>
                {option}
              </MenuItem>
            ))}
          </TextField>
 
 
          <Button
            variant="outlined"
 
            onClick={() => {
 
              setPaginationModel(
                (previous) => ({
                  ...previous,
                  page: 0,
                })
              );
 
              setAppliedSearch(
                search
              );
 
            }}
          >
            Search
          </Button>
 
        </Box>
 
 
        <Box
          sx={{
            height: 450,
            width: "100%",
          }}
        >
 
          <DataGrid
 
            rows={
              rows
            }
 
            columns={
              columns
            }
 
            getRowId={
              (row) =>
                row.security_id
            }
 
            loading={
              loading
            }
 
            rowCount={
              paginationModel.pageSize === -1
                ? rows.length
                : total
            }
 
            paginationMode={
              paginationModel.pageSize === -1
                ? "client"
                : "server"
            }
 
            paginationModel={
              paginationModel
            }
 
            onPaginationModelChange={
              (newModel) => {
 
                setPaginationModel({
 
                  page:
                    newModel.pageSize !==
                    paginationModel.pageSize
                      ? 0
                      : newModel.page,
 
                  pageSize:
                    newModel.pageSize,
 
                });
 
              }
            }
 
            pageSizeOptions={[
 
              5,
              10,
              25,
              50,
              100,
 
              {
                value: -1,
                label: "All",
              },
 
            ]}
 
            disableRowSelectionOnClick
 
          />
 
        </Box>
 
      </DialogContent>
 
 
      <DialogActions>
 
        <Button
          onClick={
            onClose
          }
        >
          Close
        </Button>
 
      </DialogActions>
 
    </Dialog>
 
  );
 
}
 
 
export default AddHoldingDialog;
 