from datetime import date
 
from app.repositories.portfolio_repository import (
    PortfolioRepository
)
 
from app.services.ums_service import (
    UMSService
)
 
from app.services.valuation_service import (
    ValuationService
)
 
 
class PerformanceService:
 
    START_DATE = date(
        2026,
        10,
        1
    )
 
 
    @staticmethod
    async def get_performance(
        portfolio_id: int,
        valuation_date: date
    ):
 
        # ==========================================
        # 1. GET PORTFOLIO
        # ==========================================
 
        portfolio = (
            PortfolioRepository
            .get_portfolio_by_id(
                portfolio_id
            )
        )
 
 
        if portfolio is None:
 
            raise ValueError(
                "Portfolio not found"
            )
 
 
        # ==========================================
        # 2. GET PORTFOLIO VALUATION
        # ==========================================
 
        valuation = await (
            ValuationService
            .get_portfolio_valuation(
                portfolio_id,
                valuation_date
            )
        )
 
 
        portfolio_return = float(
            valuation[
                "portfolio_return_percentage"
            ]
        )
 
 
        # ==========================================
        # 3. GET BENCHMARKS FROM UMS
        # ==========================================
 
        benchmarks = await (
            UMSService.get_benchmarks()
        )
 
 
        benchmark = next(
            (
                item
                for item in benchmarks
 
                if item["benchmark_id"]
                ==
                portfolio["benchmark_id"]
            ),
            None
        )
 
 
        if benchmark is None:
 
            raise ValueError(
                "Benchmark not found"
            )
 
 
        # ==========================================
        # 4. BENCHMARK RETURN
        # ==========================================
 
        benchmark_return = 0
 
        benchmark_start_value = None
        benchmark_current_value = None
 
 
        # Day 1:
        # Portfolio was bought on Day 1,
        # therefore both returns start from 0.
 
        if (
            valuation_date
            ==
            PerformanceService.START_DATE
        ):
 
            benchmark_return = 0
 
            benchmark_start_value = float(
                benchmark["previous_close"]
            )
 
            benchmark_current_value = (
                benchmark_start_value
            )
 
 
        else:
 
            benchmark_start_value = float(
                benchmark["previous_close"]
            )
 
            benchmark_current_value = float(
                benchmark["close_price"]
            )
 
 
            if benchmark_start_value > 0:
 
                benchmark_return = (
 
                    (
                        benchmark_current_value
                        -
                        benchmark_start_value
                    )
 
                    /
 
                    benchmark_start_value
 
                    * 100
                )
 
 
        # ==========================================
        # 5. RELATIVE PERFORMANCE
        # ==========================================
 
        relative_return = (
            portfolio_return
            -
            benchmark_return
        )
 
 
        if relative_return > 0:
 
            performance_status = (
                "OUTPERFORMED"
            )
 
        elif relative_return < 0:
 
            performance_status = (
                "UNDERPERFORMED"
            )
 
        else:
 
            performance_status = (
                "MATCHED"
            )
 
 
        # ==========================================
        # 6. RESPONSE
        # ==========================================
 
        return {
 
            "portfolio_id":
                portfolio_id,
 
            "portfolio_name":
                portfolio[
                    "portfolio_name"
                ],
 
            "valuation_date":
                valuation_date,
 
            "exchange":
                portfolio[
                    "exchange"
                ],
 
            "currency":
                portfolio[
                    "currency"
                ],
 
            "total_invested_value":
                valuation[
                    "total_invested_value"
                ],
 
            "total_current_value":
                valuation[
                    "total_current_value"
                ],
 
            "total_profit_loss":
                valuation[
                    "total_profit_loss"
                ],
 
            "portfolio_return_percentage":
                round(
                    portfolio_return,
                    2
                ),
 
            "benchmark_id":
                benchmark[
                    "benchmark_id"
                ],
 
            "benchmark_name":
                benchmark[
                    "benchmark_name"
                ],
 
            "benchmark_code":
                benchmark[
                    "benchmark_code"
                ],
 
            "benchmark_start_value":
                round(
                    benchmark_start_value,
                    2
                ),
 
            "benchmark_current_value":
                round(
                    benchmark_current_value,
                    2
                ),
 
            "benchmark_return_percentage":
                round(
                    benchmark_return,
                    2
                ),
 
            "relative_return_percentage":
                round(
                    relative_return,
                    2
                ),
 
            "performance_status":
                performance_status
        }
 