from datetime import date
 
from fastapi import APIRouter
 
from app.services.ums_service import (
    UMSService
)
 
 
router = APIRouter(
    prefix="/ums-test",
    tags=["UMS Connection Test"]
)

 
@router.get("/themes")
async def test_themes():
 
    return await UMSService.get_themes()
 
 
# ==========================================
# TEST BENCHMARKS
# ==========================================
 
@router.get("/benchmarks")
async def test_benchmarks():
 
    return await UMSService.get_benchmarks()
 
 
# ==========================================
# TEST SECURITIES
# ==========================================
 
@router.get("/securities")
async def test_securities(
    exchange: str | None = None
):
 
    return await UMSService.get_securities(
        exchange=exchange,
        page=1,
        page_size=10
    )
 
 
# ==========================================
# TEST PRICE
# ==========================================
 
@router.get(
    "/security/{security_id}/price"
)
async def test_price(
    security_id: int,
    valuation_date: date
):
 
    return await UMSService.get_security_price(
        security_id,
        valuation_date
    )
 