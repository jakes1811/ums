from app.repositories.portfolio_repository import (
    PortfolioRepository
)
 
from app.services.ums_service import (
    UMSService
)
 
 
class PortfolioService:
 
    EXCHANGE_CONFIG = {
 
        "NSE": {
            "currency": "INR",
            "benchmark_code": "NIFTY50"
        },
 
        "NASDAQ": {
            "currency": "USD",
            "benchmark_code": "NDX"
        },
 
        "LSE": {
            "currency": "GBP",
            "benchmark_code": "FTSE100"
        }
    }
 
 
    @staticmethod
    async def create_portfolio(data):
 
        exchange = (
            data["exchange"]
            .strip()
            .upper()
        )
 
 
        # =========================================
        # VALIDATE EXCHANGE
        # =========================================
 
        if exchange not in PortfolioService.EXCHANGE_CONFIG:
 
            raise ValueError(
                "Exchange must be NSE, NASDAQ or LSE"
            )
 
 
        config = (
            PortfolioService.EXCHANGE_CONFIG[
                exchange
            ]
        )
 
 
        # =========================================
        # VALIDATE THEME FROM UMS
        # =========================================
 
        themes = await UMSService.get_themes()
 
 
        selected_theme = next(
            (
                theme
                for theme in themes
 
                if theme["theme_id"]
                ==
                data["theme_id"]
            ),
            None
        )
 
 
        if selected_theme is None:
 
            raise ValueError(
                "Invalid investment theme"
            )
 
 
        if selected_theme["status"] != "ACTIVE":
 
            raise ValueError(
                "Selected investment theme is inactive"
            )
 
 
        # =========================================
        # GET BENCHMARK FROM UMS
        # =========================================
 
        benchmarks = (
            await UMSService.get_benchmarks()
        )
 
 
        selected_benchmark = next(
            (
                benchmark
                for benchmark in benchmarks
 
                if benchmark[
                    "benchmark_code"
                ]
                ==
                config["benchmark_code"]
            ),
            None
        )
 
 
        if selected_benchmark is None:
 
            raise ValueError(
                "Benchmark not found for selected exchange"
            )
 
 
        # =========================================
        # CREATE PORTFOLIO
        # =========================================
 
        portfolio_id = (
            PortfolioRepository.create_portfolio(
 
                portfolio_name=
                    data["portfolio_name"],
 
                portfolio_type=
                    data.get("portfolio_type"),
                fund_manager_name = data.get("fund_manager_name"),
 
                currency=
                    config["currency"],
 
                exchange=
                    exchange,
 
                benchmark_id=
                    selected_benchmark[
                        "benchmark_id"
                    ],
 
                rebalancing_frequency=
                    data.get(
                        "rebalancing_frequency"
                    ),
 
                amount=
                    data.get(
                        "amount",
                        0
                    ),
 
                theme_id=
                    data["theme_id"]
            )
        )
 
 
        return {
            "message":
                "Portfolio created successfully",
 
            "portfolio_id":
                portfolio_id,
 
            "status":
                "NEW",
 
            "exchange":
                exchange,
 
            "currency":
                config["currency"],
 
            "theme":
                selected_theme[
                    "theme_name"
                ],
 
            "benchmark":
                selected_benchmark[
                    "benchmark_name"
                ]
        }
 
 
    @staticmethod
    async def get_all_portfolios():
 
        portfolios = (
            PortfolioRepository
            .get_all_portfolios()
        )
 
 
        themes = (
            await UMSService.get_themes()
        )
 
        benchmarks = (
            await UMSService.get_benchmarks()
        )
 
 
        theme_lookup = {
            theme["theme_id"]:
            theme["theme_name"]
 
            for theme in themes
        }
 
 
        benchmark_lookup = {
            benchmark["benchmark_id"]:
            benchmark["benchmark_name"]
 
            for benchmark in benchmarks
        }
 
 
        for portfolio in portfolios:
 
            portfolio["theme_name"] = (
                theme_lookup.get(
                    portfolio["theme_id"]
                )
            )
 
            portfolio["benchmark_name"] = (
                benchmark_lookup.get(
                    portfolio["benchmark_id"]
                )
            )
 
 
        return portfolios
 
 
    @staticmethod
    async def get_portfolio_by_id(
        portfolio_id
    ):
 
        portfolio = (
            PortfolioRepository
            .get_portfolio_by_id(
                portfolio_id
            )
        )
 
 
        if portfolio is None:
            return None
 
 
        themes = (
            await UMSService.get_themes()
        )
 
        benchmarks = (
            await UMSService.get_benchmarks()
        )
 
 
        selected_theme = next(
            (
                theme
                for theme in themes
 
                if theme["theme_id"]
                ==
                portfolio["theme_id"]
            ),
            None
        )
 
 
        selected_benchmark = next(
            (
                benchmark
                for benchmark in benchmarks
 
                if benchmark["benchmark_id"]
                ==
                portfolio["benchmark_id"]
            ),
            None
        )
 
 
        portfolio["theme_name"] = (
            selected_theme["theme_name"]
            if selected_theme
            else None
        )
 
 
        portfolio["benchmark_name"] = (
            selected_benchmark[
                "benchmark_name"
            ]
            if selected_benchmark
            else None
        )
 
 
        return portfolio

    @staticmethod
    def activate_portfolio(
        portfolio_id
    ):
    
        portfolio = (
            PortfolioRepository
            .get_portfolio_by_id(
                portfolio_id
            )
        )
    
    
        if portfolio is None:
    
            raise ValueError(
                "Portfolio not found"
            )
    
    
        if portfolio["status"] == "ACTIVE":
    
            return {
                "message":
                    "Portfolio is already active",
    
                "portfolio_id":
                    portfolio_id,
    
                "status":
                    "ACTIVE"
            }

        if portfolio["status"] == "CLOSED":
                raise ValueError("Closed portfolio cannot be activated again")
    
        PortfolioRepository.update_status(
            portfolio_id,
            "ACTIVE"
        )
    
    
        return {
    
            "message":
                "Portfolio activated successfully",
    
            "portfolio_id":
                portfolio_id,
    
            "status":
                "ACTIVE"
        }


    # =====================================================
    # CLOSE PORTFOLIO
    # =====================================================
    
    @staticmethod
    def close_portfolio(
        portfolio_id
    ):
    
        portfolio = (
            PortfolioRepository
            .get_portfolio_by_id(
                portfolio_id
            )
        )
    
    
        if portfolio is None:
    
            raise ValueError(
                "Portfolio not found"
            )
    
    
        if portfolio["status"] == "CLOSED":
    
            return {
                "message":
                    "Portfolio is already closed",
    
                "portfolio_id":
                    portfolio_id,
    
                "status":
                    "CLOSED"
            }
    
    
        if portfolio["status"] != "ACTIVE":
    
            raise ValueError(
                "Only an active portfolio can be closed"
            )
    
    
        PortfolioRepository.update_status(
            portfolio_id,
            "CLOSED"
        )
    
    
        return {
            "message":
                "Portfolio closed successfully",
    
            "portfolio_id":
                portfolio_id,
    
            "status":
                "CLOSED"
        }

    @staticmethod
    def delete_portfolio(portfolio_id:int):
        portfolio = (PortfolioRepository.get_portfolio_by_id(portfolio_id))
        if portfolio is None:
            raise ValueError("Portfolio not found")

        PortfolioRepository.delete_portfolio(portfolio_id)
        
        return {"message":"Portfolio deleted successfully",
                "portfolio_id":portfolio_id}
    
    
    