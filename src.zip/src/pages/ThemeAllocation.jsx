import {
  useEffect,
  useMemo,
  useState,
} from "react";
 
import {
  Alert,
  Box,
  Button,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Typography,
} from "@mui/material";
 
import {
  DataGrid,
} from "@mui/x-data-grid";
 
import SaveIcon
  from "@mui/icons-material/Save";
 
import {
  getAssetClasses,
  getThemeAllocations,
  getThemes,
  saveThemeAllocations,
} from "../api/api";
 
 
function ThemeAllocation() {
 
  const [themes, setThemes] =
    useState([]);
 
  const [assetClasses, setAssetClasses] =
    useState([]);
 
  const [selectedTheme, setSelectedTheme] =
    useState("");
 
  const [rows, setRows] =
    useState([]);
 
  const [loading, setLoading] =
    useState(false);
 
  const [message, setMessage] =
    useState("");
 
  const [error, setError] =
    useState("");
 
  useEffect(() => {
 
    async function loadMasterData() {
 
      try {
 
        const [
          themeData,
          assetData
        ] = await Promise.all([
 
          getThemes(),
 
          getAssetClasses(),
 
        ]);
 
 
        setThemes(themeData);
 
        setAssetClasses(assetData);
 
 
        if (
          themeData.length > 0
        ) {
 
          setSelectedTheme(
            themeData[0].theme_id
          );
        }
 
      }
      catch (error) {
 
        console.error(
          "Master data error:",
          error
        );
      }
    }
 
 
    loadMasterData();
 
  }, []);
 
  useEffect(() => {
 
    if (!selectedTheme) {
      return;
    }
 
 
    async function loadAllocation() {
 
      try {
 
        setLoading(true);
 
        setMessage("");
 
        setError("");
 
 
        const existing =
          await getThemeAllocations(
            selectedTheme
          );
 
 
        /*
          Make sure every Asset Class appears.
 
          Existing themes:
          use saved percentage.
 
          Newly created themes:
          start from 0%.
        */
 
        const combinedRows =
          assetClasses.map(
            (asset) => {
 
              const found =
                existing.find(
                  (item) =>
                    item.asset_class_id ===
                    asset.asset_class_id
                );
 
 
              return {
 
                id:
                  asset.asset_class_id,
 
                asset_class_id:
                  asset.asset_class_id,
 
                asset_class:
                  asset.asset_class,
 
                target_percentage:
                  found
                    ? Number(
                        found.target_percentage
                      )
                    : 0,
              };
            }
          );
 
 
        setRows(
          combinedRows
        );
 
      }
      catch (error) {
 
        console.error(
          "Allocation load error:",
          error
        );
 
      }
      finally {
 
        setLoading(false);
      }
    }
 
 
    if (
      assetClasses.length > 0
    ) {
 
      loadAllocation();
    }
 
  }, [
    selectedTheme,
    assetClasses,
  ]);
 
  function handlePercentageChange(
    assetClassId,
    value
  ) {
 
    let numberValue =
      Number(value);
 
 
    if (
      Number.isNaN(
        numberValue
      )
    ) {
 
      numberValue = 0;
    }
 
 
    setRows(
      previousRows =>
        previousRows.map(
          (row) => {
 
            if (
              row.asset_class_id
              ===
              assetClassId
            ) {
 
              return {
                ...row,
 
                target_percentage:
                  numberValue,
              };
            }
 
            return row;
          }
        )
    );
 
 
    setMessage("");
 
    setError("");
  }
 
  const totalPercentage =
    useMemo(
      () => {
 
        return rows.reduce(
          (
            total,
            row
          ) =>
            total
            +
            Number(
              row.target_percentage
              || 0
            ),
 
          0
        );
 
      },
      [rows]
    );
 
  async function handleSave() {
 
    setMessage("");
 
    setError("");
 
 
    if (
      Math.round(
        totalPercentage * 100
      ) / 100 !== 100
    ) {
 
      setError(
        `Total allocation must be 100%. Current total is ${totalPercentage}%.`
      );
 
      return;
    }
 
 
    try {
 
      const allocationData =
        rows.map(
          (row) => ({
 
            asset_class_id:
              row.asset_class_id,
 
            target_percentage:
              Number(
                row.target_percentage
              ),
          })
        );
 
 
      await saveThemeAllocations(
        selectedTheme,
        allocationData
      );
 
 
      setMessage(
        "Theme allocation saved successfully"
      );
 
    }
    catch (error) {
 
      console.error(
        "Allocation save error:",
        error
      );
 
 
      setError(
        error.response?.data?.detail
        ||
        "Unable to save theme allocation"
      );
    }
  }
 
  const columns = [
 
    {
      field:
        "asset_class_id",
 
      headerName:
        "ID",
 
      width: 90,
    },
 
 
    {
      field:
        "asset_class",
 
      headerName:
        "Asset Class",
 
      flex: 1,
 
      minWidth: 220,
    },
 
 
    {
      field:
        "target_percentage",
 
      headerName:
        "Target %",
 
      flex: 1,
 
      minWidth: 220,
 
 
      renderCell: (
        params
      ) => (
 
        <TextField
 
          type="number"
 
          size="small"
 
          value={
            params.row
              .target_percentage
          }
 
          onChange={
            (event) =>
              handlePercentageChange(
                params.row
                  .asset_class_id,
 
                event.target.value
              )
          }
 
          inputProps={{
            min: 0,
            max: 100,
            step: 0.01,
          }}
 
          sx={{
            width: 140,
          }}
 
        />
 
      ),
    },
  ];
 
 
  return (
 
    <Box>
 
      {/* HEADER */}
 
      <Typography
        variant="h4"
        fontWeight="bold"
      >
        Theme Allocation
      </Typography>
 
 
      <Typography
        color="text.secondary"
        sx={{
          mb: 3,
        }}
      >
        Define target asset allocation
        for each investment theme
      </Typography>
 
 
      {/* THEME SELECTOR */}
 
      <Box
        sx={{
          display: "grid",
 
          gridTemplateColumns:
            "300px 1fr auto",
 
          gap: 2,
 
          alignItems: "center",
 
          mb: 3,
        }}
      >
 
        <FormControl
          size="small"
        >
 
          <InputLabel>
            Investment Theme
          </InputLabel>
 
 
          <Select
 
            label="Investment Theme"
 
            value={
              selectedTheme
            }
 
            onChange={
              (event) =>
                setSelectedTheme(
                  event.target.value
                )
            }
          >
 
            {
              themes.map(
                (theme) => (
 
                  <MenuItem
 
                    key={
                      theme.theme_id
                    }
 
                    value={
                      theme.theme_id
                    }
                  >
 
                    {theme.theme_name}
 
                  </MenuItem>
 
                )
              )
            }
 
          </Select>
 
        </FormControl>
 
 
        {/* TOTAL */}
 
        <Typography
          variant="h6"
        >
 
          Total Allocation:
 
          {" "}
 
          <strong>
            {totalPercentage}%
          </strong>
 
        </Typography>
 
 
        <Button
 
          variant="contained"
 
          startIcon={
            <SaveIcon />
          }
 
          onClick={
            handleSave
          }
 
        >
          Save Allocation
        </Button>
 
      </Box>
 
 
      {/* SUCCESS */}
 
      {
        message &&
        (
          <Alert
            severity="success"
            sx={{
              mb: 2,
            }}
          >
            {message}
          </Alert>
        )
      }
 
 
      {/* ERROR */}
 
      {
        error &&
        (
          <Alert
            severity="error"
            sx={{
              mb: 2,
            }}
          >
            {error}
          </Alert>
        )
      }
 
 
      {/* DATA GRID */}
 
      <Box
        sx={{
          height: 520,
          width: "100%",
        }}
      >
 
        <DataGrid
 
          rows={rows}
 
          columns={columns}
 
          loading={loading}
 
          getRowId={
            (row) =>
              row.asset_class_id
          }
 
          disableRowSelectionOnClick
 
          hideFooter
 
        />
 
      </Box>
 
    </Box>
  );
}
 
 
export default ThemeAllocation;